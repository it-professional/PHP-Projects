<?php session_start() ;
include("checksession.php");
$pd = $_SESSION['PID'] ;
if(isset($_GET['PID']) && $_GET['PID'] != "")
{
	$_SESSION['Backlink'] = "Markedusers.php?PID=$pd" ;
}
else
{
	$_SESSION['Backlink'] = "viewrating.php?PID=$pd" ;
}	
?>
<title> Product Owner Detail </title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table cellpadding="0" cellspacing="0" border="0" width="100%" >
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_SESSION['Backlink'] ;?>');"  colspan="5">Go Back
</td>
</tr>
 <tr>
 <td>
 <table border="0" cellpadding="0" cellspacing="0" width="100%">
 	<tr bgcolor="#CCCCCC">
					<td class="SubHeading" width="15%"><b>Rating From</b></td>
					<td class="SubHeading" width="15%"><b>Rating</b></td>
					<td class="SubHeading" width="55%" align="center"><b>Comments</b></td>
					<td class="SubHeading" align="center" width="15%"><b>Posted Date</b></td>						
				</tr>
<?php
$ratingtopersonid = $_GET['bid'] ;
include("include/config.php");
$ratingforavg = 0 ;
$ratingquery = mysql_query("select * from  tblrating where iratingto = '".$_GET['bid']."' order by iid asc");
$ratingrows = mysql_num_rows($ratingquery);
if($ratingrows  > 0)
	{
		while($ratingdata = mysql_fetch_array($ratingquery))
		{
			$rating = $ratingdata['irating'] ;
			$ratingcomments = $ratingdata['strdescription'] ;
			$ratingfrom = $ratingdata['iratingfrom'] ;
			$ratingdate = $ratingdata['ddate'] ;
			$ratingforavg = $ratingforavg + $ratingdata['irating'] ;
			
			$userquery = mysql_query("select strnickname from tblmember where iid = '$ratingfrom'");
			$userdata = mysql_fetch_array($userquery);
			$nick = $userdata['strnickname'] ;	
			
			
			if($rating == 1)	
			{
				$strrating = "Horrible" ;
				$strimage = "horrible.gif" ;
			}
			else if($rating == 2)	
			{
				$strrating = "Bad" ;
				$strimage = "bad.gif" ;
			}
			else if($rating == 3)	
			{
				$strrating = "Poor" ;
				$strimage = "poor.gif" ;
			}
			else if($rating == 4)	
			{
				$strrating = "Below Average" ;
				$strimage = "belowavg.gif" ;
			}
			else if($rating == 5)	
			{
				$strrating = "Average" ;
				$strimage = "average.gif" ;
			}
			else if($rating == 6)	
			{
				$strrating = "Above Average" ;
				$strimage = "aboveavg.gif" ;
			}
			else if($rating == 7)	
			{
				$strrating = "Good" ;
				$strimage = "good.gif" ;
			}
			else if($rating == 8)	
			{
				$strrating = "Very Good" ;
				$strimage = "vgood.gif" ;
			}
			else if($rating == 9)	
			{
				$strrating = "Superb" ;
				$strimage = "superb.gif" ;
			}
			else if($rating == 10)	
			{
				$strrating = "Excellent" ;
				$strimage = "excellent.gif" ;
			}
			else 	
			{
				$strrating = "" ;
			}
			
			

?>
				<tr>
					<?php 
					if(isset($_GET['PID']) && $_GET['PID'] != "")
					{
					?>
					<td class="bluelink" width="15%" onClick="javascript: ViewAgainstMarkedUserRating('<?php echo $ratingfrom ; ?>','<?php echo $ratingtopersonid ;?>','<?php echo $_GET['PID'] ;?>');"><?php echo $nick ;?></td>
					<?php } else { ?>
					<td class="bluelink" width="15%" onClick="javascript: GoToViewRating('<?php echo $ratingfrom ; ?>','<?php echo $ratingtopersonid ;?>');"><?php echo $nick ;?></td>
					<?php } ?>
					<td class="SubHeading" width="15%"><?php if($strimage !="") { ?><img align="absmiddle" src="images/<?php echo $strimage ;?>" border="0" />&nbsp;<?php } ?><?php echo $rating."-".$strrating ; ?></td>
					<td class="SubHeading" width="55%" align="center"><?php echo $ratingcomments ; ?></td>
					<td class="SubHeading" align="center" width="15%"><?php echo $ratingdate?></td>						
				</tr>
<?php 
		}
		$ratingaverage2 = $ratingforavg / $ratingrows ;
		$ratingaverage = number_format($ratingaverage2,2);
		$roundratingavg = round($ratingaverage);
		
		if($roundratingavg == 1)	
	{
		$straveragerating = "Horrible" ;
		$strimage = "horrible.gif" ;
	}
	else if($roundratingavg == 2)	
	{
		$straveragerating = "Bad" ;
		$strimage = "bad.gif" ;
	}
	else if($roundratingavg == 3)	
	{
		$straveragerating = "Poor" ;
		$strimage = "poor.gif" ;
	}
	else if($roundratingavg == 4)	
	{
		$straveragerating = "Below Average" ;
		$strimage = "belowavg.gif" ;
	}
	else if($roundratingavg == 5)	
	{
		$straveragerating = "Average" ;
		$strimage = "average.gif" ;
	}
	else if($roundratingavg == 6)	
	{
		$straveragerating = "Above Average" ;
		$strimage = "aboveavg.gif" ;
	}
	else if($roundratingavg == 7)	
	{
		$straveragerating = "Good" ;
		$strimage = "good.gif" ;
	}
	else if($roundratingavg == 8)	
	{
		$straveragerating = "Very Good" ;
		$strimage = "vgood.gif" ;
	}
	else if($roundratingavg == 9)	
	{
		$straveragerating = "Superb" ;
		$strimage = "superb.gif" ;
	}
	else if($roundratingavg == 10)	
	{
		$straveragerating = "Excellent" ;
		$strimage = "excellent.gif" ;
	}
		?>
		<tr><td colspan="4">&nbsp;</td></tr>
		<tr><td colspan="4">&nbsp;</td></tr>
		<tr>
		<td colspan="4" align="center"  class="Heading"><b>Average Rating:</b> <img  align="absmiddle" src="images/<?php echo $strimage ;?>" border="0" /><?php echo $ratingaverage." (".$straveragerating.") " ; ?></a>
		</tr>
		<?php
	}
	else
	{
?>	
	<tr><td class="SubHeading">
		</td></tr>
	<?php }?>				
			<tr bgcolor="#CCCCCC"><td colspan="11">&nbsp;</td></tr>	
			</table></td></tr>
</table>