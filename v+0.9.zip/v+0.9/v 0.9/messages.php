<?php
 session_start() ;
 include("checksession.php");
 ?>
 
 <title>View Messages</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>
<?php 
//echo($_SESSION['loginid']);

include("include/config.php");
if(isset($_POST['submit']))
{
	$markeduserid = $_POST['hdnmarkeduserid'] ;
	$prodownerid = $_POST['hdnproductownerid'] ;
	$pid = $_POST['hdnproductid'] ;
	$msg= $_POST['postmessage'] ;
	$gethdnbacklink = $_POST['hdnbacklink'] ;
	$todaydate = date("y-m-d");
	$messagefrom = $_SESSION['loginid'] ;
	//
	$chkbacklink = $_SESSION["Backlink1"] ;
	$getfirstvalue = explode(".php", $chkbacklink) ;
	if($getfirstvalue[0] == "MarkedProducts" || $getfirstvalue[0] == "boughtproducts")
	{
		$messageto = $prodownerid ;
	}
	else
	{
		$messageto = $markeduserid ;
	}
	
	$query4 = mysql_query("INSERT INTO tblmessages (ipid,bactive,strmessage,ifromuid,itouid,ddate) values('$pid' ,1,'$msg','$messagefrom','$messageto', '$todaydate')");
	if($query4)
	{
		// GET emailid of email receiver
		$mailquery = mysql_query("select stremail from tblmember where iid = '$messageto'");
		$maildata = mysql_fetch_array($mailquery);
		$receiveremailid = $maildata['stremail'] ;
		
		$mailquery2 = mysql_query("select strnickname from tblmember where iid = '$messagefrom'");
		$maildata2 = mysql_fetch_array($mailquery2);
		$delivernickname = $maildata2['strnickname'] ;
		
		// GET Receintely delivered message
		$messagequery = mysql_query("select max(iid) as iid from tblmessages ");
		$messagedata = mysql_fetch_array($messagequery);
		$sentid = $messagedata['iid'];
		
		$postedmessagequery = mysql_query("select strmessage  from tblmessages where iid = '$sentid'");
		$postmessagedata = mysql_fetch_array($postedmessagequery);
		$sentmessage = html_entity_decode($postmessagedata['strmessage']);
		
		
		
		$headers = "MIME-Version: 1.0\r\n";  
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: PickmeFriend.com";
		
		$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
		$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
		$strHTML .= "<b>Message: </b>".$sentmessage."<br><br>";
		$strHTML .= "</td></tr></table>";
			
		$strHTML = stripslashes($strHTML);	
		
		$subject = "A New Message Posted From ".$delivernickname ;
		
		mail($receiveremailid,$subject,$strHTML,$headers);
		//mail($receiveremailid,"A New Message Posted",$strHTML,$headers);
		
		if($gethdnbacklink != "")
		{
	?>
		<script language="javascript">
			window.location.href = 'main.php?pg=messages.php&PID=<?php echo $pid ;?>&bid=<?php echo $markeduserid ;?>&blink=<?php echo $gethdnbacklink ;?>' ;
		</script>
	<?php
	}
	else
	{
	?>
	<script language="javascript">
			window.location.href = 'main.php?pg=messages.php&PID=<?php echo $pid ;?>&bid=<?php echo $markeduserid ;?>' ;
		</script>	
	<?php
	}
	
	}
}
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?php if($_GET['blink'] == 'Markedusers')  { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onclick="javascript: goback('Markedusers.php?PID=<?php echo $_GET['PID']?>&blink=selleraccount.php');" colspan="5" >Go Back
</td>
</tr>
<?php } else {?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onclick="javascript: goback('<?php echo $_SESSION["Backlink1"] ;?>');" colspan="5" >Go Back
</td>
</tr>
<?php } ?>
<?php
$productid = $_GET['PID'];
$markeduserid = $_GET['bid']; // This is id of buyer/marked person

$query5 = mysql_query("select strproductname,iuid from tblproducts where iid = '$productid'");
$data5  = mysql_fetch_array($query5);
$name = $data5['strproductname'] ;
$productowner = $data5['iuid'] ;
$loginuser = $_SESSION['loginid'];
?>

<tr>
		<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
			<font face="verdana" size="+1" color="#000000"><b><?php echo $name ;?>&nbsp; Messages</b></font>
		</td>
</tr>
<?php
$query2 = mysql_query("select * from tblmessages where ipid = '$productid' AND ((ifromuid = '$productowner' AND itouid = '$markeduserid') OR (ifromuid = '$markeduserid' and itouid = '$productowner')) ORDER BY ddate ASC");
$rows = mysql_num_rows($query2);
if($rows > 0)
{
	while($data2 = mysql_fetch_array($query2))
	{
		$fromuser = $data2['ifromuid'] ;
		//Getting Users info
		$query1 = mysql_query("select * from tblmember where iid = '$fromuser'");
		$rows2 = mysql_num_rows($query1);
		if($rows2 > 0)
		{
			$data = mysql_fetch_array($query1);
			$firstname = $data['strfirstname'] ;
			$lastname = $data['strlastname'] ;
			$nick = $data['strnickname'] ;	
			$country = $data['strcountry'] ;
			$city = $data['strcity'] ;
				
	//	}
		//Getting Messages Information
		$message = $data2['strmessage'] ;
		$posteddate = $data2['ddate'] ;
		//Displaying messages in date descending order
		
		if($fromuser == $loginuser)
		{
			$backgroundcolor = "#FF99CC" ;
		}
		else
		{
			$backgroundcolor = "#CCFFFF" ;
		}
		?>

			
			<tr bgcolor="<?php echo $backgroundcolor ; ?>">
				<td class="SubHeading">
					<span class="Heading">From: </span> <?php echo $nick ;?>
				</td>
			</tr>
			<tr bgcolor="<?php echo $backgroundcolor ; ?>">
				<td class="SubHeading">
					<span class="Heading">Posted On: </span> <?php echo $posteddate ;?>
				</td>
			</tr>
			<tr bgcolor="<?php echo $backgroundcolor ; ?>">
				<td class="Heading">
					Message:-
				</td>
			</tr>
			<tr bgcolor="<?php echo $backgroundcolor ; ?>">
				<td class="SubHeading">
					<?php echo $message ;?>
				</td>
			</tr>
			<tr bgcolor="<?php echo $backgroundcolor ; ?>"><td>&nbsp;</td></tr>
			<tr><td><hr width="50%" /></td></tr>
		<?php		
	}
	}
	}
	else
	{
	?>
	<tr>
		<td class="SubHeading" width="100%">
			There is no Message now yet.
		</td>
	</tr>
	<?php
}	


//echo("select * from tblmessages where ipid = '$productid' AND iuid IN($arrMarkedUsers) ORDER BY ddate ASC");
//end;

?>




	<tr>
		<td class="Heading">
			Post New Message
		</td>
	</tr>
	
	<form name="messages" action="messages.php"  method="post">
	<tr>
		<td>
			
			  <textarea id="postmessage" name="postmessage" ></textarea>
				<script language="javascript">
					generate_wysiwyg('postmessage');
				</script>
		</td>
	</tr>
	<tr>
		<td>

			
			<input type="hidden" name="hdnproductownerid" value="<?php echo $productowner ;?>" />
			<input type="hidden" name="hdnmarkeduserid" value="<?php echo $markeduserid ;?>" />
			<input type="hidden" name="hdnproductid" value="<?php echo $productid?>" />
			<input type="hidden" name="hdnbacklink" value="<?php echo $_GET['blink'] ;?>" />
			<input type="submit" class="SubHeading" name="submit" value=" Submit " />
		</td>
	</tr>
	</form>

</table>	