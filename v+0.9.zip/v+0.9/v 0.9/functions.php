<?php
session_start();
include("include/config.php");
include("random.php");
function findipaddress()
{
	if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
	{
	  $ip=$_SERVER['HTTP_CLIENT_IP'];
	}
	elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
	{
	  $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	else
	{
	  $ip=$_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}
	
	
$Action = $_POST['action'] ;

if($Action == 'HomeSignup')
{
	$nickname = $_POST['nick'] ;
	$email = $_POST['email'] ;
	$country = $_POST['country'] ;
	$nlang = $_POST['nlang'] ;
	$socialnetwork = $_POST['socialnetwork'] ;
	$date = date("y-m-d");
	
	
	$query = mysql_query("select * from tblmember where stremail = '$email' or strnickname = '$nickname'");
	$rows = mysql_num_rows($query);
	if($rows > 0)
	{
		$comdata = mysql_fetch_array($query);
		$comemail = $comdata['stremail'] ;
		$comnick =  $comdata['strnickname'] ;
		if($comemail == $email)
		{
			//$msg = "Email Address of this name already exists." ;
			$msg = 1 ;
		}
		else
		{
			//$msg = "Nick of this name already exists." ;
			$msg = 2 ;
		}
			//$message = "The User of this Information already exists. Try another Email Address or Nick." ;
	?>
		<script language="javascript">
		// var msg = "The User of this Information already exists. Try another Email Address or Nick." ;
		window.location.href = 'index.php?registrationmessage=<?php echo $msg ;?>' ;
		//window.location.href = 'registeruser.php' ;
		</script>	
	<?php
	}
	else
	{
		$newquery = mysql_query("select * from tblmember_temp where stremail = '$email'");
		$newrows = mysql_num_rows($newquery);
		if($newrows > 0)
		{
			$newdata = mysql_fetch_array($newquery) ;
			
				$temporarypassword = $newdata['strtemppassword'] ;
				if($temporarypassword == "" || $temporarypassword == "NULL")
				{
					$temporarypassword = get_rand_id(128);
				}
				
				$iid = $newdata['iid'];
				$query2 = mysql_query("update tblmember_temp set strnickname = '$nickname' , strcountry = '$country' , strnativelang = '$nlang' , strsocialnetwork = '$socialnetwork' , ddate = '$date' ,strtemppassword = '$temporarypassword' where iid = '$iid' ");
			
		}
		else
		{
			//$temporarypassword = rand(1111111111111111111 , 9999999999999999999);
			$temporarypassword = get_rand_id(128);
			$query2 = mysql_query("insert into tblmember_temp (strnickname , stremail , strcountry , strnativelang , strsocialnetwork , ddate,strtemppassword) values('$nickname' , '$email' , '$country' , '$nlang' , '$socialnetwork' ,'$date','$temporarypassword')");
			$query3 = mysql_query("select max(iid) as iid from tblmember_temp");
			$row = mysql_fetch_array($query3);
			$iid = $row['iid'];
		
		}	
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: PickmeFriend.com";
		
			$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
			$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
			$strHTML .= "<b>Email ID : </b>".$email."<br>";
			$strHTML .= "<a target = '_blank' href = 'http://pickmefriend.com/beta/index.php?step=abc3def&temp=$temporarypassword'><b>Please Click Here To Confirm your Registration</b></a>" ;
			$strHTML .= "</td></tr></table>";
			
			$strHTML = stripslashes($strHTML);	
			mail($email,"Confirm Your Registration",$strHTML,$headers);	
		//	echo $strHTML ;
			
	?>
			<script language="javascript">
				window.location.href = 'index.php?step=abc2def' ;
			</script>
		
	<?php
	}
	
}


if($Action == 'Registration')
{
	
	$nickname = $_POST['nick'] ;
	$email = $_POST['email'] ;
	$country = $_POST['country'] ;
	$nlang = $_POST['nlang'] ;
	$socialnetwork = $_POST['socialnetwork'] ;
	$date = date("y-m-d");
	
	
	$query = mysql_query("select * from tblmember where stremail = '$email' or strnickname = '$nickname'");
	$rows = mysql_num_rows($query);
	if($rows > 0)
	{
		$comdata = mysql_fetch_array($query);
		$comemail = $comdata['stremail'] ;
		$comnick =  $comdata['strnickname'] ;
		if($comemail == $email)
		{
			$msg = "Email Address of this name already exists." ;
		}
		else
		{
			$msg = "Nick of this name already exists." ;
		}
			//$message = "The User of this Information already exists. Try another Email Address or Nick." ;
	?>
		<script language="javascript">
		// var msg = "The User of this Information already exists. Try another Email Address or Nick." ;
			window.location.href = 'registeruser.php?message=<?php echo $msg ;?>' ;
		//window.location.href = 'registeruser.php' ;
		</script>	
	<?php
	}
	else
	{
		$newquery = mysql_query("select * from tblmember_temp where stremail = '$email'");
		$newrows = mysql_num_rows($newquery);
		if($newrows > 0)
		{
			while($newdata = mysql_fetch_array($newquery))
			{
				$temporarypassword = $newdata['strtemppassword'] ;
				if($temporarypassword == "" || $temporarypassword == "NULL")
				{
					$temporarypassword = get_rand_id(128);
				}
				$iid = $newdata['iid'];
				$query2 = mysql_query("update tblmember_temp set strnickname = '$nickname' , strcountry = '$country' , strnativelang = '$nlang' ,  strsocialnetwork = '$socialnetwork' , ddate = '$date' ,strtemppassword = '$temporarypassword' where iid = '$iid' ");
			}
		}
		else
		{
			//$temporarypassword = rand(1111111111111111111 , 9999999999999999999);
			  $temporarypassword = get_rand_id(128);
				
			$query2 = mysql_query("insert into tblmember_temp (strnickname , stremail , strcountry , strnativelang , strsocialnetwork , ddate ,strtemppassword ) values('$nickname' , '$email' , '$country' , '$nlang' , '$socialnetwork' ,'$date','$temporarypassword')");
			$query3 = mysql_query("select max(iid) as iid from tblmember_temp");
			$row = mysql_fetch_row($query3);
			$iid = $row[0];
		
		}	
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: PickmeFriend.com";
		
			$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
			$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
			$strHTML .= "<b>Email ID : </b>".$email."<br><br>";
			$strHTML .= "<a target = '_blank' href = 'http://pickmefriend.com/beta/registeruser.php?step=abc6def&temp=$temporarypassword'><b>Please Click Here To Confirm your Registration</b></a>" ;
			$strHTML .= "</td></tr></table>";
			
			$strHTML = stripslashes($strHTML);	
		
			mail($email,"Confirm Your Registration",$strHTML,$headers);	
			//echo $strHTML ;
			
			
	?>
			<script language="javascript">
					window.location.href = 'registeruser.php?step=abc2def&temp=<?php echo $temporarypassword ;?>' ;
			</script>
		
	<?php
	}
	
}






if($Action == 'Signup')
{
	$firstname = $_POST['fname'] ;
	$nickname = $_POST['nick'] ;
	$lastname = $_POST['lname'] ;
	$company = $_POST['company'] ;
	$email = $_POST['email'] ;
	$country = $_POST['country'] ;
	$city = $_POST['city'] ;
	$address = $_POST['address'] ;
	$phone = $_POST['phone'] ;
	$nlang = $_POST['nlang'] ;
	$Mlang = $_POST['Mlang'] ;
	$dbirth = $_POST['dbirth'] ;
	$socialnetwork = $_POST['socialnetwork'] ;
	$date = date("y-m-d");
	$picture = $_FILES['picture']['name'] ;
	
	$query = mysql_query("select * from tblmember where stremail = '$email' or strnickname = '$nickname'");
	$rows = mysql_num_rows($query);
	if($rows > 0)
	{
		$comdata = mysql_fetch_array($query);
		$comemail = $comdata['stremail'] ;
		$comnick =  $comdata['strnickname'] ;
		if($comemail == $email)
		{
			$msg = "Email Address of this name already exists." ;
		}
		else
		{
			$msg = "Nick of this name already exists." ;
		}
			//$message = "The User of this Information already exists. Try another Email Address or Nick." ;
	?>
		<script language="javascript">
		// var msg = "The User of this Information already exists. Try another Email Address or Nick." ;
			window.location.href = 'registeruser.php?message=<?php echo $msg ;?>' ;
		//window.location.href = 'registeruser.php' ;
		</script>	
	<?php
	}
	else
	{
		$newquery = mysql_query("select * from tblmember_temp where stremail = '$email'");
		$newrows = mysql_num_rows($newquery);
		if($newrows > 0)
		{
			while($newdata = mysql_fetch_array($newquery))
			{
				$temporarypassword = $newdata['strtemppassword'] ;
				$iid = $newdata['iid'];
				$query2 = mysql_query("update tblmember_temp set strfirstname = '$firstname' , strnickname = '$nickname' , strlastname = '$lastname' , strcompany =  '$company' , strcountry = '$country' , strcity =  '$city' , straddress = '$address' , strphone = '$phone' , strnativelang = '$nlang' ,  strmangedlang = '$Mlang' , ddateofbirth = '$dbirth' , strsocialnetwork = '$socialnetwork' , ddate = '$date' , strpicture = '$picture' where iid = '$iid' ");
			}
		}
		else
		{
			$temporarypassword = rand(1111111111111111111 , 9999999999999999999);
			$query2 = mysql_query("insert into tblmember_temp (strfirstname , strnickname ,strlastname , strcompany , stremail , strcountry , strcity , straddress , strphone , strnativelang , strmangedlang , ddateofbirth , strsocialnetwork , ddate , strpicture) values('$firstname' , '$nickname' ,'$lastname' , '$company' , '$email' , '$country' , '$city' , '$address' , '$phone' , '$nlang' , '$Mlang' , '$dbirth' , '$socialnetwork' ,'$date' , '$picture')");
			$query3 = mysql_query("select max(iid) as iid from tblmember_temp");
			$row = mysql_fetch_row($query3);
			$iid = $row[0];
		
		}	
			
	if($_FILES['picture']['error'] <= 0)
	{
		
		if( ($_FILES["picture"]["type"] == "image/gif" || $_FILES["picture"]["type"] == "image/jpg" || $_FILES["picture"]["type"] ==  "image/jpeg"))
		{
			
			if (file_exists("images/accountpictures/" . $_FILES["picture"]["name"]))
			{
			
				unlink("images/accountpictures/" . $picture) ;
				move_uploaded_file($_FILES["picture"]["tmp_name"],
    			"images/accountpictures/". $_FILES["picture"]["name"]);
			}
			else
			{
				move_uploaded_file($_FILES["picture"]["tmp_name"],
				"images/accountpictures/". $_FILES["picture"]["name"]);
			}
		}

	}		
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: PickmeFriends.com";
		
			$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
			$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
			$strHTML .= "<b>Email ID : </b>".$email."<br><br>";
			$strHTML .= "<a target = '_blank' href = 'http://pickmefriend.com/beta/registeruser.php?step=abc6def&id=$iid'><b>Please Click Here To Confirm your Registration</b></a>" ;
			$strHTML .= "</td></tr></table>";
			
			$strHTML = stripslashes($strHTML);	
			
		
			mail($email,"Confirm Your Registration",$strHTML,$headers);	
			
			
	?>
			<script language="javascript">
					window.location.href = 'registeruser.php?step=abc2def&id=<?php echo $iid ;?>' ;
			</script>
		
	<?php
	}
	
}



if($Action == 'TemporaryPassword')
{
	$temppass = $_POST['temppass'] ;
	$iid = $_POST['hid'] ;
	$query = mysql_query("select strtemppassword from tblmember_temp where iid = '".$iid."' ");
	while($data = mysql_fetch_array($query))
	{
		$temp = $data['strtemppassword'];
	}
	if($temppass == $temp)
	{
	
	?>
		<script language="javascript">
			window.location.href = 'registeruser.php?step=abc3def&id=<?php echo $iid ;?>' ;
		</script>
	<?php
	}
	else
	{
	$message = "Wrong password. Please try again." ;
	?>
		<script language="javascript">
			//var msg = "Wrong password. Please try again." ;
		window.location.href = 'registeruser.php?step=abc2def&id=<?php echo $iid ;?>' ;
		alert("Wrong password. Please try again.");
		//	window.opener.location.href = window.opener.location.href ;
		</script>
	<?php
	}
}

if($Action == 'RecoveryPassword')
{
	$recoverpass = $_POST['recoverpassword'] ;
	$iid = $_POST['hid'] ;
	$query = mysql_query("select strpasswordstring , iuid from tblrecovery where strtemporarystring = '".$iid."' ");
	while($data = mysql_fetch_array($query))
	{
		$recover = $data['strpasswordstring'];
		$iuserid = $data['iuid'];
	}
	if($recoverpass == $recover)
	{
	
	?>
		<script language="javascript">
			window.location.href = 'registeruser.php?step=abc3def&temp=<?php echo $iid ;?>&action2=Recover' ;
		</script>
	<?php
	}
	else
	{
	$message = "Wrong Entry. Please try again." ;
	?>
		<script language="javascript">
			//var msg = "Wrong password. Please try again." ;
		window.location.href = 'registeruser.php?step=abc5def&temp=<?php echo $iid ;?>&message=1' ;
		</script>
	<?php
	}
}		

if($Action == 'Password' && $_POST['action2'] != '')
{
	$password = $_POST['password'] ;
	$iid = $_POST['hid'] ;
	
	$tempquery4 = mysql_query("SELECT * FROM tblrecovery where strtemporarystring = '$iid'");
	$tempdata = mysql_fetch_array($tempquery4) ; 
	$iid = $tempdata['iuid'] ;
	$recoverid = $tempdata['iid'] ;
	$getcount = $tempdata['icount'] ;
	$totalcount = $getcount + 1 ;
	
	
//	$passwordquery1 = mysql_query("update tblmember set strpassword = '$password' where iid = '$iid'");	
	$passwordquery = mysql_query("select * from tblmember where iid = '$iid' ");
	$data = mysql_fetch_array($passwordquery) ; 
	$id = $data['iid'];
	$nname = $data['strnickname'] ;
	$email = $data['stremail'] ;
	
	$encpassword = $nname.$password ;
	$salt = 's+(_a*';
	$salt_pass = md5($encpassword.$salt);
	
	$passwordquery2 = mysql_query("update tblmember set strpassword = '$salt_pass' where iid = '$iid'");
	$recoverquery = mysql_query("update tblrecovery set strphase = 'true',icount = '$totalcount' where iid = '$recoverid'");	
	$_SESSION['userid'] = $id ;
	$_SESSION['loginid'] = $id ;
	$_SESSION['emailaddress'] = $email ;
?>
<script language="javascript">
	window.location.href = 'registeruser.php?step=abc4def' ;
</script>
<?php
}

if($Action == 'Password' && $_POST['action2'] == '')
{
	$password = $_POST['password'] ;
	//$password = md5($password);
		
	
	
	$iid = $_POST['hid'] ;
	
	$query = mysql_query("select * from tblmember_temp where strtemppassword = '".$iid."' ");
	$data = mysql_fetch_array($query) ;
		
	$fname = $data['strfirstname'] ;
	$nname = $data['strnickname'] ;
	$lname = $data['strlastname'] ;
	$company = $data['strcompany'] ;
	$email = $data['stremail'] ;
	$country = $data['strcountry'] ;
	$city = $data['strcity'] ;
	$address = $data['straddress'] ;
	$phone = $data['strphone'] ;
	$nativelang = $data['strnativelang'] ;
	$mangelang = $data['strmangedlang'] ;
	$date = $data['ddateofbirth'] ;
	$socialnetwork = $data['strsocialnetwork'] ;	
	$picture = $data['strpicture'] ;			
	
	
	$encpassword = $nname.$password ;
	$salt = 's+(_a*';
	$salt_pass = md5($encpassword.$salt);
	
	
	$ipaddress = findipaddress() ;
	
	$phasequery = mysql_query("Update tblmember_temp set strphase = 'true' where strtemppassword = '".$iid."'");
	
	// Check is this user existes in tblmember table
	$chkmailread = mysql_query("Select * From tblmember Where strnickname = '$nname' and stremail = '$email'");
	$chkmailrows = mysql_num_rows($chkmailread);
	if($chkmailrows > 0)
	{
		$chkmaildata = mysql_fetch_array($chkmailread);
		$iid = $chkmaildata['iid'] ;
		
		$query2 = mysql_query("Update tblmember set strfirstname = '$fname',strnickname = '$nname' , strlastname = '$lname',strcompany = '$company',stremail='$email',strcountry='$country',strcity='$city',straddress='$address',strphone='$phone',strnativelang='$nativelang',strmangedlang='$mangelang',ddateofbirth='$date',strsocialnetwork='$socialnetwork',strpassword='$salt_pass',strpicture='$picture',dtdatetime=NOW(),istatus='1',ipaddress='$ipaddress' Where iid = '$iid' " );
	}
	else
	{
			$query2 = mysql_query("insert into tblmember (strfirstname , strnickname ,strlastname , strcompany , stremail , strcountry , strcity , straddress , strphone , strnativelang , strmangedlang , ddateofbirth , strsocialnetwork , strpassword , strpicture,dtdatetime,istatus,ipaddress) values('$fname' , '$nname' ,'$lname' , '$company' , '$email' , '$country' , '$city' , '$address' , '$phone' , '$nativelang' , '$mangelang' , '$date' , '$socialnetwork' , '$salt_pass' , '$picture',NOW(),'1','$ipaddress')"); 
			

	
	
	
		$query3 = mysql_query("select max(iid) as iid from tblmember");
		$row = mysql_fetch_array($query3);
		$iid = $row['iid'];
	}	
	
		
	

	if($query2)
	{
		
		$query4 = mysql_query("select * from tblmember where iid = '$iid'");
		$object = mysql_fetch_object($query4);
					
			$userid = $object->iid ;
			$emailaddress = $object->stremail ;
			$_SESSION['userid'] = $userid ;
			$_SESSION['loginid'] = $userid ;
			$_SESSION['emailaddress'] = $emailaddress ;
			
		//$_SESSION['userid'] =  $iid ;
	?>
		<script language="javascript">
			
			//window.location.href = 'registeruser.php?step=4' ;
			window.location.href = 'main.php' ;
		</script>
	<?php
	}
	else
	{
	?>
		<script language="javascript">
			//var msg = "Error while registering user. Please try again." ;
			window.location.href = 'registeruser.php' ;
			alert("Error while registering user. Please try again.");
		</script>
	<?php
	}
	
}

?>