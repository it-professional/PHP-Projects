<?php  session_start() ;
include("checksession.php");

?>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<title>Marked Users</title>
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<table border="0"  cellpadding="0" cellspacing="0" width="100%">
<!--<tr>
<td height="10" bgcolor="#999999" class="redlink2" onclick="javascript: goback('<?php // echo $_GET['blink'] ;?>');" colspan="5">Go Back
</td>
</tr>-->
<?php if($_SESSION['Backlink1'] != '')  { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onclick="javascript: goback('<?php echo $_SESSION['Backlink1'] ;?>');"  colspan="5">Go Back
</td>
</tr><?php } ?>
<tr>
<td colspan="2" width="100%"  align="left" bgcolor="#CCCCCC" class="Heading"><font face="verdana" size="+1" color="#000000"><b>Marked Buyer's Information</b></font></td>
</tr>
<?php
include("include/config.php");
$productid = $_GET['PID'] ;
// Get the iid of product owner

$newuquery = mysql_query("select iuid from tblproducts where iid = '$productid'");
$ndat = mysql_fetch_array($newuquery);
$prodownerid = $ndat['iuid'];
//$userid  = $_SESSION['userid'] ;
$query1 = mysql_query("select distinct iuid  from tblmarkedproducts where ipid = '$productid'");
$rows = mysql_num_rows($query1);
if($rows > 0)
{
	while($data = mysql_fetch_array($query1))
	{
		$userid = $data['iuid'] ;
		
		$query3 = mysql_query("SELECT * FROM tblmember where iid = '$userid' ");
		if($query3)
		{
			while($data2 = mysql_fetch_array($query3))
			{
				$userid = $data2['iid'];
				$firstname = $data2['strfirstname'] ;
				$lastname = $data2['strlastname'] ;
				$nick = $data2['strnickname'] ;
				$email = $data2['stremail'] ;
				$address = $data2['straddress'] ;
				$phone = $data2['strphone'] ;
				$country = $data2['strcountry'] ;
				$city = $data2['strcity'] ;
				$picture = $data2['strpicture'] ;
				$ratingaverage = "" ;
				$rating =  0 ;
				$strrating = "" ;
				
				$ratingquery = mysql_query("select * from  tblrating where iratingto = '$userid' order by iid asc");
				$ratingrows = mysql_num_rows($ratingquery);
				if($ratingrows  > 0)
				{
					while($ratingdata = mysql_fetch_array($ratingquery))
					{
						$rating = $rating + $ratingdata['irating'] ;
						$ratingcomments = $ratingdata['strdescription'] ;
					}
					$ratingaverage2 = $rating / $ratingrows ;	
					$ratingaverage = number_format($ratingaverage2,2);
					$roundratingavg = round($ratingaverage);
					if($roundratingavg == 1)	
					{
						$strrating = "Horrible" ;
						$strimage = "horrible.gif" ;
					}
					else if($roundratingavg == 2)	
					{
						$strrating = "Bad" ;
						$strimage = "bad.gif" ;
					}
					else if($roundratingavg == 3)	
					{
						$strrating = "Poor" ;
						$strimage = "poor.gif" ;
					}
					else if($roundratingavg == 4)	
					{
						$strrating = "Below Average" ;
						$strimage = "belowavg.gif" ;
					}
					else if($roundratingavg == 5)	
					{
						$strrating = "Average" ;
						$strimage = "average.gif" ;
					}
					else if($roundratingavg == 6)	
					{
						$strrating = "Above Average" ;
						$strimage = "aboveavg.gif" ;
					}
					else if($roundratingavg == 7)	
					{
						$strrating = "Good" ;
						$strimage = "good.gif" ;
					}
					else if($roundratingavg == 8)	
					{
						$strrating = "Very Good" ;
						$strimage = "vgood.gif" ;
					}
					else if($roundratingavg == 9)	
					{
						$strrating = "Superb" ;
						$strimage = "superb.gif" ;
					}
					else if($roundratingavg == 10)	
					{
						$strrating = "Excellent" ;
						$strimage = "excellent.gif" ;
					}					
				}
				else
				{
					$strrating = "No Rated" ;
				}
							
?>
			<tr>
				<td style="padding-top:20px;">
					<table border="0" cellpadding="0" cellspacing="0">
						
						<tr>
							<td>
								<table border="0" cellpadding="0" cellspacing="0">
									<tr>
										<td class="Heading">
											Name:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php echo $firstname ;?>&nbsp;<?php echo $lastname ;?>
										</td>
									</tr>
									<tr>
										<td class="Heading">
											Nick:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php echo $nick ;?>
										</td>
									</tr>
									<tr>
										<td class="Heading">
											Address:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php echo $address ;?>
										</td>
									</tr>
									<tr>
										<td class="Heading">
											Phone:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php echo $phone ;?>
										</td>
									</tr>
									<tr>
										<td class="Heading">
											Country:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php echo $country ;?>
										</td>
									</tr>
									<tr>
										<td class="Heading">
											City:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php echo $city ;?>
										</td>
									</tr>
									<tr>
										<td class="Heading">
											Average Rating:
										</td>
										<td class="SubHeading" style="padding-left:25px;">
											<?php if($strimage !="") { ?><img  align="absmiddle" src="images/<?php echo $strimage ;?>" border="0" />&nbsp;<?php } ?><?php echo $ratingaverage." (".$strrating.") " ; ?>
										</td>
									</tr>
									<?php if($ratingaverage > 0) { ?>
									<tr><td class="bluelink" colspan="2" style="font-size:10px;" onClick="javascript: viewmarkeduserratingcomments('<?php echo $userid; ?>','<?php echo $productid ;?>')">View Rating Comments </td></tr><?php } ?>
									
								</table>
							</td>
							<?php if($picture != '') { ?>
							<td  align="right"  style="padding-left:50px;">
								<img align="absmiddle" src="images/accountpictures/<?php echo $picture ;?>" border="0" width="150" height="120" />
							</td>	
							</tr>
							<?php } else {?>
						
						</tr>
						<?php }?>
					</table>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td  align="center" class="Heading"><a class="bluelink" onclick="viewmarkedusermessages(<?php echo $productid ; ?>,<?php echo $userid; ?>,'Markedusers')">View Messages</a></td></tr>
			<tr><td><hr width="50%" /></td></tr>
			<tr><td>&nbsp;</td></tr>
			<?php
			}
			}
			}
			}
			?>


	
</table>