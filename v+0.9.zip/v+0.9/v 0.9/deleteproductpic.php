<?php
session_start();
include("checksession.php");
?>
<script language="javascript" type="text/javascript">

	function NewWindow(mypage,myname,w,h,scroll,resize)
		{
			w=w-50;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
		}


function editproduct(ival)
		{
			var msg = "Picture bas been deleted" ;
			NewWindow("editproduct.php?PID="+ival+"&message="+msg,"frmEditProperty",'600','900','Yes','No');		
		}
		
		
</script>		


<?php
include("include/config.php");
$iid = $_GET['id'] ;
$strqry = "select * from tblproducts where iid = '$iid'";
	$row = mysql_query( $strqry );
	$res = mysql_fetch_array ( $row );
	if($res["strpicture"] != "" )
	{
		$path = "images/productpictures/" . $res["strpicture"];
		$delete = unlink($path) ;
		if($delete)
		{
			$q = "UPDATE tblproducts SET strpicture = '' WHERE iid = '$iid'";
			$recordSet = mysql_query ($q);
?>
<script language="JavaScript">
var msg = "Picture has been deleted" ;
//window.location.href = "editaccount.php?message="+msg ;
editproduct(<?php echo $iid ; ?>) ;
//this.window.close() ;
</script>
<?php
			
		}	
	}
	else
	{		
?>
<script language="JavaScript">
var msg = "There is no Picture" ;
window.location.href = "editaccount.php?message="+msg ;
this.window.close() ;
</script>
<?php
}
?>