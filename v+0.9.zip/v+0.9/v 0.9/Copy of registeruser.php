<?php 
session_start();
include("include/config.php");
include("random.php");
?>
<?php if(!isset($_SESSION['userid']) || $_SESSION['userid'] == '') { ?>
<table width="100%" border="0" cellpadding="0"  cellspacing="0">
<tr>
<td id="tdindexmain">
<?php
include("include/template.php");
templateheader("" , "false");
?>
<html>
<head>
<title> Register Your Account </title>
<style>
form div.captcha {
  width: 200px;
  margin-left: 1px;
 }
</style>
<script type="text/javascript" language="javascript" src="include/js/md5.js"></script>
<script type="text/javascript" language="javascript" src="include/js/jcap.js"></script>
   <link href="include/css/rfnet.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="include/js/datetimepicker_css.js"></script>
<script>

function required1()
{
	if(document.registerform.nick.value == '')
	{
		alert("Please Enter your Nick ");
		return false ;
		document.registerform.nick.focus() ;		
	}
	else if(document.registerform.email.value == '')
	{
		alert("Please Enter your Email Address");
		return false ;
		document.registerform.email.focus() ;		
	}
	
	else if (echeck(document.registerform.email.value)==false)
	{
		alert("Please enter Valid email address.");	
		return false;				
		document.registerform.email.focus();
		
	}
	else if(document.registerform.country.value == '')
	{
		alert("Please Enter your Country ");
		return false ;
		document.registerform.country.focus() ;		
	}
	else if(document.registerform.nlang.value == '')
	{
		alert("Please Enter your Native Language");
		return false ;
		document.registerform.nlang.focus() ;		
	}
	else if(document.registerform.socialnetwork.value == '')
	{
		alert("Please Select Most Used Social Network");
		return false ;
		document.registerform.socialnetwork.focus() ;		
	}
	else if(document.registerform.uword.value == '')
	{
		alert("Please Enter Verification Code");
		return false ;
		document.registerform.uword.focus() ;		
	}
	else if(!jcap())
	{
		  return false ;  
		  document.registerform.uword.focus() ;	
	}
	else
	{
		return true ;
	}
}

function echeck(str)
{
	var at="@"
	var dot="."
	var underscore="_"
	var lat=str.indexOf(at)
	var lstr=str.length
	var ldot=str.indexOf(dot)
	var lunderscore=str.indexOf(underscore)

	if (str.indexOf(at)==-1)
	{
	   //alert("Invalid E-mail ID")
	   return false
	}
		//check @ on start,end and its existance 
	if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr)
	{
	  //alert("Invalid E-mail ID")
	  return false
	}
			//check . on start,end and its existance		
	if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr)
	{
		return false
	}
	
	if (str.indexOf(underscore)==0 || str.indexOf(underscore)==lat-1 || str.indexOf(underscore)==lstr)
	{
		return false;
	}

	 return true					

}


function required2()
{
var temp = document.registerform2.temppass.value ;
if(temp == '')
{
alert("Please Enter Temporary Password that is email to you");
return false ;
document.registerform2.password.focus();
}
else
{
return true ;
}
}

function required5()
{
var temp = document.registerform5.recoverpassword.value ;
if(temp == '')
{
alert("Please Enter Password Recovery String that is email to you");
return false ;
document.registerform5.recoverpassword.focus();
}
else
{
return true ;
}
}


function required3()
{
var password = document.registerform3.password.value ;
var confirmpass = document.registerform3.cpassword.value ;

if(password == '')
{
alert("Please Enter Your Password");
return false ;
document.registerform3.password.focus();
}
else if(confirmpass == '')
{
alert("Please Confirm Your Password");
return false ;
document.registerform3.confirmpass.focus();
}

else if(confirmpass != password)
{
alert("Your Password and Confirm Password does not match.");
return false ;
document.registerform3.confirmpass.focus();
}
else
{
return true ;
}
}

function closewindow()
{
	this.window.close();
	window.location.href = "index.php" ;
}
</script>
<link href="include/css/css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">


<table width="600" align="center" border="0" cellpadding="0" cellspacing="0">
	
	<?php
	if(isset($_GET['message']))
	{
		$message = $_GET['message'] ;
		if($message == 1)
		{
			$message = "Invalid Password Recovery String." ;
		}	
	?>
	<tr><td>&nbsp;</td></tr>
	<tr><td class="redlink" colspan="2" align="center"><b><?php echo $message ;?></b></td></tr>
	<?php
	}
	?>
	<tr><td>&nbsp;</td></tr>
	<tr>
		<td   align="center" >
			<table cellpadding="0" align="center" width="72%" cellspacing="0" border="1"  style="border-color:#000000; border-style:solid">
				
				<tr>
					<td>
					<table border="0" cellpadding="0" cellspacing="0" width="100%">
						<tr>
							<td   height="28" bgcolor="#000000" colspan="2" ><font face="Trebuchet MS" size="2" color="#FFFFFF"  style="padding-left:10px;"><b>Register Your Account</b></font><span class="SubHeading"><b><font color="#FFFFFF" style="padding-left:15px;">  (* indicate required fields)</font></b></span></td>
						</tr>
					<?php 
					if(!isset($_GET['step']))
					{
					?>
						<form name="registerform" action="functions.php" method="post" enctype="multipart/form-data" >
						<tr><td>&nbsp;</td></tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Nick :</td>
							<td>
								<input type="text" id="nick" name="nick" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Email Address:</td>
							<td>
								<input type="text" id="email" name="email" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Country:</td>
							<td>
								<select name="country" id="country" style="width:205px;">
									<?php 
										$countryquery = mysql_query("SELECT * FROM tblcountries order by id");
										while($countrydata = mysql_fetch_array($countryquery))
										{
											$strcountry = $countrydata['country_name'] ;
									?>
									<option value="<?php echo $strcountry?>"><?php echo $strcountry ;?></option>
									<?php }?>
								</select>
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Native Language:</td>
							<td>
								<select name="nlang" id="nlang" style="width:205px;">
										<?php 
											$languagequery = mysql_query("SELECT * FROM tbllanguages order by iid");
											while($languagedata = mysql_fetch_array($languagequery))
											{
												$strnativelanguage = $languagedata['language_name'] ;
										?>
										<option value="<?php echo $strnativelanguage?>" <?php if($strnativelanguage == "English") { ?> selected="selected" <?php }?>><?php echo $strnativelanguage ;?></option>
										<?php }?>
										</select>
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Most Used Social Network:</td>
							<td>
								<select id="socialnetwork" name="socialnetwork"  style="width:205px;">
									<option value="facebook">Face Book</option>
									<option value="myspace">My Space</option>
									<option value="twitter">Twitter</option>
									<option value="youtube">You Tube</option>
									<option value="google">Google</option>
									<option value="yahoo">Yahoo</option>
									<option value="squidoo">Squidoo</option>
									<option value="bloglines">Bloglines</option>
									<option value="google">other</option>
									
								</select>
							</td>
						</tr>
						
						
						<tr>
							<td>&nbsp;</td>
							<td class="content" >
								<div class="captcha">
									<script language="javascript" type="text/javascript">
										cimg() ;
									</script>
									<noscript>[This resource requires a Javascript enabled browser.]</noscript>
								</div>
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;"  class="Heading">
								*Verification Code:
							</td>
							<td style="padding-top:5px; padding-left:5px;">
								<input name="uword" id="uword" size="30" maxlength="25"  type="text" >
							</td>
						</tr>
						<tr>
						<td colspan="2" align="center" style="padding-top:20px;" bgcolor="">
						<input type="submit" name="submit" value=" OK " class="Heading"      onClick="return required1()">
						<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">
						</td>
						</tr>
				<input type="hidden" name="action" value="Registration">
				</form>
			<?php
			}
			include("include/config.php");
			if(isset($_GET['step']) && $_GET['step'] == 'abc2def')
			{
				$iid = $_GET['temp'] ;
				$query = mysql_query("select stremail from tblmember_temp where strtemppassword = '".$iid."' ");
				while($data = mysql_fetch_array($query))
				{
					$emailaddress = $data['stremail'];
				}
				
			?>
			<tr>
				<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> You are Successfully Registered. To confirm your registration. Plz chk your email.</td>
			</tr>
			<tr>
				<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> An Email is send at the below address.</td>
			</tr>
			<tr>
				<td colspan="2" class="Heading" align="center"><?php echo $emailaddress ; ?></td>
			</tr>
			
			
			<tr><td>&nbsp;</td></tr>
			
			<?php
			}
			if(isset($_GET['step']) && $_GET['step'] == 'abc5def')
			{
				$iid = $_GET['temp'] ;
				// Chk is this user receive email and recover his password
				$chkquery = mysql_query("Select strphase From tblrecovery Where strtemporarystring = '$iid'");
				$chkrows = mysql_num_rows($chkquery) ;
				if($chkrows > 0)
				{
					$chkdata = mysql_fetch_array($chkquery);
					$chkphase = $chkdata['strphase'] ;
					if($chkphase == "false")
					{
						$query = mysql_query("select iuid from tblrecovery where strtemporarystring = '".$iid."' ");
						$data = mysql_fetch_array($query);
						$userid = $data['iuid'];
						
						$query2 = mysql_query("select stremail from tblmember where iid = '".$userid."' ");
						$data2 = mysql_fetch_array($query2);
						$emailaddress = $data2['stremail'];
					
			?>
					<form name="registerform5" action="functions.php" method="post">
					<tr>
						<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> To Recover your account, your address is being verified.  An email was just sent to:</td>
					</tr>
					<tr>
						<td colspan="2" class="Heading" align="center"><?php echo $emailaddress ; ?></td>
					</tr>
					
					<tr><td>&nbsp;</td></tr>
					<tr><td colspan="2" class="SubHeading" style="padding:10px;" align="center">Please enter Password Recovery String.</td></tr>
					<tr>
						<td style="padding-left:10px; " class="Heading">*Password Recovery String</td>
						<td><input id="recoverpassword" type="password" name="recoverpassword" size="30">
							<input type="hidden" name="action" value="RecoveryPassword">
							<input type="hidden" name="hid" value="<?php echo $iid ;?>">
							
						</td>
					</tr>
					
					<tr>
						<td colspan="2" style="padding-left:10px; padding-top:20px;" align="center">
							
							<input type="submit" name="submit" value=" OK " class="Heading"      onClick="return required5()">
								<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">
						</td>
					</tr>
					<tr><td>&nbsp;</td></tr>
					</form>
			<?php
				}
				else
				{
				?>
				<tr>
						<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> You have already Recover Password using this Password Recovery String.</td>
				</tr>
				<tr>
						<td colspan="2" class="SubHeading" style="padding:10px;" align="center">If you again forgot your password. You can recover it using Forgot Password Link or <a href="forgot.php"  class="bluelink">Click here to go to Forgot Password link.</a></td>
				</tr>
				<?php
				}
			}
			else
			{
			?>
				<tr>
					<td colspan="2" class="redlink" style="padding:10px;" align="center">Wrong URL</td>
				</tr>
				<tr>
						<td colspan="2" class="SubHeading" style="padding:10px;" align="center">If you again forgot your password. You can recover it using Forgot Password Link or <a href="forgot.php"  class="bluelink">Click here to go to Forgot Password link.</a></td>
				</tr>
			<?php
			}
		}		
			
			if(isset($_GET['step']) && $_GET['step'] == 'abc3def')
			{
				$iid = $_GET['temp'] ;
			?>
			<form name="registerform3" action="functions.php" method="post">
			<tr>
				<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> Please enter your permanent password below. that will be used when you Login. </td>
			</tr>
			
			
			<tr><td>&nbsp;</td></tr>
			<tr><td colspan="2" align="center" ></td></tr>
			<tr><td>&nbsp;</td></tr>
			
			<tr>
				<td class="Heading" style="padding-left:15px;">*Password</td>
				<td>
					<input  type="password" name="password" size="30">
				
				</td>
			</tr>
			<tr>
				<td class="Heading" style="padding-left:15px;" >*Confirm Password</td>
				<td style="padding-top:8px;">
					<input  type="password" name="cpassword" size="30">
				
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td colspan="2" style="padding-left:10px; padding-top:20px;" align="center">
					<input type="hidden" name="action" value="Password">
					<?php if(isset($_GET['action2']) && $_GET['action2'] != "") { ?>
					<input type="hidden" name="action2" value="<?php echo $_GET['action2'] ;?>">
					<?php } else { ?>
					<input type="hidden" name="action2" value="">
					<?php } ?>
					
					<input type="hidden" name="hid" value="<?php echo $iid ;?>">
						
					<input type="submit" name="submit" value=" OK " class="Heading"      onClick="return required3()">
					<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">
				</td>
			</tr>
			</form>
			
			<?php
			}
			if(isset($_GET['step']) && $_GET['step'] == 'abc6def')
			{
				$iid = $_GET['temp'] ;
				$chkquery = mysql_query("Select strphase From tblmember_temp Where strtemppassword = '$iid'");
				$chkrows = mysql_num_rows($chkquery);
				if($chkrows > 0)
				{
					$chkdata = mysql_fetch_array($chkquery);
					$chkphase = $chkdata['strphase'] ;
					if($chkphase == "false" || $chkphase == "NULL" || $chkphase == "")
					{	
			?>
				<form name="registerform3" action="functions.php" method="post">
				<tr>
					<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> Please enter your permanent password below. that will be used when you Login. </td>
				</tr>
				
				
				<tr><td>&nbsp;</td></tr>
				<tr><td colspan="2" align="center" ></td></tr>
				<tr><td>&nbsp;</td></tr>
				
				<tr>
					<td class="Heading" style="padding-left:15px;">*Password</td>
					<td>
						<input  type="password" name="password" size="30">
					
					</td>
				</tr>
				<tr>
					<td class="Heading" style="padding-left:15px;" >*Confirm Password</td>
					<td style="padding-top:8px;">
						<input  type="password" name="cpassword" size="30">
					
					</td>
				</tr>
				<tr><td>&nbsp;</td></tr>
				<tr>
					<td colspan="2" style="padding-left:10px; padding-top:20px;" align="center">
						<input type="hidden" name="action" value="Password">
						<?php if(isset($_GET['action2']) && $_GET['action2'] != "") { ?>
						<input type="hidden" name="action2" value="<?php echo $_GET['action2'] ;?>">
						<?php } else { ?>
						<input type="hidden" name="action2" value="">
						<?php } ?>
						
						<input type="hidden" name="hid" value="<?php echo $iid ;?>">
							
						<input type="submit" name="submit" value=" OK " class="Heading"      onClick="return required3()">
						<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">
					</td>
				</tr>
				</form>
			<?
				}
				else
				{
				?>
				<tr>
					<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> You have already Confirm your registration.</td>
				</tr>
				<tr>
					<td colspan="2" class="SubHeading" style="padding:10px;" align="center">Now you can <a href="login.php" class="bluelink">Login</a> or again <a href="registeruser.php" class="bluelink">Register your account.</a> </td>
				</tr>
				<?php
				}
			}
			else
			{
			?>
				<tr>
					<td colspan="2" class="redlink" style="padding:10px;" align="center"> No Registration Confirmation. </td>
				</tr>
				<tr>
					<td colspan="2" class="SubHeading" style="padding:10px;" align="center">Now you can <a href="login.php" class="bluelink">Login</a> or again <a href="registeruser.php" class="bluelink">Register your account.</a> </td>
				</tr>
			<?php
			}	
		}
			if(isset($_GET['step']) && $_GET['step'] == 'abc4def')
			{
			?>	
			<form name="registerform3" action="main.php" method="post">
			<tr>
				<td colspan="2" class="SubHeading">
				 	You now have FULL access to all of the site's advanced features!
				 </td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td colspan="2" class="Heading" align="center">
				 	Welcome to our site.
				 </td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td class="SubHeading">
					To go back to where you were, click the button below. 
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td colspan="2" style="padding-left:10px; padding-top:20px;" align="center">
					<input type="submit" name="ok" value=" Continue " class="Heading">
				</td>
			</tr>
			</form>
			<?php
			}
			?>
			</table>
		</td>
	</tr>
	</table>
	</td>
</tr>
	
	<tr>
		<td >&nbsp;</td>
	</tr>
	
	
</table>		

</body>
</html>

<?php templatefooter("" , "false"); ?>
</td>
</tr>
</table>
<?php } else { ?>
<script language="javascript" type="text/javascript">
	window.location.href = "index.php" ;
</script>
<?php } ?>