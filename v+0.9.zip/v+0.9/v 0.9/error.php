<?php
session_start();
include("random.php");

if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
{
include("login.php");
}
else
{	

include("include/config.php");
//include("include/template.php");
//templateheader("" , "true");
$getproductid = $_GET['ipid'] ;
$productid = decryptId($getproductid,'ABCDZYX0987654321JUI200789');
//echo $productid ;
// Get the product ownere id
$query = mysql_query("select iuid from tblproducts where iid = '$productid' ");
$data = mysql_fetch_array($query);
$productownerid = $data['iuid'];

// Set the flag = 1 of seller.	
$flagquery = mysql_query("UPDATE tblmember SET iflag = 1 WHERE  iid = '$productownerid'");

// Get Email Address of Seller to send email
$mailquery = mysql_query("select stremail , strnickname from tblmember where iid = '$productownerid'");
$maildata = mysql_fetch_array($mailquery);
$receiveremailid = $maildata['stremail'] ;
$nickname = $maildata['strnickname'] ;

// Write Email Html For Seller
$headers = "MIME-Version: 1.0\r\n";  
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: PickmeFriend.com";

$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
$strHTML .= "Your Paypal Email Address is not valid. Please Confirm your Paypal Email Address as soon as possible. <br>";
$strHTML .= "Some one want to Purchase your product.<br>";
$strHTML .= "</td></tr></table>";
	
$strHTML = stripslashes($strHTML);	
mail($receiveremailid,"Transaction Failed.",$strHTML,$headers);

// Write Email Html For Admin
$strHTML2 = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
$strHTML2 .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
$strHTML2 .= "Paypal Email Address of ".$nickname." is not valid. So Transaction cannot be Completed.<br>";
$strHTML2 .= "<br>";
$strHTML2 .= "</td></tr></table>";

$strHTML2 = stripslashes($strHTML2);	
mail("failuretransaction@pickmefriend.com","Transaction Failed.",$strHTML2,$headers);
}
?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="redlink"  align="center">
			There is some error to Complete Your Transaction at this time. Please try later.
		</td>
	</tr>
</table>



<?php
//templatefooter("" , "true");
?>