<?php session_start() ;
include("checksession.php");
$_SESSION['PID'] = $_GET['PID'] ;
?>
<title> Product Detail </title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table cellpadding="0" cellspacing="0" border="0" width="100%" >
<?php if($_SESSION['Backlink1'] == "buy.php" ) 
{
	$backscrolllinkid = $_GET['backscrolllink'] ;
	$backexternalscrolllinkid = $_GET['externalbackscroll'] ;
    $_SESSION['Backlink1'] = "buy.php?ysroll=$backscrolllinkid&externalbackscrolllink=$backexternalscrolllinkid" ?>
<tr>
<td height="10" bgcolor="#999999" width="100%" align="center"><a  class="redlink2" onclick="javascript: goback('<?php echo $_SESSION['Backlink1'] ;?>');"  colspan="5">Go Back</a>
</td>
</tr><?php } else { ?>
<tr>
<td height="10" bgcolor="#999999" width="100%" align="center"><a  class="redlink2" onclick="javascript: goback('<?php echo $_SESSION['Backlink1'] ;?>');"  colspan="5">Go Back</a>
</td>
</tr>
<?php }?>
<?php
include("include/config.php");
$query = mysql_query("select * from tblproducts where iid = '".$_GET['PID']."'");
while($data = mysql_fetch_array($query))
{
	$productid = $data['iid'];
	$productname = $data['strproductname'] ;
	$productprice2 = $data['iproductprice'] ;
	$productprice = number_format($productprice2,2);
	$other = $data['strother'];
	$otherdesc = $data['strotherdesc'];	
	$otherdesc  = html_entity_decode($otherdesc);
	//$otherdesc = stripslashes($otherdesc);
	$picture = $data['strpicture'];
	$productowner = $data['iuid'];
	
	$userquery = mysql_query("select strnickname from tblmember where iid = '$productowner'");
	$userdata = mysql_fetch_array($userquery);
	$ownernick = $userdata['strnickname'] ;	
}
?>
 <tr>
		<td colspan="2" width="100%"  align="left" bgcolor="#CCCCCC" class="Heading"><font face="verdana" size="2" color="#000000"><?php echo $productname; ?>&nbsp; Detail</font></td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Nick: </b><a   style="cursor:pointer;" onclick="javascript: viewrating('<?php echo $productid ; ?>');" class="bluelink"><?php echo $ownernick; ?></a>
	</td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<?php if($picture != '') { ?>
<tr>
	<td colspan="2"  align="left"  class="Heading">
		<b>Picture</b>
	</td>
</tr>
<tr>	
	<td colspan="2"  align="center"  >
	<img src="images/productpictures/<?php echo $picture ?>" border="0" width="120" height="80" />
	</td>
</tr>
<?php } ?>
 <tr>
		<td colspan="2"  align="left"  class="Heading"><b>Characteristics</b></td>
</tr>

</table>
<table cellpadding="0" cellspacing="0" border="0" style="padding-top:12px;" >

<?php
$query2 = mysql_query("select * from tblproductfeatures where ipid = '".$_GET['PID']."' order by iid asc");
while($data2 = mysql_fetch_array($query2))
{
	$characteristicid = $data2['icharid'] ;
	$attributeid = $data2['iatrid'] ;
	
	$query3 = mysql_query("select * from tblproductcharacteristics where ipchid = '$characteristicid'  order by ipchid asc");
	while($data = mysql_fetch_array($query3))
	{
		$characteristics = $data['strcharacteristicsname'] ;
	?>
	<tr>
		<td class="SubHeading">
		 <b><?php echo $characteristics ?>:</b>
		</td>
	
<?php	
	$query4 = mysql_query("select * from tblproductattributes where iid = '$attributeid' ");
	while($data2 = mysql_fetch_array($query4))
	{
		
		$attribute = $data2['strattribute'] ;	
	?>
		<td  class="SubHeading">
			<?php echo $attribute ;?>
		</td>
			
	<?php
	}
	?>
	</tr>
	<?php
	}

}

?>

<tr>
	<td class="Heading">
		Other:
	</td>
	<td class="SubHeading">
	<?php echo $other?>
	</td>
</tr>

<tr style="padding-top:8px;">
	<td class="Heading">
		<b>Product Price:</b>
	</td>
	<td class="SubHeading">
		<?php echo "$".$productprice ;?>
	</td>

</tr>

<tr style="padding-top:10px;">
	<td class="Heading" colspan="2">
		<b>Description:</b>
	</td>

</tr>
<tr>
	
		<td class="SubHeading" align="left" colspan="2">
			<?php echo $otherdesc ;?>
		</td>
	
</tr>
<tr><td>&nbsp;</td></tr>

<?php
$checkreportabusequery = mysql_query("SELECT * FROM tblreportabuses WHERE ifromid = '".$_SESSION['loginid']."'");
$chkabuserows = mysql_num_rows($checkreportabusequery) ;
if($chkabuserows > 0)
{
?>
<tr><td ><a class="bluelink" onclick="javascript: alert('You have already submit report abuse against this product.');">Report Abuse</a></td></tr>
<?php } else { ?>
<tr><td ><a class="bluelink" href="main.php?pg=reportabuse.php&PID=<?php echo $_GET['PID'] ;?>">Report Abuse</a></td></tr>
<?php }?>
</table>