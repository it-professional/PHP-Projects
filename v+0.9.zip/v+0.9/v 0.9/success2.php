<?php
session_start();
include("include/config.php");
include("include/configvariables.php");
include("include/template.php");
// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-synch';

$tx_token = $_GET['tx'];
//$auth_token = "CoPkscHDqYIRMvf17Rpmk99IMn7LZEZNCVHwrXBiI8PVF6vQgH-8SC-3kTu" ;
//$auth_token = "27au9wPHQaZ7YlZ5WHojxWIaz9bCnVaKBPCnU9XumpFQr4AnBnHodQ03Cmq" ;
$req .= "&tx=$tx_token&at=$auth_token";

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('www.sandbox.paypal.com', 80, $errno, $errstr, 30);
// If possible, securely post back to paypal using HTTPS
// Your PHP server will need to be SSL enabled
// $fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

if (!$fp) {
// HTTP ERROR
} else {
fputs ($fp, $header . $req);
// read the body data
$res = '';
$headerdone = false;
while (!feof($fp)) {
$line = fgets ($fp, 1024);
if (strcmp($line, "\r\n") == 0) {
// read the header
$headerdone = true;
}
else if ($headerdone)
{
// header has been read. now read the contents
$res .= $line;
}
}

// parse the data
$lines = explode("\n", $res);
$keyarray = array();
if (strcmp ($lines[0], "SUCCESS") == 0) {
for ($i=1; $i<count($lines);$i++){
list($key,$val) = explode("=", $lines[$i]);
$keyarray[urldecode($key)] = urldecode($val);
}
// check the payment_status is Completed
// check that txn_id has not been previously processed
// check that receiver_email is your Primary PayPal email
// check that payment_amount/payment_currency are correct
// process payment
$firstname = $keyarray['first_name'];
$lastname = $keyarray['last_name'];
$itemname = $keyarray['item_name'];
$amount = $keyarray['payment_gross'];
$commissionid = $keyarray['item_number'];
//$buyeremail = $keyarray['payer_email'] ; 
$date = date("Y-m-d");
$beforedays  = mktime(0, 0, 0, date("m")  , date("d")-5, date("Y"));
$duedate = date("Y-m-d" , $beforedays);

$chkcommissionquery = mysql_query("Select * From tblcommission WHERE iid = '$commissionid'");
$chkcommissionrows = mysql_num_rows($chkcommissionquery);
if($chkcommissionrows > 0)
{
		$bought = mysql_fetch_array($chkcommissionquery) ;
		$sellerid =  $bought['isellerid'];
		$chkstatus =  $bought['istatus'];
		
		if($chkstatus == 0)
		{
			mysql_query("UPDATE tblcommission SET istatus = '1' WHERE iid = '$commissionid'");
			mysql_query("UPDATE tblmember SET istatus = '1' WHERE iid = '$sellerid'");
			
			// GET Seller Email Id To Send Email.
			$mailquery2 = mysql_query("select * from tblmember where iid = '$sellerid'");
			$maildata2 = mysql_fetch_array($mailquery2);
			$selleremailid = $maildata2['stremail'] ;
			
			$headers = "MIME-Version: 1.0\r\n";  
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: PickmeFriend.com";
			
			$strHTML = global_commissionpaid_message($amount) ;
					
			$strHTML = stripslashes($strHTML);	
			
	//		mail($selleremailid,"Commission Paid",$strHTML,$headers);
	//		mail("commission@pickmefriend.com","Commission Paid",$strHTML,$headers);
?>


	<?php
	if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
	{
		include("login.php");
	}
	else
	{	
		
		templateheader("" , "true");
	
		$_SESSION['userid'] = $sellerid ;
		$_SESSION['loginid'] = $sellerid ;
		$_SESSION['emailaddress'] = $selleremailid ;
	
	?>
		<script language="javascript">
		window.location.href = "main.php?pg=commission.php" ;
		</script>
<?php
}
}
else
{	
	if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
	{
		include("login.php");
	}
	else
	{	
		templateheader("" , "true");
		echo ("<p align='center' style='width:100%'><h3><font color='#FF0000'>Commission Already Paid.</font></h3></p>");
	}	
}
}
else
{
	if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
	{
		include("login.php");
	}
	else
	{	
		templateheader("" , "true");
		echo ("<p align='center' style='width:100%'><h3><font color='#FF0000'>There is no Commission against this Transaction.</font></h3></p>");
	}	
}





}
else if (strcmp ($lines[0], "FAIL") == 0) {
// log for manual investigation
}

}

fclose ($fp);

?>


<?php
templatefooter("" , "true");
?>