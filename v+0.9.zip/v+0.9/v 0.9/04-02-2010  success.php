<?php
session_start();

if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
{
include("login.php");
}
else
{	
	
include("include/template.php");
templateheader("" , "true");
}

// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-synch';

$tx_token = $_GET['tx'];
$auth_token = "lC2DgRg3gOEwCeEu0Fk7v7a-nekUOvS-UYW8qpZBf1aldQ_VCKV6hrzGmL8" ;
$req .= "&tx=$tx_token&at=$auth_token";

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('www.sandbox.paypal.com', 80, $errno, $errstr, 30);
// If possible, securely post back to paypal using HTTPS
// Your PHP server will need to be SSL enabled
// $fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

if (!$fp) {
// HTTP ERROR
} else {
fputs ($fp, $header . $req);
// read the body data
$res = '';
$headerdone = false;
while (!feof($fp)) {
$line = fgets ($fp, 1024);
if (strcmp($line, "\r\n") == 0) {
// read the header
$headerdone = true;
}
else if ($headerdone)
{
// header has been read. now read the contents
$res .= $line;
}
}

// parse the data
$lines = explode("\n", $res);
$keyarray = array();
if (strcmp ($lines[0], "SUCCESS") == 0) {
for ($i=1; $i<count($lines);$i++){
list($key,$val) = explode("=", $lines[$i]);
$keyarray[urldecode($key)] = urldecode($val);
}
// check the payment_status is Completed
// check that txn_id has not been previously processed
// check that receiver_email is your Primary PayPal email
// check that payment_amount/payment_currency are correct
// process payment
$firstname = $keyarray['first_name'];
$lastname = $keyarray['last_name'];
$amount = $keyarray['payment_gross'];
$productid = $keyarray['item_number'];
$buyeremail = $keyarray['payer_email'] ; 
$date = date("y-m-d");
$beforedays  = mktime(0, 0, 0, date("m")  , date("d")+5, date("Y"));
$duedate = date("Y-m-d" , $beforedays);

include("include/config.php");
$query2 = mysql_query("SELECT * FROM tblproducts WHERE iid = '$productid'");
$data = mysql_fetch_array($query2);
$proddesc = $data['strotherdesc'] ;
$productownerid = $data['iuid'] ;
 $itemname = $data['strproductname'] ;


$query1 = mysql_query("INSERT INTO tblboughtproducts (ipid,ibuyerid,isellerid,istatus,ddate) VALUES('$productid','".$_SESSION['loginid']."','$productownerid',1,'$date')");
if($query1)
{
	// Update this bought product from Marked Products.	
	mysql_query("UPDATE tblmarkedproducts set bactive = 0 WHERE ipid = '$productid' AND iuid = '".$_SESSION['loginid']."'");
	
	$mailquery2 = mysql_query("select stremail from tblmember where iid = '$productownerid'");
	$maildata2 = mysql_fetch_array($mailquery2);
	$productowneremail = $maildata2['stremail'] ;
	
	$mailquery3 = mysql_query("select stremail from tblmember where iid = '".$_SESSION['loginid']."'");
	$maildata3 = mysql_fetch_array($mailquery3);
	$productbuyeremail = $maildata3['stremail'] ;
	
	$headers = "MIME-Version: 1.0\r\n";  
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: voskysinteractivepaypal@mail.com";
	
	$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
	$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
	$strHTML .= "<b>Your transaction has been completed</b><br><br>";
	$strHTML .= "<b>Payment Details</b><br>";
	$strHTML .= "<b>Product: </b>".$itemname."<br>";
	$strHTML .= "<b>Amount: </b>".$amount."<br>";
	$strHTML .= "<b>Description: </b>".$proddesc."<br><br>";
	$strHTML .= "</td></tr></table>";
		
	$strHTML = stripslashes($strHTML);	
	
	mail($productbuyeremail,"New Transaction Completed Successfully",$strHTML,$headers);
	mail($productowneremail,"New Transaction Completed Successfully",$strHTML,$headers);
	mail("admin@voskysinteractive.com","New Transaction Completed Successfully",$strHTML,$headers);
	
	
	$percentofproduct = ($amount/100)*10 ;
	
	$commissionquery = mysql_query("INSERT INTO tblcommission(isellerid,ipid,iproductamount,icommission,ddate,dduedate,istatus) VALUES('$productownerid','$productid','$amount','$percentofproduct','$date','$duedate','0')");
	if($commissionquery)
	{
		$headers2 = "MIME-Version: 1.0\r\n";  
		$headers2 .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers2 .= "From: voskysinteractivepaypal@mail.com";
		
		$strHTML2 = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
		$strHTML2 .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
		$strHTML2 .= "<b>Your transaction has been completed. And now according to agreement you have to pay the 10% to the site.</b><br><br>";
		$strHTML2 .= "<b>Payment Details</b><br>";
		$strHTML2 .= "<b>Product: </b>".$itemname."<br>";
		$strHTML2 .= "<b>Amount: $</b>".$amount."<br>";
		$strHTML2 .= "<b>10% of Amount: $</b>".$percentofproduct."<br><br>";
		$strHTML2 .= "<b>So Now you have to pay $".$percentofproduct."</b><br><br>";
		$strHTML2 .= "<b>Due Date :".$duedate."</b><br><br>";
		$strHTML2 .= "<b>After Due Date you will be bann. to sell or buy your product.</b><br><br>";
		$strHTML2 .= "</td></tr></table>";
		
		mail($productowneremail,"Remember Transaction Completed Agreement.",$strHTML2,$headers2);
	}	

?>
<script language="javascript">
window.location.href = "main.php?pg=boughtproducts.php" ;
</script>
<?php
}
else
{	
	echo ("<p><h3>There is some error to complete your transaction.</h3></p>");
}





}
else if (strcmp ($lines[0], "FAIL") == 0) {
echo "Payment has been done. But there is no insertion in database. Becouse IPN address is not valid" ;
// log for manual investigation
}


}

fclose ($fp);

?>


<?php
templatefooter("" , "true");
?>