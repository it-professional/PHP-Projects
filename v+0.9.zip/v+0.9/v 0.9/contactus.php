<?php session_start(); 
?>
<table width="100%" border="0" cellpadding="0"  cellspacing="0">
<tr>
<td id="tdindexmain">
<?php
include("include/template.php");
templateheader("" , "true");
?>
<?php
include("include/config.php");
$message = "" ;
if(isset($_POST['comments']) && $_POST['comments'] != "")
{
	$cname = $_POST['cname'] ;
	$cemail = $_POST['cemail'] ;
	$cphone = $_POST['cphone'] ;
	$comments = $_POST['comments'] ;
	$picture = $_FILES['picture']['name'] ;
	$todaydate = date("Y-m-d");
	
	$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
	$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
	$strHTML .= "<b>Name : </b>".$cname."<br>";
	$strHTML .= "<b>Email ID : </b>".$cemail."<br>";		
	$strHTML .= "<b>Contact No. : </b>".$cphone. "<br>";
	$strHTML .= "<b>Comments : </b>".$comments."<br>" ;
	$strHTML .= "</td></tr></table>";
	
	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: PickmeFriend.com";
			
	$strHTML = stripslashes($strHTML);	
		$email = "true" ;
		$sqlinsetionquery = "" ;
		if($_FILES['picture']['error'] <= 0)
		{
			
			if( ($_FILES["picture"]["type"] == "image/gif" || $_FILES["picture"]["type"] == "image/jpg" || $_FILES["picture"]["type"] ==  "image/jpeg"))
			{
					$randomnumer = rand();	
					$strpicturename = "ContactUs_".$randomnumer."_".$_FILES["picture"]["name"] ;			
					move_uploaded_file($_FILES["picture"]["tmp_name"],
					"images/ContactUsPic/".$strpicturename);
					$sqlinsetionquery ="INSERT INTO tblcontactus(strname,stremail,strphoneno,strcomments,strpicture,ddate) VALUES('$cname','$cemail','$cphone','$comments','$strpicturename','$todaydate')" ;
			}
			else
			{
				$sqlinsetionquery = "" ;
				$message = "Only JPG and GIF Images are allowed" ;
			}
	
		}
		else
		{
			$sqlinsetionquery ="INSERT INTO tblcontactus(strname,stremail,strphoneno,strcomments,ddate) VALUES('$cname','$cemail','$cphone','$comments','$todaydate')" ;
		}
		
		
		if($sqlinsetionquery != "")
		{
			$executequery = mysql_query($sqlinsetionquery) ;
			if($executequery)
			{
				//$email = mail("aamirrasheed143@gmail.com","Contact us information",$strHTML,$headers);
				$email = mail("contactpage@pickmefriend.com","Contact us information",$strHTML,$headers);
				$message = "We have received your query and we will contact you shortly." ;
			} 
			else
			{	
				$message = "There is somr error to submit your query so plz try again" ;
			}	
		}
			
		
}
?>
<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<script language="javascript">
function contactusrequired2()
{
	var nm = document.getElementById("cname").value ;
	var emid = document.getElementById("cemail").value ;
	var phone = document.getElementById("cphone").value ;
	var comments = document.getElementById("comments").value ;
	
if(document.getElementById("cname").value == "")
{
   alert("Please Enter Your Name");
   return false ;
  document.getElementById("cname").focus();
}
else if(document.getElementById("cemail").value == "")
{
   alert("Please Enter Your email address");
   return false ;
  document.getElementById("cemail").focus();
}
else if(document.getElementById("comments").value == "")
{
   alert("Please Enter Your Comments");
   return false ;
  document.getElementById("comments").focus();
}
else
{
	return true ;
}

}
</script>
<table  border="0" cellpadding="0" cellspacing="0" >
	<tr>
      <td align="left" valign="top"><table cellpadding="0" cellspacing="0" border="0">
	  <tr><td colspan="5" class="Heading">Contact Us</td></tr>
	  <tr><td>&nbsp;</td></tr>
	  <?php if($message != "") { ?>
	  	<tr><td class="redlink" height="50" colspan="2" align="center">
		<?php echo "<b>$message</b>" ; ?>
		</td></tr>
	  <?php } ?>
        <tr>
          <td width="99%" valign="top" style="padding-left:0" >
		  	 <tbody>
			 <form name="contactusform" method="post" action="contactus.php" enctype="multipart/form-data" onsubmit="return contactusrequired2()">
                <tr>
                  <td class="content"  style="width: 70px; text-align: left;">Name :</td>
                  <td style="padding-bottom:5px;"><input name="cname" id="cname" size="30" type="text" /></td>
                </tr>
				
                <tr>
                  <td class="content"  style="width: 70px; text-align: left;">Email :</td>
                  <td style="padding-bottom:5px;"><input name="cemail" id="cemail" size="30" type="text" /></td>
                </tr>
				
                <tr>
                  <td  class="content" style="width: 70px; text-align: left;">Contact  # :</td>
                  <td style="padding-bottom:5px;"><input name="cphone" id="cphone" size="30" type="text" /></td>
                </tr>
                <tr>
                  <td  class="content" style="width: 70px; text-align: left;" valign="top">Comments :</td>
                  <td style="padding-bottom:5px;"><label style="padding-bottom:5px;">
                    <textarea name="comments" id="comments" rows="5" cols="50"></textarea>
                  </label></td>
                </tr>
				 <tr>
                  <td  class="content" style="width: 70px; text-align: left; padding-bottom:5px;" valign="top">Your Picture :</td>
                  <td style="padding-bottom:5px;"><label style="padding-bottom:5px;">
                    <input type="file" name="picture" id="picture" />
                  </label></td>
                </tr>
				<tr><td>&nbsp;</td></tr>
                <tr>
                  <td style="text-align: center;">&nbsp;</td>
                  <td style="text-align: center;"><input name="submit" value="Submit" type="submit" />
                          <input name="reset" type="reset" value="Cancel" /></td>
                </tr>
				</form>
              </tbody>
			  
			  </td></tr></table>
		
	</td>
	</tr>
	</table>
	
	</td></tr></table>
<?php
templatefooter("" , "true");
?>			    