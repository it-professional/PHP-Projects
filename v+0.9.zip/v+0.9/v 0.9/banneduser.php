<?php
session_start();
//include("checksession.php");
?>
<table width="100%" border="0" cellpadding="0"  cellspacing="0">
<tr>
<td id="tdindexmain">
<?php
include("include/template.php");
templateheader("" , "false");
?>
<html>
<head>
<title> Pay Commission </title>

<link href="include/css/css.css" type="text/css" rel="stylesheet">
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<script language="javascript">
	function contactus()
	{
		window.location.href = "contactus.php" ;
	}
</script>
</head>
<body>

<table width="100%" cellpadding="0" cellspacing="0" >
	<tr>
		<td class="Heading" align="left">
			<h4 class="Heading" style="padding-left:10px;">Banned User</h4>
		</td>
	</tr>
	
	<tr>
		<td class="SubHeading" style="padding-left:10px;">
			You have been banned from site, please contact the site administrator using the contact page.
		</td>
	</tr>	
	<tr>
		<td class="SubHeading" style="padding-left:10px;">
			This page will automatic redirect in 5 seconds to the contact page.
		</td>
	</tr>	
	<script language='javascript'>
	setTimeout('contactus()', 5000);	
	</script>
</table>
<?php 
templatefooter("" , "false");
?>
</body></html>
