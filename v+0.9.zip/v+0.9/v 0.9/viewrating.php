<?php session_start() ;
include("checksession.php");
$pd = $_GET['PID'] ;
$_SESSION['Backlink'] = "viewproduct.php?PID=$pd" ;
?>
<title> Product Owner Detail </title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table cellpadding="0" cellspacing="0" border="0" width="100%" >
<?php //if($_GET['backlink'] == 'viewproduct.php')  {?>
<!--<tr>
<td height="10" bgcolor="#999999"  class="redlink2"  colspan="5"><a class="redlink2" style="text-decoration:none;" href="main.php?pg=viewproduct.php&PID=<?php //echo $_GET['PID']?>&backlink=--><?php //echo $_GET['backlink2']?><!--">Go Back</a>-->
<!--
</td>
</tr>-->
<?php //} else { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_SESSION['Backlink'] ;?>');"  colspan="5">Go Back
</td>
</tr><?php // } ?>
<?php
include("include/config.php");
$productid = $_GET['PID'] ; 
$query23 = mysql_query("select * from tblproducts where iid = '".$_GET['PID']."'");
$data23 = mysql_fetch_array($query23);
$productownerid = $data23['iuid'];


$userquery = mysql_query("select * from tblmember where iid = '$productownerid'");
$data = mysql_fetch_array($userquery);

$iid = $data['iid'];
$firstname = $data['strfirstname'] ;
$nickname = $data['strnickname'] ;
$lastname = $data['strlastname'] ;
$company = $data['strcompany'] ;
$country = $data['strcountry'] ;
$city = $data['strcity'] ;
$address = $data['straddress'] ;
$phone = $data['strphone'] ;
$nlang = $data['strnativelang'] ;
$Mlang = $data['strmangedlang'] ;
$socialnetwork = $data['strsocialnetwork'] ;
$rating = 0 ;
$ratingcomments = "" ;
$ratingquery = mysql_query("select * from  tblrating where iratingto = '$productownerid'");
$ratingrows = mysql_num_rows($ratingquery);
if($ratingrows  > 0)
{
	while($ratingdata = mysql_fetch_array($ratingquery))
	{
		$rating = $rating + $ratingdata['irating'] ;
		$ratingcomments = $ratingdata['strdescription'] ;
	}
	$ratingaverage2 = $rating / $ratingrows ;
	$ratingaverage = number_format($ratingaverage2,2);
	$roundratingavg = round($ratingaverage);
	
	if($roundratingavg == 1)	
	{
		$strrating = "Horrible" ;
		$strimage = "horrible.gif" ;
	}
	else if($roundratingavg == 2)	
	{
		$strrating = "Bad" ;
		$strimage = "bad.gif" ;
	}
	else if($roundratingavg == 3)	
	{
		$strrating = "Poor" ;
		$strimage = "poor.gif" ;
	}
	else if($roundratingavg == 4)	
	{
		$strrating = "Below Average" ;
		$strimage = "belowavg.gif" ;
	}
	else if($roundratingavg == 5)	
	{
		$strrating = "Average" ;
		$strimage = "average.gif" ;
	}
	else if($roundratingavg == 6)	
	{
		$strrating = "Above Average" ;
		$strimage = "aboveavg.gif" ;
	}
	else if($roundratingavg == 7)	
	{
		$strrating = "Good" ;
		$strimage = "good.gif" ;
	}
	else if($roundratingavg == 8)	
	{
		$strrating = "Very Good" ;
		$strimage = "vgood.gif" ;
	}
	else if($roundratingavg == 9)	
	{
		$strrating = "Superb" ;
		$strimage = "superb.gif" ;
	}
	else if($roundratingavg == 10)	
	{
		$strrating = "Excellent" ;
		$strimage = "excellent.gif" ;
	}
}
else
{
	$strrating = "No Rated" ;
}	


$warningquery = mysql_query("SELECT * FROM tblwarningmessages WHERE itoid = '$productownerid' order by iid desc");	
$warningrows = mysql_num_rows($warningquery);	
if($warningrows > 0)
{
	$wardingdata = mysql_fetch_array($warningquery) ;
	$strwarningmessage = $wardingdata['strmessage'] ;
}
else
{	
	$strwarningmessage = "" ;
}	

?>
 <tr>
		<td colspan="2" width="100%"  align="left" bgcolor="#CCCCCC" class="Heading"><font face="verdana" size="2" color="#000000"><?php echo $nickname; ?>&nbsp; Detail</font></td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Name: </b><?php echo $firstname."&nbsp;".$lastname ; ?>
	</td>
</tr>

<tr>
	<td class="SubHeading" colspan="2">
		<b>Company: </b><?php echo $company; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Country: </b><?php echo $country; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>City: </b><?php echo $city; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Address: </b><?php echo $address; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Phone No: </b><?php echo $phone; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Native Language: </b><?php echo $nlang; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Social Network: </b><?php echo $socialnetwork; ?>
	</td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>Average Rating: </b><?php if($strimage !="") { ?><img  align="absmiddle" src="images/<?php echo $strimage ;?>" border="0" />&nbsp;<?php } ?><?php echo $ratingaverage." (".$strrating.") " ; ?>
	</td>
</tr>

<?php /*if($ratingcomments != "") 
{ 
	if(strlen($ratingcomments)>=100)
	{
		if(!function_exists('str_split')) 
		{ 
			$ratingcommentsarray = str_split1($ratingcomments,100);
		}
		else
		{
			$ratingcommentsarray = str_split($ratingcomments,100);
		}	
	}*/
?>	
<!--<tr>
	<td class="SubHeading" colspan="2">
		<b>Rating Comments: </b>-->
<?php 		
/*if(strlen($ratingcomments)>=100)
{
	 echo $ratingcommentsarray[0]."&nbsp;...... " ;
}
else
{	
	 echo $ratingcomments ;
}	*/		
?>
	<!--</td>
</tr>-->
<?php //}?>
<?php if($roundratingavg >= 1) { ?>
<tr><td class="bluelink" colspan="2" style="font-size:10px;" onClick="javascript: viewbuyerratingcomments('<?php echo $productownerid; ?>')">View Rating Comments</td></tr>
<?php } ?>
<?php if($strwarningmessage != "") { ?>
<tr><td class="SubHeading" colspan="2" style="font-size:10px;"><b>Warning(s): </b><?php echo $strwarningmessage ;?></td></tr>
<tr><td class="bluelink" colspan="2" style="font-size:10px;" onClick="javascript: viewwarnings('<?php echo $productownerid; ?>')">View Warning(s) Detail</td></tr>
<?php }?>
</table>