<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<?php
include("include/config.php");
?>
<table border="0" cellpadding="0" cellspacing="0"  style="padding-left:10px;">

<?php	
$query = mysql_query("Select * from tblcontent where strPageName = 'TermsOfServices' ");
$rows = mysql_num_rows($query);
if($rows > 0)
{
	while($data = mysql_fetch_array($query))
	{
										
		$strPageName = $data['strPageName'] ;
		$strHeading = $data['strHeading'] ;
		$strsubheading = $data['strSubHeading'] ;
		$strContent = $data['strContent'] ;
		$strContent =html_entity_decode($strContent);
		$strpicture = $data['strPicture'] ;
									
?>

<?php if($strpicture != "") { ?>
<tr><td style="padding-left:15px" ><img src="admin/includes/images/<?php echo $strpicture?>" border="0"></td></tr>
<tr><td>&nbsp;</td></tr>
<?php }?>

<?php if($strHeading != "") { ?>
<tr><td class="Heading" style="padding-left:15px"><?php echo $strHeading?></td></tr>
<?php }?>

<?php if($strsubheading != "") { ?>
<tr><td class="subheading" class="" style="padding-left:15px"><?php echo $strsubheading ?></td></tr>
<?php }?>

<?php if($strContent != "") { ?>
<tr><td class="content" style="padding-left:15px"><?php echo $strContent ?></td></tr>
<tr><td>&nbsp;</td></tr>
<?php }?>

<?php
}
}
?>


</table>

