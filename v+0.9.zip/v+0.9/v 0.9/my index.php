<?php
session_start();
include("include/config.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home Page</title>
<link rel="shortcut icon" href="http://voskysinteractive.servehttp.com/beta/images/favicon.ico" />

<link href="include/css/css.css" type="text/css" rel="stylesheet" />
<link href="include/Newsscroller/scroller.css" rel="stylesheet" type="text/css" />
<script src="include/Newsscroller/scroller.js" language="javascript" type="text/javascript"></script>
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<script type="text/javascript" language="javascript" src="include/js/md5.js"></script>
<script type="text/javascript" language="javascript" src="include/js/jcap.js"></script>
   <link href="include/css/rfnet.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="include/js/datetimepicker_css.js"></script>
	<script language="JavaScript" type="text/javascript">
		
		
		function loginformchecking()
		{
			if(document.loginform.emailid.value == '')
			{
				alert("Please Enter Your Email");
				return false ;
				document.loginform.emailid.focus();				
			}
			else if(document.loginform.password.value == '')
			{
				alert("Please Enter Your Password");
				return false ;
				document.loginform.password.focus();				
			}
			else
			{
				return true ;
				//window.location.href = "login.php" ;
				document.loginform.submit();
				
			}
		}	 		
	</script>
<script language="javascript" type="text/javascript">
	
		function 	homepagecontent(page)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= page;
			
			url = "main.php?pg="+page;
								
			xmlHttp.onreadystatechange=homepagestateChanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		
		function homepagestateChanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdindexmain").innerHTML=xmlHttp.responseText ;						
			 } 
		}
		
		function mainpagecontent(callingpageurl)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= callingpageurl;
			var findindexof = url.indexOf("?") ;
			if(findindexof > 0)
			{
				url=url+"&sid="+Math.random() ;				
			}
			else
			{
				url=url+"?sid="+Math.random() ;
			}	
			//url=url+"?sid="+Math.random()				
			xmlHttp.onreadystatechange=mainpagecontentstateChanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		function mainpagecontentstateChanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdmain").innerHTML=xmlHttp.responseText ;						
			 } 
		}
		function homepage(callingpageurl)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= callingpageurl;
			url=url+"?sid="+Math.random()				
			xmlHttp.onreadystatechange=mainpagecontentstateChanged2 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		
		function mainpagecontentstateChanged2() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("homecontent").innerHTML=xmlHttp.responseText ;						
			 } 
		}			
	
		function GetXmlHttpObject()
		{
		var xmlHttp=null;
		try
		 {
		 // Firefox, Opera 8.0+, Safari
		 xmlHttp=new XMLHttpRequest();
		 }
		catch (e)
		 {
		 //Internet Explorer
		 try
		  {
		  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		  }
		 catch (e)
		  {
		  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		 }
		return xmlHttp;
		}
</script>
</head>
<body bgcolor="#FFFFFF" >

<table cellpadding="0" cellspacing="0" width="100%" border="0">
	<tr>
		<td align="center" id="tdindexmain">
				
			<table align="center" width="70%" border="0" cellspacing="0" cellpadding="0" style="padding-top:65px;">
 	 			<!-- Start Header -->
 				 <tr>
   					 <td>
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td align="center">
									<img src="images/Template-Home-Page_03.jpg" width="757" height="97" alt="" />
								</td>		
							</tr>
						</table>
					</td>
 				 </tr>
				 <tr>
				 	<td>
				 		<table border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0">
									
									<tr>
										<td  width="70%" valign="top" style="padding-left:55px;" >
											<table border="0"  cellpadding="0" cellspacing="0" width="100%">
												<!-- Start Login Here -->
												<tr>
													<td align="right"  bgcolor="#B7C6FF" style="width:512px; height:100px; border-color:#C2C4C8 ; padding-top:8px; padding-right:8px;">
														<table border="0" cellpadding="0" cellspacing="0">
															<tr>
																<td class="content" >
																	Email Address
																	<span style="padding-left:110px;">
																	Password
																</span>
																</td>
															</tr>		
															<tr>
																<td class="SubHeading" align="right">
																<form name="loginform" action="login.php" method="post">
																	<input type="text"  id="emailid" name="emailid" size="25" />	
																	<input type="password"  id="password" name="password" size="25" />
																	<?php  if($_SESSION['loginid'] == "") {?>
																	
																		<input type="image" align="absmiddle" onClick="javascript: return loginformchecking()"  src="images/login.jpg" />
																	<?php } else { ?>	
																	
																<a href = 'logout.php' class='bluelink' ><img src="images/logout.jpg" align="absmiddle" border="0" /></a>
																	<?php } ?>
																</form>	
																	
																</td>
															</tr>
														</table>
													</td>
												</tr>
												
												<!-- End Login Here -->
												<tr>
													<td>
														<img src="images/Template-Home-Page_24.jpg"  width="100%" height="400" alt="" />
													</td>
												</tr>
<!--												<tr>
												<td style="padding-top:5px;" >
													<table border="0" width="100%"  cellpadding="0" cellspacing="0">
														<tr>					
															<td bordercolor="#CCCCCC" bgcolor="#B7C6FF" style="width:231px; height:31px;" class="Heading" align="center">
																<?php 
																	$Heading2 = '' ;
																	$query = mysql_query("select * from tblhomemenues where strmenu = 'Menu1' order by iid desc");
																	$rows = mysql_num_rows($query);
																	if($rows > 0)
																	{
																	while($data = mysql_fetch_array($query))
																	{
																		$Heading2 = $data['strHeading'] ;
																	}
																	}
																?>
																<?php if($Heading2 != '') { ?>		
																<?php echo $Heading2 ;  }?>	
															</td>							
														</tr>
														<tr>
															<td valign="top" bordercolor="#CCCCCC" bgcolor="#DBE2FF" style="width:223px; height:185px" class="content">
																<?php 
																	$content2 = '' ;
																	$query = mysql_query("select * from tblhomemenues where strmenu = 'Menu1' order by iid desc");
																	$rows = mysql_num_rows($query);
																	if($rows > 0)
																	{
																	while($data = mysql_fetch_array($query))
																	{
																		$content2 = $data['strDescription'] ;
																		$content2 = html_entity_decode($content2);
																	?>
																	<p class="content"><?php echo $content2 ;?></p>
																	<?php
																	}
																	}			
																?>
															</td>
														</tr>
													</table>
												</td>
											</tr>-->
											</table>
						</td>
					</tr>	

	
  				 <!-- End Header -->  
				 <!-- Start Center area -->
				 
				 <!-- End  Center area -->
								
									
									</table>
									</td>
									<td valign="top" align="right" style="padding-left:10px;" width="30%"  >
											<?php include("include/rightpanel.php");?>
									</td>
							</tr>
						</table>
					</td>
  				</tr>
   <!-- End Center area -->
   
    <!-- Start Footer -->
  <tr>
    <td style="padding-left:55px;">
		 <table cellpadding="0" cellspacing="0" border="0" width="100%">
		 <tr><td>&nbsp;</td></tr>
		 	<!--<tr>
				<td style="padding-top:15px;">
					<span  class="Heading">Routing Users</span> <br>
					<?php
						if(isset($_SESSION['userid']) && $_SESSION['userid'] != '') 
						{
						echo "<a href = 'logout.php' class='bluelink' > Logout </a>" ;
						}
						else
						{
						?>
						
						<a href="login.php" class="bluelink"  >Login </a> 
						<?php
						 }
					?> <br>
					
					<?php
				if($_SESSION['userid'] == '') 
				{
				?>
						<a href="login.php"  class="bluelink" >Buyers</a> <br>
						<a href="login.php"  class="bluelink" >Search Sellers</a> <br>
						<a href="login.php" class="bluelink" >Sellers</a> <br><br>
					
				<?php } else {?>	
				
				<a href="javascript: homepagecontent('buyesaccount.php')"  class="bluelink" >Buyers</a> <br>
						<a href="javascript: homepagecontent('search.php')"  class="bluelink" >Search Sellers</a> <br>
						<a href="javascript: homepagecontent('selleraccount.php')" class="bluelink" >Sellers</a> <br><br>
				
				<?php }?>
				</td>
			</tr>-->
			<tr>
				<td width="100%">
					<img src="images/Template-Home-Page_96.jpg" width="100%" height="3" alt="">
				</td>
			</tr>
			<tr>
				<td align="center">
				
					<a href="index.php"  class="bluelink">Home</a> &nbsp; | 
					<a href="javascript: homepagecontent('aboutus.php')"  class="bluelink">About Us</a> &nbsp;| 
					<a href="javascript: homepagecontent('legal.php')"  class="bluelink">Legal</a> &nbsp; |
					<a href="contactus.php"  class="bluelink">Contact Us</a> &nbsp; | 
					<a href="javascript: homepagecontent('termsofservices.php')" class="bluelink">Terms of Services</a>
				
				</td>
			</tr>
			<tr>
				<td align="center" class="content">
					Copyright &copy; 2008-2009 ABC Solutions, Inc. All rights reserved <br>
					By using this site you agree to its Terms and Conditions
				</td>
			</tr>
		 </table>
	</td>
  </tr>
   <!-- End Footer -->
   
</table>

</td>
</tr>
</table>