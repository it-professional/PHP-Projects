<?php session_start() ;
include("checksession.php");
$pd = $_SESSION['PID'] ;
$_SESSION['Backlink'] = "viewrating.php?PID=$pd" ;
?>
<title> Product Owner Detail </title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table cellpadding="0" cellspacing="0" border="0" width="100%" >
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_SESSION['Backlink'] ;?>');"  colspan="5">Go Back
</td>
</tr>
 <tr>
 <td>
 <table border="0" cellpadding="0" cellspacing="0" width="100%">
 	<tr bgcolor="#CCCCCC">
					<td class="SubHeading" width="25%"><b>Subject</b></td>
					<td class="SubHeading" width="65%" align="left"><b>Warning</b></td>
					<td class="SubHeading" align="center" width="10%"><b>Posted Date</b></td>						
				</tr>
<?php
$warningpersonid = $_GET['uid'] ;
include("include/config.php");
$query = mysql_query("SELECT * FROM tblwarningmessages WHERE itoid = '$warningpersonid'");	
$getrows = mysql_num_rows($query);	
if($getrows > 0)
{
	while($wardingdata = mysql_fetch_array($query))
	{
		
		$strsubject = $wardingdata['strsubject'] ;
		$strwarningmessage = $wardingdata['strmessage'] ;
		$posteddate = $wardingdata['ddate'] ;
		
		
?>
				<tr>
					
					<td class="SubHeading" width="25%"><?php echo $strsubject ;?></td>
					<td class="SubHeading" width="50%" align="left"><?php echo $strwarningmessage ; ?></td>
					<td class="SubHeading" align="center" width="10%"><?php echo $posteddate?></td>						
				</tr>
<?php 
	}
}		
?>
			</table></td></tr>
</table>