<link href="include/css/css.css" type="text/css" rel="stylesheet" >

<?php

include("include/config.php");
$message = "" ;
$cname = $_GET['name'] ;
$cemail = $_GET['email'] ;
$cphone = $_GET['phone'] ;
$comments = $_GET['comments'] ;
$todaydate = date("Y-m-d");

$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
$strHTML .= "<b>Name : </b>".$cname."<br>";
$strHTML .= "<b>Email ID : </b>".$cemail."<br>";		
$strHTML .= "<b>Contact No. : </b>".$cphone. "<br>";
$strHTML .= "<b>Comments : </b>".$comments."<br>" ;
$strHTML .= "</td></tr></table>";

$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: voskysinteractive.com";
		
$strHTML = stripslashes($strHTML);	
//$email = mail("info@voskysinteractive.com","Contact us information",$strHTML,$headers);
$email = mail("aamirrasheed143@gmail.com","Contact us information",$strHTML,$headers);
	if($email)
	{
		mysql_query("INSERT INTO tblcontactus(strname,stremail,strphoneno,strcomments,ddate) VALUES('$cname','$cemail','$cphone','$comments','$todaydate')");
		$message = "We have received your query and we will contact you shortly." ;
		
	}
	else
	{
		$message = "There is somr error to submit your query so plz try again" ;
	}

?>
<table border="0" cellpadding="0" cellspacing="0"  style="padding-left:10px;">
	<tr>
		<td class="redlink" height="50" colspan="2" align="center">
			<?php
				 echo "<b>$message</b>" ;
						
			?>
		</td>
	</tr>
</table>



