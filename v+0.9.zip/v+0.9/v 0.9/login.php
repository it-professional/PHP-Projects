<?php
session_start();
?>

<?php if(!isset($_SESSION['userid']) || $_SESSION['userid'] == '') { ?>
<table width="100%" border="0" cellpadding="0"  cellspacing="0">
<tr>
<td id="tdindexmain">
<?php
include("include/template.php");
templateheader("" , "false");
?>


<?php

include("include/config.php");

if(isset($_POST['emailid']) && $_POST['emailid'] != '')
{
	$EmailAddress = $_POST['emailid'];
	$Password = $_POST['password'] ;
	$nname = "" ;
	//$Password = md5($Password) ;
	//$salt = 's+(_a*';
	//$salt_pass = md5($Password.$salt);
	$mailquery = mysql_query("select strnickname from tblmember where stremail = '$EmailAddress'");
	$mailrow = mysql_num_rows($mailquery);
	if($mailrow > 0)
	{
		$maildata = mysql_fetch_array($mailquery);
		$nname = $maildata['strnickname'] ;
	}	
	
	$encpassword = $nname.$Password ;
	$salt = 's+(_a*';
	$salt_pass = md5($encpassword.$salt);
	
	$query = mysql_query("select * from tblmember where stremail = '$EmailAddress' && strpassword = '$salt_pass'");
	$rows = mysql_num_rows($query);
	if($rows > 0)
	{
		$object = mysql_fetch_object($query);
		
		$userid = $object->iid ;
		$emailaddress = $object->stremail ;
		$status = $object->istatus ;
		
		// Check User Status
		if($status == 0)
		{
		?>
			<script>
				//window.location.href = "commissionpay.php?uid=<?php //echo $userid ;?>" ;
				  window.location.href = "banneduser.php" ;
			</script>
		<?php
		}
		
		// Check Commission
		else
		{
			$commissionquery = mysql_query("SELECT * FROM tblcommission WHERE isellerid = '$userid' AND istatus = '0'");
			$commissionrows = mysql_num_rows($commissionquery);
			if($commissionrows > 0)
			{
				$commissiondata = mysql_fetch_array($commissionquery);
				$date1 =  date("Y-m-d");
				$date2 = $commissiondata['dduedate'];
				
				$today = strtotime($date1);
				$duedate = strtotime($date2);
				if($today > $duedate)
				{
					$banneduserquery = mysql_query("UPDATE tblmember set istatus = '0' Where iid = '$userid'");
				
			?>
				<script>
					//window.location.href = "commissionpay.php?uid=<?php //echo $userid ;?>" ;
					window.location.href = "banneduser.php" ;
				</script>
			<?php
				}
				else
				{	
					$_SESSION['userid'] = $userid ;
					$_SESSION['loginid'] = $userid ;
					$_SESSION['emailaddress'] = $emailaddress ;
				?>
					<script>
						window.location.href = "main.php" ;
					</script>
				<?php
				}
			}
			else
			{
				$_SESSION['userid'] = $userid ;
					$_SESSION['loginid'] = $userid ;
					$_SESSION['emailaddress'] = $emailaddress ;
			?>
			<script>
						window.location.href = "main.php" ;
					</script>
			<?php
			}
		}	
	}
	else
	{
		$loginmessage = "Invalid Email address or Password." ;
		//$message = md5($message);
	
	?>
		<script>
			//var msg = "Invalid Email address or Password." ;
			window.opener.location.href = window.opener.location.href ;
		</script>
	<?php
		$_SESSION['userid'] = '' ;
		$_SESSION['emailaddress'] = '' ;
		$loginmessage = "Invalid Email address or Password." ;
	}

}
?>

<html>
<head>
<title> login </title>
	<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
		
		
		function loginformchecking()
		{
			if(document.loginform.emailid.value == '')
			{
				alert("Please Enter Your Email");
				return false ;
				document.loginform.emailid.focus();				
			}
			else if(document.loginform.password.value == '')
			{
				alert("Please Enter Your Password");
				return false ;
				document.loginform.password.focus();				
			}
			else
			{
				return true ;
			}
		}	 		
	</SCRIPT>
<link href="include/css/css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">



<table width="600" align="center" border="0" cellpadding="0" cellspacing="0">
	<?php
	if($loginmessage != "")
	{
	?>
	<tr>
		<td class="redlink" height="50" colspan="2" align="center">
			<?php
				//$msg = $_GET['message'] ;
				//$msg = md5($_GET['message']);
			
				 echo "<b>$loginmessage</b>" ;
				 $loginmessage = "" ;
				
			?>
		</td>
	</tr>
	<?php
	}
	?>
	
	<tr>
		<td  width="100%" class="SubHeading" align="center"><b>If you do not have an account yet. Plz Click here to <a href="registeruser.php" class="bluelink" style="text-decoration:underline; font-size:16px;">Register your Free account.</a> </b></td>
	</tr>
	<tr>
		<td >&nbsp;</td>
	</tr>
		
	<tr>
		<td   align="center" >
			<table cellpadding="0" align="center" width="52%" cellspacing="0" border="1"  style="border-color:#000000; border-style:solid">
				<tr>
					<td>
					<table border="0" cellpadding="0" cellspacing="0" width="100%">
						<tr>
							<td   height="28" bgcolor="#000000" ><font face="Trebuchet MS" size="2" color="#FFFFFF"  style="padding-left:10px;"><b>My Account</b></font><span class="SubHeading"><b><font color="#FFFFFF" style="padding-left:15px;"> (* indicate required fields)</font></b></span></td>
						</tr>
						<form name="loginform" action="#" method="post" onSubmit="return loginformchecking()">
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Email Address</td>
						</tr>
						<tr>
							<td style="padding-left:10px;"><input type="text" id="emailid" name="emailid" size="40"></td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;"  class="Heading">*Password</td>
						</tr>
						<tr>
							<td style="padding-left:10px;"><input type="password" id="password" name="password" size="40"></td>
						</tr>
						<tr>
						<td style="padding-left:10px; padding-top:5px;" class="content"><input  align="absmiddle"  type="checkbox" name="remember">&nbsp; Remember my password on this computer</td>
						</tr>
						<tr>
						<td style="padding-top:20px;" align="center"><input type="image"  src="images/Template-login-Page-1_40.jpg" ></td>
						</tr>
						<tr>
						<td align="right" style="padding-right:10px; padding-top:10px; padding-bottom:5px" class="Heading"><a href="forgot.php"  class="bluelink" style="text-decoration:none;">Forgot your password?</a></td>
						</tr>
				</form>
			</table>
		</td>
	</tr>
	</table>
	</td>
</tr>
	
	<tr>
		<td >&nbsp;</td>
	</tr>
	
	<tr>
	<td align="center" class="SubHeading" ><b>This feature requires a cookies-enabled browser. If you are blocking cookies, please re-enable them.
	<br>If you don't have a cookies-enabled browser, <a href="#" style="text-decoration:none;">click here</a> to get one.</b>
	 </td>
	</tr>
</table>	
</body>
</html>

</td>
</tr>
</table>
<?php } else { ?>
<script language="javascript" type="text/javascript">
window.location.href = "index.php" ;
</script>
<?php }?>

