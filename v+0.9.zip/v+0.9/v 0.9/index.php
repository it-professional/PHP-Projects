<?php
session_start();
include("include/config.php");
?>
<?php if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') { ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PickmeFriend</title>
<!--<link rel="shortcut icon" href="http://voskysinteractive.servehttp.com/beta/images/favicon.ico" />-->

<link href="include/css/css.css" type="text/css" rel="stylesheet" />
<link href="include/Newsscroller/scroller.css" rel="stylesheet" type="text/css" />
<script src="include/Newsscroller/scroller.js" language="javascript" type="text/javascript"></script>
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<script type="text/javascript" language="javascript" src="include/js/md5.js"></script>
<script type="text/javascript" language="javascript" src="include/js/jcap.js"></script>
   <link href="include/css/rfnet.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="include/js/datetimepicker_css.js"></script>
	<script language="JavaScript" type="text/javascript">
		
		
		function loginformchecking()
		{
			if(document.loginform.emailid.value == '')
			{
				alert("Please Enter Your Email");
				return false ;
				document.loginform.emailid.focus();				
			}
			else if(document.loginform.password.value == '')
			{
				alert("Please Enter Your Password");
				return false ;
				document.loginform.password.focus();				
			}
			else
			{
				return true ;
				//window.location.href = "login.php" ;
				document.loginform.submit();
				
			}
		}	 		
	</script>
<script language="javascript" type="text/javascript">
	
		function 	homepagecontent(page)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= page;
			
			url = "main.php?pg="+page;
								
			xmlHttp.onreadystatechange=homepagestateChanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		
		function homepagestateChanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdindexmain").innerHTML=xmlHttp.responseText ;						
			 } 
		}
		
		function mainpagecontent(callingpageurl)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= callingpageurl;
			var findindexof = url.indexOf("?") ;
			if(findindexof > 0)
			{
				url=url+"&sid="+Math.random() ;				
			}
			else
			{
				url=url+"?sid="+Math.random() ;
			}	
			
			//url=url+"?sid="+Math.random()				
			xmlHttp.onreadystatechange=mainpagecontentstateChanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		function mainpagecontentstateChanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdmain").innerHTML=xmlHttp.responseText ;						
			 } 
		}
		function homepage(callingpageurl)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= callingpageurl;
			url=url+"?sid="+Math.random()				
			xmlHttp.onreadystatechange=mainpagecontentstateChanged2 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		
		function mainpagecontentstateChanged2() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("homecontent").innerHTML=xmlHttp.responseText ;						
			 } 
		}			
	
		function GetXmlHttpObject()
		{
		var xmlHttp=null;
		try
		 {
		 // Firefox, Opera 8.0+, Safari
		 xmlHttp=new XMLHttpRequest();
		 }
		catch (e)
		 {
		 //Internet Explorer
		 try
		  {
		  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		  }
		 catch (e)
		  {
		  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		 }
		return xmlHttp;
		}
</script>
</head>
<body bgcolor="#FFFFFF" >

<table cellpadding="0" cellspacing="0" width="95%" height = "90%" border="0"  valign="top" align="center" >
	<tr>
		<td align="center" id="tdindexmain">
				
			<table align="center" width="100%" height = "100%"  valign="top"  border="0" cellspacing="0" cellpadding="0" >
 	 			<!-- Start Header -->
 				 <tr>
   					 <td>
						<table cellpadding="0" align="center"  cellspacing="0" border="0" width="100%" height = "100%">
							<tr>
								<td align="center">
									<img src="images/Template-Home-Page_03.jpg" width="100%"  alt="" />
								</td>		
							</tr>
						</table>
					</td>
 				 </tr>
				 <tr>
				 	<td>
				 		<table border="0" cellpadding="0" width="100%" height = "100%" valign="top" align="center" cellspacing="0">
							<tr>
								<td>
									<table border="0" cellpadding="0" width="100%" height = "100%" valign="top" align="center" cellspacing="0">
									
									<tr>
										<td  width="100%" height = "100%" valign="top" align="center" style="padding-left:0px;" >
											<table border="2"  cellpadding="0" cellspacing="0" width="100%" height = "100%" align="right">
												<!-- Start Login Here -->
												<tr>
													<td align="right"  bgcolor="#B7C6FF" style="width:100%; height:100px; border-color:#C2C4C8 ; padding-top:0px; padding-right:0px;">
														<table border="0" cellpadding="0" cellspacing="0">
															<tr>
																<td class="content" >
																	Email Address
																	<span style="padding-left:110px;">
																	Password
																</span>
																</td>
															</tr>		
															<tr>
																<td class="SubHeading" align="right">
																<form name="loginform" action="login.php" method="post">
																	<input type="text"  id="emailid" name="emailid" size="25" value="Email Address" onFocus="this.value=''; this.onfocus=null" />	
																	<input type="password"  id="password" name="password" size="25" value="Password" onFocus="this.value=''; this.onfocus=null" />
																	<?php  if($_SESSION['loginid'] == "") {?>
																	
																		<input type="image" align="absmiddle" onClick="javascript: return loginformchecking()"  src="images/login.jpg" />
																	<?php } else { ?>	
																	
																<a href = 'logout.php' class='bluelink' ><img src="images/logout.jpg" align="absmiddle" border="0" /></a>
																	<?php } ?>
																</form>	
																	
																</td>
															</tr>
														</table>
													</td>
												</tr>
												
												<!-- End Login Here -->
												
												<tr >
													<td >
														<img src="images/Template-Home-Page_24.jpg" width="100%" height="100%" alt="" />
													</td>
												</tr>

											</table>
						</td>
					</tr>	

	
  				 <!-- End Header -->  
				 <!-- Start Center area -->
				 
				 <!-- End  Center area -->
								
									
									</table>
									</td>
									<td valign="top" align="right" style="width:30%; height:100px; border-color:#C2C4C8 ; padding-top:0px; padding-right:0px;">

									<!--<td valign="top"  border="0" align="center" style="padding-left:1px; padding-top:0px;  " width="0%"  > -->
											<?php include("include/rightpanel.php");?>
									</td>
							</tr>
						</table>
					</td>
  				</tr>
   <!-- End Center area -->
   
    <!-- Start Footer -->
  <tr>
    <td style="padding-left:5px;">
		 <table cellpadding="0" cellspacing="0" border="0" width="100%" height = "10%">
		 <tr><td>&nbsp;</td></tr>
		 	<!--<tr>
				<td style="padding-top:10px;">
					<span  class="Heading">Routing Users</span> <br>
					<?php
						if(isset($_SESSION['userid']) && $_SESSION['userid'] != '') 
						{
						echo "<a href = 'logout.php' class='bluelink' > Logout </a>" ;
						}
						else
						{
						?>
						
						<a href="login.php" class="bluelink"  >Login </a> 
						<?php
						 }
					?> <br>
					
					<?php
				if($_SESSION['userid'] == '') 
				{
				?>
						<a href="login.php"  class="bluelink" >Buyers</a> <br>
						<a href="login.php"  class="bluelink" >Search Sellers</a> <br>
						<a href="login.php" class="bluelink" >Sellers</a> <br><br>
					
				<?php } else {?>	
				
				<a href="javascript: homepagecontent('buyesaccount.php')"  class="bluelink" >Buyers</a> <br>
						<a href="javascript: homepagecontent('search.php')"  class="bluelink" >Search Sellers</a> <br>
						<a href="javascript: homepagecontent('selleraccount.php')" class="bluelink" >Sellers</a> <br><br>
				
				<?php }?>
				</td>
			</tr>-->
			<tr>
				<td width="100%">
					<img src="images/Template-Home-Page_96.jpg" width="100%" height="3" alt="">
				</td>
			</tr>
			<tr>
				<td align="center">
				
					<a href="index.php"  class="bluelink">Home</a> &nbsp; | 
					<a href="javascript: homepagecontent('aboutus.php')"  class="bluelink">About Us</a> &nbsp;| 
					<a href="javascript: homepagecontent('legal.php')"  class="bluelink">Legal</a> &nbsp; |
					<a href="contactus.php"  class="bluelink">Contact Us</a> &nbsp; | 
					<a href="javascript: homepagecontent('termsofservices.php')" class="bluelink">Terms of Services</a>
				
				</td>
			</tr>
			<tr>
				<td align="center" class="content">
					Copyright &copy; 2009-20010 VoskysInteracive Inc. All rights reserved <br>
					By using this site you agree to its <a href="javascript: homepagecontent('termsofservices.php')" class="bluelink">Terms of Services</a>
				</td>
			</tr>
		 </table>
	</td>
  </tr>
   <!-- End Footer -->
   
</table>

</td>
</tr>
</table>
</body></html>
<?php } else { ?>
<script language="javascript" type="text/javascript">
window.location.href = "main.php" ;
</script>
<?php }?>