<?php

$dbhost   = 'pickmefrienddb.db.5374949.hostedresource.com';
$dbname   = 'pickmefrienddb';
$dbusername   = 'pickmefrienddb';
$dbuserpass = 'wOrk2env10';        
mysql_connect ($dbhost, $dbusername, $dbuserpass);
mysql_select_db($dbname) or die('Cannot select database');


?>
