<?php
session_start();
//include("checksession.php");
include("random.php");
?>

<?php if(!isset($_SESSION['userid']) || $_SESSION['userid'] == '') { ?>
<table width="100%" border="0" cellpadding="0"  cellspacing="0">
<tr>
<td id="tdindexmain">
<?php
include("include/template.php");
templateheader("" , "false");
?>


<?php

include("include/config.php");

if(isset($_POST['emailid']) && $_POST['emailid'] != '')
{
	$EmailAddress = $_POST['emailid'];
	
	$mailquery = mysql_query("select iid from tblmember where stremail = '$EmailAddress'");
	$mailrow = mysql_num_rows($mailquery);
	if($mailrow > 0)
	{
		$maildata = mysql_fetch_array($mailquery);
		$id = $maildata['iid'] ;				
		$strpasswordrecovery = rand(1111111111111111111,9999999999999999999);	
		$temporarypassword = get_rand_id(128);
		$ddate = date("Y-m-d");	
		
		$mailquery4 = mysql_query("SELECT * FROM tblrecovery where iuid = '$id'");
		$mailquery4rows = mysql_num_rows($mailquery4);
		if($mailquery4rows > 0)
		{
			$mysqlquery = "Update tblrecovery set strpasswordstring = '$strpasswordrecovery',strtemporarystring = '$temporarypassword' where iuid = '$id'" ;			
		}
		else
		{
			$mysqlquery = "INSERT INTO tblrecovery (iuid,icount,strphase,ddate,strpasswordstring,strtemporarystring) VALUES('$id', '1','false','$ddate','$strpasswordrecovery','$temporarypassword')" ;

		}
		
		$mailquery2 = mysql_query($mysqlquery);
		if($mailquery2)
		{
			$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
			$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>You have requested for your password, your password is :<br><br> ";
			$strHTML .= "<b>Email ID : </b>".$_POST['emailid']."<br>";	
			$strHTML .= "<b>Password Recovery String : </b>".$strpasswordrecovery."<br>";	
			$strHTML .= "<b>Please Click on below link to Recover your Password </b><br>";
			$strHTML .= "<a target = '_blank' href = 'http://pickmefriend.com/beta/registeruser.php?step=abc5def&temp=$temporarypassword'><b>Start your Password Recovery Process.</b></a>" ;			
			$strHTML .= "</td></tr></table>";
			
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: PickmeFriend.com";
			
			
			$strHTML = stripslashes($strHTML);	
			//echo $strHTML ;	
			$email = mail($EmailAddress,"Forgot Password",$strHTML,$headers);	
			if($email)
			{
				//$loginmessage = "Password has been sent at your email address." ;			
			?>
			<script language="javascript">
				window.location.href = 'registeruser.php?step=abc5def&temp=<?php echo $temporarypassword ?>' ;
			</script>
			<?php	
			}
			else
			{
				$loginmessage = "There is some error to send email." ;
			}
		}
		else
		{
		?>
			<script language="javascript">
				alert("Error in Insertion.");
			</script>/
		<?php
		}	
	}
	else
	{
		$loginmessage = "There is no Registered user against this email address." ;
	}
}
?>

<html>
<head>
<title> Forgot Password </title>
	<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
		
		
		function forgotformchecking()
		{
			if(document.forgotform.emailid.value == '')
			{
				alert("Please Enter Your Email");
				return false ;
				document.forgotform.emailid.focus();				
			}
			else if(document.forgotform.uword.value == '')
			{
				alert("Please Enter Verification Code");
				return false ;
				document.forgotform.uword.focus() ;		
			}
			else if(!jcap())
			{
				  return false ;  
				  document.forgotform.uword.focus() ;	
			}
			else
			{
				return true ;
			}
		}	 		
	</SCRIPT>
	<style>
form div.captcha {
  width: 200px;
  margin-left: 1px;
 }
</style>
<script type="text/javascript" language="javascript" src="include/js/md5.js"></script>
<script type="text/javascript" language="javascript" src="include/js/jcap2.js"></script>
   <link href="include/css/rfnet.css" rel="stylesheet" type="text/css">
<link href="include/css/css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">



<table width="600" align="center" border="0" cellpadding="0" cellspacing="0">
	<?php
	if($loginmessage != "")
	{
	?>
	<tr>
		<td class="redlink" height="50" colspan="2" align="center">
			<?php
				//$msg = $_GET['message'] ;
				//$msg = md5($_GET['message']);
			
				 echo "<b>$loginmessage</b>" ;
				 $loginmessage = "" ;
				
			?>
		</td>
	</tr>
	<?php
	}
	?>
	
	<tr>
		<td  width="100%" class="SubHeading" align="center"><b>If you do not have an account yet. Plz Click here to <a href="registeruser.php" class="bluelink" style="text-decoration:underline; font-size:16px;">Register your Free account.</a> </b></td>
	</tr>
	<tr>
		<td >&nbsp;</td>
	</tr>
		
	<tr>
		<td   align="center" >
			<table cellpadding="0" align="center" width="52%" cellspacing="0" border="1"  style="border-color:#000000; border-style:solid">
				<tr>
					<td>
					<table border="0" cellpadding="0" cellspacing="0" width="100%">
						<tr>
							<td   height="28" bgcolor="#000000" ><font face="Trebuchet MS" size="2" color="#FFFFFF"  style="padding-left:10px;"><b>Forgot Password</b></font><span class="SubHeading"><b><font color="#FFFFFF" style="padding-left:15px;"> (* indicate required fields)</font></b></span></td>
						</tr>
						<form name="forgotform" action="forgot.php" method="post" onSubmit="return forgotformchecking()">
					<tr>
						<td align="center" class="SubHeading" >Please enter your correct registered email address<br>Your password will be send to your email address. 
						 </td>
					</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Email Address</td>
						</tr>
						<tr>
							<td style="padding-left:10px;"><input type="text" id="emailid" name="emailid" size="40"></td>
						</tr>
						<tr><td>&nbsp;</td></tr>
						<tr>
							
							<td style="padding-left:10px;" >
								<div class="captcha">
									<script language="javascript" type="text/javascript">
										cimg() ;
									</script>
									<noscript>[This resource requires a Javascript enabled browser.]</noscript>
								</div>
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px;">
								<input name="uword" id="uword" size="40" type="text" >
							</td>
						</tr>
						<tr>
							<td align="center" class="SubHeading" style="padding-left:10px;">
								<b>(Please enter above mentioned code.)</b>
							</td>
						</tr>
						<tr>
						<td style="padding-top:20px;" align="center"><input type="image"  src="images/Template-login-Page-1_40.jpg" ></td>
						</tr>
						
				</form>
			</table>
		</td>
	</tr>
	</table>
	</td>
</tr>
	
	<tr>
		<td >&nbsp;</td>
	</tr>
	
</table>	
</body>
</html>

</td>
</tr>
</table>
<?php } else { ?>
<script language="javascript" type="text/javascript">
window.location.href = "index.php" ;
</script>
<?php }?>

