<?php
include("openconn.php");
$bigtitle = "" ;
$title = "" ;
$subtitle = "" ;
$image = "" ;
?>
<?php
if(isset($_POST['submit']))
{
	$contactid = $_POST['contactusid'] ;
	$query = mysql_query("Delete FROM tblcontactus where iid = '$contactid'");
}
?>

<script language="javascript">
function NewWindow(mypage,myname,w,h,scroll,resize)
{
			w=w-100;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
}
function viewcomments(cid)
{

	NewWindow("viewcomments.php?cid="+cid,"ViewComments",'600','420','Yes','No');
}

function viewmessage2(id)
{

window.open("viewmessage.php?id="+id,"View Email Message","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=150, height=140");

}
function contactusconfirmation(iid)
{

var confirm1 = confirm("Are you sure you want to delete these Comments ");

if(confirm1 == true)
{
 
 window.location.href = 'deletecomments.php?id= '+iid ;
 
}
}
function contactconfirmation()
{
	var answer = confirm("Are you sure you want to delete these Comments ");
	if (answer)	 return true;
	else  return false;
}

</script>
<head>
<title>PickmeFriend</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="101%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong>Contact Us User's</strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" background="images/inner_06.jpg"><table width="100%" border="0" cellpadding="6" cellspacing="2" class="innertable">
      <tr>
        <td width="100%" valign="top">
			<table cellpadding="0"  cellspacing="0" border="0">
			<tr background="images/bg_part.gif" >
			<td class="formtext" width="12%" >Name</td>
			<td class="formtext" width="23%">Email Address</td>
			<td class="formtext"  width="10%" >Phone NO</td>
			<td class="formtext"  width="25%">Comments</td>
			<td class="formtext"  width="10%">Picture</td>
			<td class="formtext" width="20%">&nbsp;</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<form name="emailform" method="post">
			<?php
			$query = mysql_query("select * from tblcontactus order by ddate asc");
			$rows = mysql_num_rows($query);
			if($rows > 0)
			{
				while($data = mysql_fetch_array($query))
				{
					
					$id = $data['iid'] ;
					$name = $data['strname'] ;
					$emailid = $data['stremail'] ;
					$phoneno = $data['strphoneno'] ;
					$comments = $data['strcomments'] ;
					$strpicture = $data['strpicture'] ;
					
					if($comments != "") 
					{ 
						if(strlen($comments)>=100)
						{
							if(!function_exists('str_split')) 
							{ 
								$commentsarray = str_split1($comments,100);
							}
							else
							{
								$commentsarray = str_split($comments,100);
							}	
						}
					}	
?>	
			
			<tr >
			<td class="tdfeatured" width="12%"><?php echo $name ?></td>
			<td class="tdfeatured" width="23%" ><?php echo $emailid ;?></td>
			<td class="tdfeatured" width="10%" ><?php echo $phoneno ;?></td>
			<td class="tdfeatured" width="25%" >
			<?php if(strlen($comments)>=100)
					{
						 echo $commentsarray[0]."&nbsp;...... " ;
					}
					else
					{	
						 echo $comments ;
					}
			?>			
			</td>
			
			
			<?php if($strpicture != "" || $strpicture  == "NULL") { ?>
			<td class="tdfeatured" width="10%" ><img src="../images/ContactUsPic/<?php echo $strpicture ;?>" border="0" width="100" height="80"></td>
			<?php } else {?>
			<td class="tdfeatured" width="10%" >No Picture</td>
			<?php } ?>
				<td class="tdfeatured" width="20%">
				<form name="contactform" method="post" action="#">
					<input  type="button" class="btn1" value=" View Comments " onClick="javascript: viewcomments(<?php echo $id ; ?>)">
					<input type="hidden" name="contactusid" value="<?php echo $id ; ?>" >
					<input  type="submit" name="submit" id="submit" class="btn1" value=" Delete Comments " onClick="return contactconfirmation()">
				</form>
				</td>
			</tr>
			<?php
				}
			}
			else
			{
			?>
			<tr background="images/bg_part.gif">
			
			<td class="formtext" colspan="5" align="center">There are no Comments.</td>
			
			</tr>
			<?php
			}
			?>
			</table>
		 </td>
      </tr>
	
    </table></td>
  </tr>
  
</table>
</body>
</html>
