<?php
include("openconn.php");
include("functions.php");


//header("location:index.php");
$hid="";
$masg=0;
$active=0;
$uploadedimage = 'nopicture.jpg' ;
//$bigtitle ="" ;
//$subtitle = "" ;
//$option_heading = "" ;
//$image = "" ;
if(isset($_POST["add"]))
{
	$active=0;
	$masg=0;

	$bigtitle 		= $_POST["bigtitle"];
	$productcharacteristics = $_POST['productcharacteristics'] ;
	$newquery = mysql_query("select * from tblproductcharacteristics where ipchid = '$productcharacteristics'");
	while($newdata = mysql_fetch_array($newquery))
	{
		$characteristicname = $newdata['strcharacteristicsname'];
	}
	
	$active	= $_POST["active"];
	if($active == '')
	{
		$active = 'Disable' ;
	}
	else
	{
		$active = 'Active' ;
	}
	
	$date = date("Y-m-d");
	
	if($productcharacteristics == '')
	{
		$masg=1;
		$msg="There is no Characteristic. so first add characteristic";
	}
	else
	{
	
		$query4 = mysql_query("select * from tblproductattributes where ipchid = '$productcharacteristics' and strattribute = '$bigtitle' ");
		$rws = mysql_num_rows($query4);
		if($rws > 0)
		{
			$masg=1;
			$msg="The Attribute of this name already exists in this characteristic.";
		}
		else
		{
			
			if($characteristicname == "Built Year")
			{
				if(is_numeric($bigtitle) == false )
				{
					$masg=1;
					$msg="The Attribute Should be Numeric.";
				}
				else
				{
					$qry = "INSERT INTO tblproductattributes (ipchid , strattribute ,  bactive , dtdate) VALUES  ('$productcharacteristics' , '$bigtitle' , '$active' , '$date')";
					$res = mysql_query( $qry );
					if( $res )
					{
						$masg=1;
						$msg="Record Added Susccessfully";
					}
					else
					{
						$masg=1;
						$msg="This record Could not be Added.";
					}
			
				}
			}
			
			
			else
			{
			
			$qry = "INSERT INTO tblproductattributes (ipchid , strattribute ,  bactive , dtdate) VALUES  ('$productcharacteristics' , '$bigtitle' , '$active' , '$date')";
			$res = mysql_query( $qry );
			if( $res )
			{
				$masg=1;
				$msg="Record Added Susccessfully";
			}
			else
			{
				$masg=1;
				$msg="This record Could not be Added.";
			}
			}	
		}
	}		
}

			
//update values
if(isset($_POST["update"])){
	
	$active=0;
	$masg=0;

	$bigtitle 		= $_POST["bigtitle"];
	$productcharacteristics = $_POST['productcharacteristics'] ;
	$newquery = mysql_query("select * from tblproductcharacteristics where ipchid = '$productcharacteristics'");
	while($newdata = mysql_fetch_array($newquery))
	{
		$characteristicname = $newdata['strcharacteristicsname'];
	}
	
	$active	= $_POST["active"];
	if($active == '')
	{
		$active = 'Disable' ;
	}
	else
	{
		$active = 'Active' ;
	}
	$date = date("Y-m-d");
	
	
	$heditid = $_POST["hid"];
	
	
	if($characteristicname == "Built Year")
	{
		if(is_numeric($bigtitle) == false )
		{
			$masg=1;
			$msg="The Attribute Should be Numeric.";
		}
		else
		{
		$qry ="update tblproductattributes set  ipchid = '$productcharacteristics' ,  strattribute = '$bigtitle' ,  bactive = '$active' , dtdate = '$date' where iid= $heditid" ;
			$res = mysql_query( $qry );
			if( $res )
			{
				$masg=1;
				$msg="Record Updated Susccessfully";
			}
			else
			{
				$masg=1;
				$msg="This record Could not be Updated.";
			}
			
		}
	}
	
	else
	{
	
	$qry ="update tblproductattributes set  ipchid = '$productcharacteristics' ,  strattribute = '$bigtitle' ,  bactive = '$active' , dtdate = '$date' where iid= $heditid" ;
	$res = mysql_query( $qry );
			if( $res ){
				$masg=1;
				$msg="Record updated Susccessfully";
			}
			else{
				$masg=1;
				$msg="Record Could not be updated.";
			}
}
}
		

//delet value
if(isset($_POST["delete"]))
{
	$hid = $_POST["hiddendelete"];
	$strQRY="Delete from tblproductattributes  where iid = $hid" ;
	$nRst=mysql_query($strQRY);
}


//select value
if(isset($_POST["edit"]))
{
	$hid=$_POST["hiddenedit"];
	$qry = "select * from tblproductattributes where iid='$hid'";
	$res	= mysql_query($qry);
	$obj	= mysql_fetch_object($res);
	$bigtitle	= $obj->strattribute ;
	$active	= $obj->bactive ;
	$productcharacteristics = $obj->ipchid;
	
	
	//print $product;
	//print $Pic."<br>";
}
?>
<script language="javascript">
function formCheck(formobj){
formobj = eval(formobj);
//alert(formobj1.txtProduct.value);
	// Enter name of mandatory fields
	
var fieldRequired = Array();
	// Enter field description to appear in the dialog box
	var fieldDescription = Array();
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].value == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "password":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}
	if (alertMsg.length == l_Msg)
	{
		return true;
	}
	else{
		alert(alertMsg);
		return false;
	}}

function del_confirm(){	var answer = confirm ("Do you really want to delete this Event?")
	if (answer)	 return true;
	else  return false;}

function IsNumeric(strString) {
   var strValidChars = "0123456789.-";
   var strChar;
   var blnResult = true;

   if (strString.length == 0) return false;

   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }
	  if(blnResult == false)
	  	{alert("Only Numeric Value is Acceptable!")
		//form25.txtvalue.focus();
		}
		
   return blnResult;
   }

<!--
function popitup(url) {
	newwindow=window.open(url,'name','height=400,width=500');
	if (window.focus) {newwindow.focus()}
	return false; }

function add_option(p_opt_id)
	{
	alert(p_opt_id);
	
	
	}
// -->
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/javascript" src="editor/wysiwyg.js"></script>
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="101%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong> Product Characteristics Attributes </strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" background="images/inner_06.jpg"><table width="93%" border="0" cellpadding="6" cellspacing="2" class="innertable">
      <tr>
        <td width="100%" valign="top"><form action="#" method="post" enctype="multipart/form-data" name="frmhome" onSubmit="return formCheck('frmhome');">
        <input type="hidden" name="hid" value="<?php echo $hid?>">
        <input type="hidden" name="oldimg" value="<?php echo $image?>">
   
     
          <table width="100%" border="0" cellspacing="3" cellpadding="0" class="singleborder">
            <tr>
              <td colspan="2">&nbsp;</td>
              </tr>
			  
			   <tr>
              <td width="25%"><div align="right">Characteristics</div></td>
              <td><div align="left">
                <label>
                <select name="productcharacteristics" style="width:130px;">
				<?php
				$query5 = mysql_query("select * from tblproductcharacteristics order by ipchid asc");
				$rows = mysql_num_rows($query5);
				if($rows > 0)
				{
					while($data = mysql_fetch_array($query5))
					{
					?>
						<option <?php if($productcharacteristics == $data['ipchid']) { ?> selected="selected" <?php }?> value="<?php echo $data['ipchid'] ;?>"><?php echo $data['strcharacteristicsname'] ;?></option>
						
					<?php
					}
				}
				?>
				</select>
                </label>
              </div></td>
            </tr>
			  
			  <tr>
              <td width="25%"><div align="right">Attribute Name</div></td>
              <td><div align="left">
                <label>
                <input name="bigtitle" type="text" class="textbox1" id="bigtitle" value="<?php echo $bigtitle ?>">
                </label>
              </div></td>
            </tr>
			
                        
           		
			 <tr>
             
              <td><div align="right">
                <label>
                <input name="active" type="checkbox" class="textbox1" id="active" <?php if($active == 'Active') { ?> checked="checked" <?php }?> >
                </label>
              </div></td>
			   <td width="25%"><div align="left">Active </div></td>
            </tr>
            
            <tr>
              <td><div align="right"></div></td>
              <td><div align="left">
				<?php if(isset ($_POST["edit"])){?>	
                <input name="update" type="submit" class="btn1" id="update" value="Update">
                <?php }else{?>
                <input name="add" type="submit" class="btn1" id="add" value="   Add   ">
                <?php }?>
              </div></td>
            </tr>
          </table>
                </form>
        </td>
      </tr>
	  
    </table></td>
  </tr>
  <tr>
    <td>
	
<table width="100%" border="0" cellspacing="0" cellpadding="0"> 
	<tr> 
   		<td width="30%" height="20" align="left" background="images/bg_part.gif" class="formtext">Characteristic</td>		
    	<td width="25%" height="20" align="left" background="images/bg_part.gif" class="formtext">Attribute</td>
    	<td width="20%" height="20" align="left" background="images/bg_part.gif" class="formtext">Status</td>
       	<td height="20" colspan="3" align="right" background="images/bg_part.gif" class="formtext">Options</td>
  </tr>
  <?php  
$qry 	= "Select tblproductcharacteristics.strcharacteristicsname , tblproductattributes.strattribute , tblproductattributes.bactive , tblproductattributes.iid from  tblproductcharacteristics , tblproductattributes where tblproductcharacteristics.ipchid = tblproductattributes.ipchid ";	
$ress 	= mysql_query($qry);
while($objj = mysql_fetch_array($ress)) 
	{
		$charteristics = $objj['strcharacteristicsname'];
		$attribute = $objj['strattribute'] ;
		$iid = $objj['iid'];
		$strstatus = $objj['bactive'];
	?>
	<form name="frm" method="post" action="#">
			<tr> 
							
			  <td width="30%" height="30" align="left" class="tdfeatured">
			 	 
				 
				 <?php
				 echo $charteristics ;
				 
				 ?>		</td>
			
				
			  <td width="25%" height="30" align="left" class="tdfeatured">
			 	 
				 
				 <?php
				 echo $attribute ;
				 
				 ?>		</td>
				   <td width="20%" height="30" align="left" class="tdfeatured">
			 	 
				 
				 <?php
				 echo $strstatus ;
				 
				 ?>		</td>
			
			

				<td height="30" align="right" class="tdfeatured"><div align="right">
				  <input name="edit" type="submit" class="btn1" value="EDIT" id="edit" />
				  <input type="hidden" value="<?php  echo $iid  ?>" name="hiddenedit" />
			    </div></td>
				<td width="10%" height="30" align="right" class="tdfeatured"> 
					 <div align="center">
					   <input name="delete" type="submit" class="btn1" onClick="return del_confirm();" value="DELETE" id="delete">
					   <input type="hidden" value="<?php echo $iid  ?>" name="hiddendelete">			
			      </div></td>
			</tr>
	</form>
  
<?php
}
?>
			<tr>
			  <td height="30">&nbsp;</td>
			  <td height="30">&nbsp;</td>
			  <td height="30" align="center">			  </td>
			  <td height="30" align="center">			  </td>
			  <td height="30" colspan="2" align="right">&nbsp;</td>
			  <td height="30" align="center">&nbsp;</td>
		  </tr>
</table>	</td>
  </tr>
  <tr>
    <td>
    
    
    </td>
  </tr>
</table>
</body>
</html>
