<?php
include("openconn.php");
$bigtitle = "" ;
$title = "" ;
$subtitle = "" ;
$image = "" ;
?>

<script language="javascript">
function NewWindow(mypage,myname,w,h,scroll,resize)
{
			w=w-100;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
}
function sendwarning(cid)
{

	NewWindow("sendwarning.php?cid="+cid,"sendnotice",'640','420','Yes','No');
}

function viewmessage2(id)
{

window.open("viewmessage.php?id="+id,"View Email Message","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=150, height=140");

}
function confirmation()
{
	var confirm1 = "" ;
	if(status == 0)
	{
		confirm1 = confirm("Are you sure you want to Bann this User. ");
	}
	else
	{
		confirm1 = confirm("Are you sure you want to Active this User. ");
	}	

if(confirm1 == true)
{
//alert("bannuser.php?id="+iid+"&setstatus="+status) ;
 window.location.href = "bannuser.php?id="+iid+"&setstatus="+status ; 
}
}

function bannconfirmation()
{
	var answer = confirm ("Do you really want to Bann this User?")
	if (answer)	 return true;
	else  return false;
}
function activeconfirmation()
{
	var answer = confirm ("Do you really want to Active this User?")
	if (answer)	 return true;
	else  return false;
}
</script>
<head>
<title>PickmeFriend</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table  border="0" align="left" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong>Manage Report Abuses</strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr >
    <td align="center" valign="top" background="images/inner_06.jpg" ><table  border="0" width="100%" cellpadding="0" cellspacing="0" class="innertable">
      <tr>
        <td  valign="top" >
			<table cellpadding="0"   cellspacing="0" border="0" width="100%">
			<tr background="images/bg_part.gif">
			<td class="formtext" width="15%"><b>Abuse From</b></td>
			<td class="formtext" width="15%" ><b>Abuse To</b></td>
			<td class="formtext" width="15%" ><b>Product Name</b></td>
			<td class="formtext" width="40%" ><b>Message</b></td>
			<td class="formtext" width="15%" ><b>Posted Date</b></td>
		
			</tr>
			<tr><td>&nbsp;</td></tr>
		<?php
			
				$reportquery = mysql_query("SELECT * FROM tblreportabuses order by iid asc");
				$abuserows = mysql_num_rows($reportquery);
				if($abuserows > 0) 
				{
					while($abusedata = mysql_fetch_array($reportquery))
					{
						$productid = $abusedata['ipid'] ;
						$fromid =$abusedata['ifromid'] ;
						$reportmessage = $abusedata['strmessage'] ;
						$posteddate = $abusedata['ddate'] ;
						
						$query = mysql_query("select * from tblproducts where iid = '$productid'");
						$data = mysql_fetch_array($query);
						$productowner = $data['iuid'];
						$productname = $data['strproductname'];
						
						$userquery = mysql_query("select strnickname from tblmember where iid = '$productowner'");
						$userdata = mysql_fetch_array($userquery);
						$ownernick = $userdata['strnickname'] ;	
						
						$userquery2 = mysql_query("select strnickname from tblmember where iid = '$fromid'");
						$userdata2 = mysql_fetch_array($userquery2);
						$fromnick = $userdata2['strnickname'] ;	
		?>
		
			<tr>
				<td class="tdfeatured" width="15%" ><?php echo $fromnick ; ?></td>
				<td class="tdfeatured" width="15%" ><?php echo $ownernick ;?></td>
				<td class="tdfeatured" width="15%" ><?php echo $productname ;?></td>
				<td class="tdfeatured" width="40%"><?php echo $reportmessage ;?></td>
				<td class="tdfeatured" width="15%" ><?php echo $posteddate ;?></td>
			</tr>
			<?php
				}
				}
				else
				{
			?>
				<tr background="images/bg_part.gif">
					<td colspan="11">
						No Abuse is posted
					</td>
				</tr>
				<?php
					}
				?>
			</table>
		 </td>
      </tr>
	
    </table></td>
  </tr>
  
</table>
</body>
</html>
