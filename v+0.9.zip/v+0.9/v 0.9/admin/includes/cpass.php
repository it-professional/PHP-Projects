<?
include("openconn.php");
include("functions.php");
include("FILES.PHP");

	$mess="";

if(isset($_POST["Submit"]))
{

	
	if($_POST["opass"]=="")$mess="Please provide Old Password !";
	elseif($_POST["npass"]=="")$mess="Please provide New Password !";
	elseif($_POST["npass"]!=$_POST["cpass"])$mess="Password and Confirm Password doesnt matched !";
	else
	{
	$strQRY="Select * from admin where password='".$_POST["opass"]."' and Name = '".$_SESSION['username']."'";
	$nRst=mysql_query($strQRY);
	$count = mysql_num_rows($nRst);
	if($count==0)$mess="Wrong Old Password";
	else
		{
			$strQRY="update admin set password='".$_POST["npass"]."' where Name = '".$_SESSION['username']."'";
			$nRst=mysql_query($strQRY);
			$mess="Password has been changed !";
		}
	}



}


?>
<head>
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<form name="form1" method="post" action="#" enctype="multipart/form-data">
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
      <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="100%" align="right" background="images/bg_part.gif"><div align="left">&nbsp;<span class="fonte"><strong>CHANGE PASSWORD </strong></span><strong>&nbsp;&nbsp;</strong></div></td>
      <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right" class="head">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="6%">&nbsp;</td>
      <td width="94%"><p>&nbsp;</p>
        <p>&nbsp;</p>
        <table width="400" border="0" align="center" cellpadding="3" cellspacing="3" bgcolor="#F2F3F6" class="singleborder">
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b> <?print($mess);?> </b></font></div></td>
        </tr>
        <tr>
          <td width="136" class="NormalText"><div align="right" class="fonte">Old Password :</div></td>
          <td width="243"><input type="password" name="opass" size="32" class="textbox"/>
          </td>
        </tr>
        <tr>
          <td width="136" class="NormalText"><div align="right" class="fonte">New Password :</div></td>
          <td width="243"><input type="password" name="npass" size="32" class="textbox"/>
          </td>
        </tr>
        <tr>
          <td width="136" class="NormalText"><div align="right" class="fonte">Confirm Password :</div></td>
          <td width="243"><input type="password" name="cpass" size="32" class="textbox"/>
          </td>
        </tr>
        <tr>
          <td width="136">&nbsp;</td>
          <td width="243"><input type="submit" name="Submit" value="Change Password"  class="btn1" /></td>
        </tr>
        <tr>
          <td width="136">&nbsp;</td>
          <td width="243">&nbsp;</td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
