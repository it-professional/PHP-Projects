<?php
include("openconn.php");
include("functions.php");


//header("location:index.php");
$hid="";
$masg=0;
$active=0;
$uploadedimage = 'nopicture.jpg' ;
//$bigtitle ="" ;
//$subtitle = "" ;
//$option_heading = "" ;
//$image = "" ;
if(isset($_POST["add"]))
{
	$active=0;
	$masg=0;

	$bigtitle 		= $_POST["bigtitle"];
	$option_heading	= $_POST["option_heading"];
	
	$qry = "INSERT INTO tblhomemenues (strHeading , strDescription , strmenu) VALUES ('$bigtitle' ,'$option_heading' , 'LatestWork')";
	$res = mysql_query( $qry );
	if( $res )
	{
		$masg=1;
		$msg="Record Added Susccessfully";
	}
	else
	{
		$masg=1;
		$msg="This record Could not be Added.";
	}
			
}

			
//update values
if(isset($_POST["update"])){
	
	$active=0;
	$masg=0;

	$bigtitle 		= $_POST["bigtitle"];
	$option_heading	= $_POST["option_heading"];
	
	
	$heditid = $_POST["hid"];
	$qry ="update tblhomemenues set strHeading = '$bigtitle' , strDescription ='$option_heading' where iid= $heditid" ;
	$res = mysql_query( $qry );
			if( $res ){
				$masg=1;
				$msg="Record updated Susccessfully";
			}
			else{
				$masg=1;
				$msg="Record Could not be updated.";
			}
}
		

//delet value
if(isset($_POST["delete"]))
{
	$hid = $_POST["hiddendelete"];
	$strQRY="Delete from tblhomemenues where iid ='".$_POST["hiddendelete"]."'";
	$nRst=mysql_query($strQRY);
}
//select value
if(isset($_POST["edit"]))
{
	$hid=$_POST["hiddenedit"];
	$qry = "select * from tblhomemenues where iid='$hid'";
	$res	= mysql_query($qry);
	$obj	= mysql_fetch_object($res);
	$option_heading	= $obj->strDescription;
	$bigtitle	= $obj->strHeading ;
	
	//print $product;
	//print $Pic."<br>";
}
?>
<script language="javascript">
function formCheck(formobj){
formobj = eval(formobj);
//alert(formobj1.txtProduct.value);
	// Enter name of mandatory fields
	
var fieldRequired = Array("option_heading");
	// Enter field description to appear in the dialog box
	var fieldDescription = Array("Latest News");
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].value == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "password":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}
	if (alertMsg.length == l_Msg)
	{
		return true;
	}
	else{
		alert(alertMsg);
		return false;
	}}

function del_confirm(){	var answer = confirm ("Do you really want to delete this Event?")
	if (answer)	 return true;
	else  return false;}

function IsNumeric(strString) {
   var strValidChars = "0123456789.-";
   var strChar;
   var blnResult = true;

   if (strString.length == 0) return false;

   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }
	  if(blnResult == false)
	  	{alert("Only Numeric Value is Acceptable!")
		//form25.txtvalue.focus();
		}
		
   return blnResult;
   }

<!--
function popitup(url) {
	newwindow=window.open(url,'name','height=400,width=500');
	if (window.focus) {newwindow.focus()}
	return false; }

function add_option(p_opt_id)
	{
	alert(p_opt_id);
	
	
	}
// -->
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/javascript" src="editor/wysiwyg.js"></script>
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="101%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong> Latest Work </strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" background="images/inner_06.jpg"><table width="93%" border="0" cellpadding="6" cellspacing="2" class="innertable">
      <tr>
        <td width="100%" valign="top"><form action="#" method="post" enctype="multipart/form-data" name="frmhome" onSubmit="return formCheck('frmhome');">
        <input type="hidden" name="hid" value="<?php echo $hid?>">
        <input type="hidden" name="oldimg" value="<?php echo $image?>">
   
     
          <table width="100%" border="0" cellspacing="3" cellpadding="0" class="singleborder">
            <tr>
              <td colspan="2">&nbsp;</td>
              </tr>
			  
			  
			  <tr>
              <td width="25%"><div align="right">Heading</div></td>
              <td><div align="left">
                <label>
                <input name="bigtitle" type="text" class="textbox1" id="bigtitle" value="<?php echo $bigtitle ?>">
                </label>
              </div></td>
            </tr>
			
                        
            <tr>
              <td><div align="right">Description</div></td>
              <td><div align="left">
              <textarea id="option_heading" name="option_heading" ><?php echo $option_heading?></textarea>
				<script language="javascript">
					generate_wysiwyg('option_heading');
				</script>
              </div></td>
            </tr>
            
            <tr>
              <td><div align="right"></div></td>
              <td><div align="left">
				<?php if(isset ($_POST["edit"])){?>	
                <input name="update" type="submit" class="btn1" id="update" value="Update">
                <?php }else{?>
                <input name="add" type="submit" class="btn1" id="add" value="   Add   ">
                <?php }?>
              </div></td>
            </tr>
          </table>
                </form>
        </td>
      </tr>
	  
    </table></td>
  </tr>
  <tr>
    <td>
	
<table width="100%" border="0" cellspacing="0" cellpadding="0"> 
	<tr> 
   		<td width="10%" height="20" align="center" background="images/bg_part.gif" class="formtext">Heading</td>		
    	<td width="30%" height="20" align="center" background="images/bg_part.gif" class="formtext">Description</td>
       	<td height="20" colspan="3" align="center" background="images/bg_part.gif" class="formtext">Options</td>
  </tr>
  <?php  
$qry 	= "Select * from tblhomemenues where strmenu = 'LatestWork' order by iid asc";	
$ress 	= mysql_query($qry);
while($objj = mysql_fetch_array($ress)) 
	{
	?>
	<form name="frm" method="post" action="#">
			<tr> 
			<td width="10%" height="30" align="center" class="tdfeatured">
			 	 	
				 <?php
				 echo $objj['strHeading'];
				 
				 ?>
				 
				 
				 
				 	</td>
				
			  <td width="80%" height="30" align="center" class="tdfeatured">
			 	 
				 
				  <?php
				 echo $objj['strDescription'];
				 
				 ?>
				 
				 
				 		</td>
		   	

				<td height="30" align="right" class="tdfeatured"><div align="center">
				  <input name="edit" type="submit" class="btn1" value="EDIT" id="edit" />
				  <input type="hidden" value="<?php  echo $objj->iid?>" name="hiddenedit" />
			    </div></td>
				<td width="10%" height="30" align="center" class="tdfeatured"> 
					 <div align="center">
					   <input name="delete" type="submit" class="btn1" onClick="return del_confirm();" value="DELETE" id="delete">
					   <input type="hidden" value="<?php echo $objj->iid?>" name="hiddendelete">			
			      </div></td>
			</tr>
	</form>
  
<?php
}
?>
			<tr>
			  <td height="30">&nbsp;</td>
			  <td height="30">&nbsp;</td>
			  <td height="30" align="center">			  </td>
			  <td height="30" align="center">			  </td>
			  <td height="30" colspan="2" align="right">&nbsp;</td>
			  <td height="30" align="center">&nbsp;</td>
		  </tr>
</table>	</td>
  </tr>
  <tr>
    <td>
    
    
    </td>
  </tr>
</table>
</body>
</html>
