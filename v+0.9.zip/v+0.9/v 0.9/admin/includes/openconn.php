<?php

$dbhost   = 'localhost';
$dbname   = 'ebay';
$dbusername   = 'root';
$dbuserpass = '';        
mysql_connect ($dbhost, $dbusername, $dbuserpass);
mysql_select_db($dbname) or die('Cannot select database');


?>
