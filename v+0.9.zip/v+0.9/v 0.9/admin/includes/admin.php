<?
include("openconn.php");
//header("location:index.php");
$hid="";
$masg=0;
$active=0;
$password="";
$email="";
$name ="";
$password="";
$ques="";
$ans="";

if(isset($_POST["Submit"]))
	{
	//$code =md5($username);
	$active=0;
	$masg=0;

	$name=$_POST['txtName'];		
	$ques=$_POST['txtQuestion'];
	$ans=$_POST['txtAnswer'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	$qry="select * from admin where Email ='$email'";
	$ress=mysql_query($qry);
	$objj = mysql_fetch_object($ress);
	$counts = mysql_num_rows($ress);
	
	//$counts = mysql_num_rows($results);
	
	
	for($k=1;$k<=$counts;$k++)
	{
	
		$emails= $objj->Email;
		
		if($emails==$email)
		{
			$masg=1;
			$msg="This email address already exists.  Please choose another email address.";
		}
	}
	
	if($masg!=1)
	{
	$qry = "Insert Into Admin (Name, Email, Password, SecurityQuestion, SecurityAnswer)Values ('$name', '$email','$password','$ques','$ans')";
	$res = mysql_query( $qry );
	if($res)
		$msg = "Admin Inserted Successfull";
	else
		$msg = "Admin Could not be Added";
	}
}


//update values

if(isset($_POST["Submit3"]))
	{
		$active=0;
	$masg=0;
	
	$name=$_POST['txtName'];		
	$ques=$_POST['txtQuestion'];
	$ans=$_POST['txtAnswer'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	$txtid= $_POST['txtid'];
		  
	$strQry = "UPDATE admin set password ='$password',Email='$email',Name ='$name', SecurityQuestion = '$ques' , SecurityAnswer = '$ans'  where AdminID=".$_POST['txtid'];
	
	$nRst=mysql_query($strQry) or die("Unable 2 Add the Record");
}

//delet value
if(isset($_POST["Submit4"]))
{
	$hid=$_POST["hiddendelete"];
	$strQRY="Delete from admin where AdminID='".$_POST["hiddendelete"]."'";
	$nRst=mysql_query($strQRY);
	//header("Location: index.php?pg=client");
}



//select value
if(isset($_POST["Submit44"]))
{
	$hid=$_POST["hidAdminid"];
	$qry = "select * from admin where AdminID='$hid'";
	$res = mysql_query($qry);
	$obj = mysql_fetch_object($res);
	
	$name= $obj->Name;		
	$ques=$obj->SecurityQuestion;
	$ans=$obj->SecurityAnswer;
	$email=$obj->Email;
	$password=$obj->Password;
	
}

?>
<script language="javascript">
function checkEmail() {
if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form25.email.value))
{
return (true)
}
//alert("Invalid E-mail Address! Please re-enter.")
else
{
 return (false)
}
}

</script>




<script language="javascript">
function formCheck(formobj){
	// Enter name of mandatory fields
var fieldRequired = Array("txtcompanyname","txtaddress1","txtcity","txtstate","txtzip","txtfullname","txtphone","email","password");
	// Enter field description to appear in the dialog box
	var fieldDescription = Array("Company Name","Address1","City","State","Zip","Full Name","Phone","Email","Password");
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].value == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "password":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}
	
	
	if(document.form25.password.value!=document.form25.cpassword.value)
	{
	alertMsg += " - Password and confirm password not match\n";
	
	}
	
	if(checkEmail()==false)
	alertMsg += " - Invalid email address\n";
	
	if (alertMsg.length == l_Msg)
	{
		return true;
	}
	else{
		alert(alertMsg);
		return false;
	}
	if(isNaN(myForm.age.value)) 
   { 
     alert("Invalid data format.\n\nOnly numbers are allowed."); 
     myForm.age.focus(); 
     return (false); 
   }

}
function del_confirm()
{
	var answer = confirm ("Do you really want to delete this Administrator?")
	if (answer)	 return true;
	else  return false;
}


</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="101%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong> Admin Accounts </strong></span><strong>&nbsp;&nbsp;</strong></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" background="images/inner_06.jpg"><table width="93%" border="0" cellpadding="6" cellspacing="2" class="innertable">
      <tr>
        <td width="100%" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center"><form action="#" method="post" enctype="multipart/form-data" name="form25" id="form25" onSubmit="return formCheck(this);">
                  <div align="center"> <span class="subhead1r"> </span><span class="messages"> </span>
                      <table width="739" border="0" align="center" cellpadding="3" cellspacing="0" bgcolor="#999999" class="singleborder">
                        <tr>
                          <td width="235" class="subhead1">&nbsp;</td>
                          <td class="subhead1"><? 
						if($masg==2){echo $mesg;}
						
						if($masg==1){echo $msg;}   ?></td>
                        </tr>
                        <tr>
                          <td  class="NormalText"><div align="right" class="fonte">*Admin Name: </div></td>
                          <td class="subhead1"><input name="txtName" type="text" class="textbox1" id="txtcompanyname" value="<?=$name?>" size="32" />
                              <input type="hidden" name="txtid" size="32" value="<?=$hid?>" />                          </td>
                        </tr>
                        <tr>
                          <td  class="NormalText"><div align="right" class="fonte">*Password: </div></td>
                          <td class="subhead1"><input name="password" type="password" class="textbox1"  id="txtaddress1" value="<?=$password?>" size="32"/></td>
                        </tr>
                        <tr>
                          <td  class="NormalText"><div align="right" class="fonte">Email Address: </div></td>
                          <td class="subhead1"><input name="email" type="text" class="textbox1"  id="txtaddress2" value="<?=$email?>" size="32"/></td>
                        </tr>
                        <tr>
                          <td  class="NormalText"><div align="right" class="fonte">*Security Question:</div></td>
                          <td class="subhead1"><input name="txtQuestion" type="text" class="textbox1" id="txtzip" value="<?=$ques?>" size="15"/>	  </td>
                        </tr>
						 <tr>
                          <td  class="NormalText"><div align="right" class="fonte">*Security Answer:</div></td>
                          <td class="subhead1"><input name="txtAnswer" type="text" class="textbox1" id="txtzip" value="<?=$ans?>" size="15"/>	  </td>
                        </tr>
                        <tr>
                          <td class="regulartext">&nbsp;</td>
                          <td><?
				  if(isset($_POST["Submit44"]))
		{
		?>
                              <input name="Submit3" type="submit" class="btn1" value="Update Admin" />
                              <?
		}
		else
		{
		?>
                              <input name="Submit" type="submit" class="btn1" value="Add Admin" />
                              <? }?>                          </td>
                        </tr>
                      </table>
                  </div>
              </form></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
 <form id="formsearch" name="formsearch" method="post" action="index.php?pg=admin">
  <tr>
    <td height="33" colspan="3" class="fonte">
        
          <div align="left">
            <table width="100%" border="0">
              <tr>
                <td width="43%"><div align="right"><span class="fonte">User Search&nbsp;(By Full Name) </span></div></td>
                <td width="57%"><span class="textleftmenu1">
                  <input name="txtcname" type="text" class="textbox1" id="txtcname" size="30" />
                </span>
                  <input name="btnsearch" type="submit" class="btn1" id="btnsearch" value="Search" /></td>
              </tr>
            </table>
          </div>          </td>
    <td class="fonte">&nbsp;</td>
    <td height="33" colspan="2" class="fonte">&nbsp;</td>
  </tr>
  </form> 
  
  <tr> 
    <td width="11%" height="20" class="fonte" background="images/bg_part.gif"><div align="center" class="formtext">ID</div></td>
    <td width="25%" height="20" class="formtext" background="images/bg_part.gif">Username</td>
    <td width="26%" background="images/bg_part.gif" class="fonte"><span class="formtext">Email
      </span>
      <div align="center"></div></td>
    <td width="22%" class="fonte" background="images/bg_part.gif">&nbsp;
      <label for="checkbox_row_4" class="formtext" onClick="return (document.getElementById('checkbox_row_4') ? false : true)">Security Question </label></td>
    <td height="20" colspan="2" background="images/bg_part.gif" class="fonte"> 
    <div align="center"></div>     
    <div align="center" class="formtext">Options</div></td>
  </tr>
  <?  
  
 if(isset($_POST['txtcname']))
{
$sclient=$_POST['txtcname'];//die("dadasd");
$qry="Select * from admin where Name='".$sclient."' order by AdminID ";
}

else{
$qry="Select * from admin order by AdminID ";	
  }	
	
	$ress=mysql_query($qry);

$objj=mysql_fetch_object($ress); 
$count = mysql_num_rows($ress);
for($j=1;$j<=$count;$j++)
{
?>
  <form name="frm" method="post" action="#">
  <tr> 
    <td width="11%" class="uline" height="30"> 
      <div align="center"><font size="2" face="Verdana, Arials, Helvetica, sans-serif">
        <input type="hidden" name="hidAdminid" value="<?=$objj->AdminID?>">
        <?=$objj->AdminID?>
      </font></div>    </td>
    <td width="25%" height="30" class="uline"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?=$objj->Name?>
      </font></td>
    <td height="30" class="uline"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
      <?=$objj->Email?>
    </font></td>
    <td width="22%" height="30" class="uline"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
      <?=$objj->SecurityQuestion;  ?>
    </font></td>
    <td width="7%" height="30" align="right" class="uline"><a href="index.php?pg=vpoints&amp;uid=<?=$objj->AdminID ?>"></a>
      <input name="Submit44" type="submit" class="btn1" value="EDIT" />
      <input type="hidden" value="<?=$objj->AdminID ?>" name="hiddenedit" /></td>
    <td width="9%" height="30" align="left" class="uline"> 
      <div align="center"> 
	  	<input type="hidden" value="<?=$objj->AdminID ?>" name="hiddendelete">
        <input name="Submit4" type="submit" class="btn1" onClick="return del_confirm();" value="DELETE">
      </div>    </td>
  </tr>
  </form>
  <?
$objj=mysql_fetch_object($ress);
}
?>
  <tr> 
    <td width="11%">&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td>&nbsp;</td>
    <td width="9%">&nbsp;</td>
  </tr>
</table>
	
	
	</td>
  </tr>
</table>
</body>
</html>
