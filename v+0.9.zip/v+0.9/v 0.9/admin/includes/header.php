<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" align="right"><img src="images/header_icon.png" width="46" height="38" align="right"></td>
    <td width="30%" background="images/background.gif"><div align="left"><span class="tophead1">PickmeFriend</span><span class="tophead"> </span></div></td>
    <td width="66%" background="images/header_blue.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>&nbsp;</td>
        <td colspan="2"><table width="330" border="0" align="right" cellpadding="0" cellspacing="0">
          <tr>
            <td width="73"><span class="style14">Username:</span></td>
            <td width="92"><span class="style15"><b>
              <?=$_SESSION['username'];?>
            </b></span></td>
            <td width="103"><span class="style14">Security Level:</span></td>
            <td width="62"><b class="style15">
              <?=$_SESSION['security_level'];?>
            </b></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
