<link href="css/style" rel="stylesheet" type="text/css" />
<link href="../css/style" rel="stylesheet" type="text/css" />

<script language="javascript">

function NewWindow(mypage,myname,w,h,scroll,resize)
{
	w=w-50;
	var winl = (screen.width-w)/2;
	var wint = (screen.height-h)/2;
	var settings  ='height='+h+',';
	settings +='width='+w+',';
	settings +='top='+wint+',';
	settings +='left='+winl+',';
	settings +='scrollbars='+scroll+',';
	settings +='resizable='+resize;
	win=window.open(mypage,myname,settings);
	if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
}

function managecontent()
{
	NewWindow("includes/pagecontent.php","frmAddProperty",'800','550','Yes','No');	
}



</script>

<style type="text/css">
<!--
.style234 {color: #FFFFFF}
.DottedBorder {
	border-top-width: 0px;
	border-right-width: 0px;
	border-bottom-width: 1px;
	border-left-width: 0px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #03E25C;
	border-right-color: #03E25C;
	border-bottom-color: #03E25C;
	border-left-color: #03E25C;
}
.style111 {color: #FFFF00}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style4 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
<table width="204" border="0" align="left" cellpadding="3" cellspacing="3" bgcolor="#f1f3f5">
  
  <tr>
    <td width="192">&nbsp;</td>
  </tr>

  
  <!--
  <tr>
    <td bgcolor="#028034" class="DottedBorder"><a href="#"><span class="heads style234" style="text-decoration:none">MY SETTINGS </span></a></td>
  </tr>
  <tr>
    <td class="DottedBorder"><a href="index.php?pg=acsettings"><span class="heads style234" style="text-decoration:none"><span class="style111">- Account settings </span></span></a></td>
  </tr>
  <tr>
    <td class="DottedBorder"><a href="index.php?pg=manual"><span class="heads style234" style="text-decoration:none"><span class="style111">- Show settings </span></span></a></td>
  </tr>
  <tr>
    <td class="DottedBorder"><a href="index.php?pg=manual2"><span class="heads style234" style="text-decoration:none"><span class="style111">- Category-video settings </span></span></a></td>
  </tr>
  -->
      <tr>
       <td class="tbl"><span class="menuehead">Manage Content</span></td>
  </tr>
  
	 
<tr>
  <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=Latestwork" class="NavLinksbot1">Manage Latest Work</a></td>
 </tr>
 
 <tr>
  <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=productchar" class="NavLinksbot1">Manage Product Characteristics</a></td>
 </tr>
 
 <tr>
  <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=productcharattributes" class="NavLinksbot1">Manage Product Characteristics<br />&nbsp;&nbsp;&nbsp; Attributes</a></td>
 </tr>
 
  <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=RegisteredUsers" class="NavLinksbot1">Manage Users </a></td>
     </tr>
 
 <!--<tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=ReleaseMoneyUsers" class="NavLinksbot1">Manage Release Money User's</a></td>
     </tr>
 <tr>-->
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=Mediation" class="NavLinksbot1">Manage Mediation Between Users</a></td>
     </tr>
	 
	  <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=ContactUs" class="NavLinksbot1">Manage Contact Us Messages</a></td>
     </tr>
	 
	 <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=Commission" class="NavLinksbot1">Manage Commissions </a></td>
     </tr>
	  <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=ReportAbuses" class="NavLinksbot1">Manage Report Abuses </a></td>
     </tr>
 
 <!--<tr>
  <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=menu1" class="NavLinksbot1">Manage Menu 1</a></td>
 </tr> 
  <tr>
  <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=menu2" class="NavLinksbot1">Manage Menu 2</a></td>
 </tr>-->
 
	  <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=Aboutus" class="NavLinksbot1">Manage About Us</a></td>
     </tr>
	 <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=legal" class="NavLinksbot1">Manage Legal</a></td>
     </tr>
	 
	 	 
	 <tr>
       <td><img src="images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=TOS" class="NavLinksbot1">Manage Terms Of Services</a></td>
     </tr>
	
  <tr>
    <td class="tbl"><a href="login.php?logout=logout" class="menuehead" style="text-decoration:none">LOGOUT</a></td>
  </tr>
  <tr>
    <td>
		<img src="images/arrow.gif" width="10" height="10" />
		<a href="index.php?pg=changpass" class="NavLinksbot1">&nbsp;</a>
		<a href="index.php?pg=wisdom" class="NavLinksbot1"></a>
		<a href="index.php?pg=changpass" class="NavLinksbot1">Change Password</a>	</td>
  </tr>
  
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  
  <tr>
    <td class="fonte">&nbsp;</td>
  </tr>
  <tr>
    <td class="fonte"><div align="center"></div></td>
  </tr>
</table>

