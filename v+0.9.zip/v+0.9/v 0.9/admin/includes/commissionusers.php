<?php
include("openconn.php");
$bigtitle = "" ;
$title = "" ;
$subtitle = "" ;
$image = "" ;
?>
<?php
if(isset($_POST['hdnstatus']) && $_POST['hdnstatus'] != "")
{
	$gethid =     $_POST['comisionid'] ; 
	$status =  $_POST['hdnstatus'] ;
	$newquery123 = mysql_query("SELECT * FROM tblcommission WHERE iid = '$gethid'");		
	$getboughtdata = mysql_fetch_array($newquery123) ;
	$getsellerid123 =  $getboughtdata['isellerid'];
	$query2 = mysql_query("UPDATE tblmember SET istatus = '$status' WHERE iid = '$getsellerid123'");
	
}

?>

<script language="javascript">
function NewWindow(mypage,myname,w,h,scroll,resize)
{
			w=w-100;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
}
function sendnotice(cid)
{

	NewWindow("sendnotice.php?cid="+cid,"sendnotice",'600','420','Yes','No');
}

function viewmessage2(id)
{

window.open("viewmessage.php?id="+id,"View Email Message","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=150, height=140");

}
function confirmation()
{
	var confirm1 = "" ;
	if(status == 0)
	{
		confirm1 = confirm("Are you sure you want to Bann this User. ");
	}
	else
	{
		confirm1 = confirm("Are you sure you want to Active this User. ");
	}	

if(confirm1 == true)
{
//alert("bannuser.php?id="+iid+"&setstatus="+status) ;
 window.location.href = "bannuser.php?id="+iid+"&setstatus="+status ; 
}
}

function bannconfirmation()
{
	var answer = confirm ("Do you really want to Bann this User?")
	if (answer)	 return true;
	else  return false;
}
function activeconfirmation()
{
	var answer = confirm ("Do you really want to Active this User?")
	if (answer)	 return true;
	else  return false;
}
</script>
<head>
<title>PickmeFriend</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table  border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong>Manage Commission's</strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr >
    <td align="center" valign="top" background="images/inner_06.jpg" ><table  border="0" cellpadding="0" cellspacing="0" class="innertable">
      <tr>
        <td  valign="top" >
			<table cellpadding="0"   cellspacing="0" border="0">
			<tr background="images/bg_part.gif">
			<td class="formtext" ><b>Seller Name</b></td>
			<td class="formtext" style="padding-left:8px;" ><b>Country</b></td>
			<td class="formtext" style="padding-left:8px;" ><b>Native Language</b></td>
			<td class="formtext" style="padding-left:8px;" ><b>Social Network</b></td>
			<td class="formtext" style="padding-left:8px;" ><b>Average Rating</b></td>
			<td class="formtext" style="padding-left:8px;"><b>Product Name</b></td>
			<td class="formtext" style="padding-left:8px;" ><b>Product Amount</b></td>
			<td class="formtext" align="left" style="padding-left:8px;" ><b>Commission</b></td>
			<td class="formtext" align="left" style="padding-left:8px;" ><b>Sold Date</b></td>
			<td class="formtext" align="left" style="padding-left:8px;" ><b>Due Date</b></td>
			<td class="formtext" align="left" style="padding-left:8px;" ><b>Status</b></td>
			<td class="formtext"  align="right" >&nbsp;</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		<?php
		$query = mysql_query("SELECT * FROM tblcommission WHERE istatus = '0' order by iid asc");	
		//echo "SELECT * FROM tblcommission WHERE istatus = '0' order by iid asc" ;
			
		$rows = mysql_num_rows($query);
		if($rows > 0)
		{
			while($bought = mysql_fetch_array($query))
			{
				$id = $bought['iid'];
				$prodid =  $bought['ipid'];
				$sellerid =  $bought['isellerid'];
				$productamount = $bought['iproductamount'];
				$commisison = $bought['icommission'];
				$date =  $bought['ddate'];
				$duedate = $bought['dduedate'];
				$status = $bought['istatus'];
				
				if($status == 0)
				{
					$status2 = "Not Paid" ;
				}
				else
				{
					$status2 = "Paid" ;
				}
				
				 
				$query2 = mysql_query("select * from tblproducts where iid = '$prodid'  order by iid asc ");
				$rows2 = mysql_num_rows($query2);
				$data2 = mysql_fetch_array($query2);
				$strproductname = $data2['strproductname'] ;
				
				$query3 = mysql_query("select * from tblmember where iid = '$sellerid'");
				$data3 = mysql_fetch_array($query3);
				$strsellerfirstname = $data3['strfirstname'] ;	
				$strsellerlasttname = $data3['strlastname'] ;
				$strsellercountry = $data3['strcountry'] ;
				$strnativelang = $data3['strnativelang'] ;
				$strsocialnetwork = $data3['strsocialnetwork'] ;
				$sellerstatus = $data3['istatus'] ;
				
				$ratingquery = mysql_query("select * from  tblrating where iratingto = '$sellerid' order by iid asc");
				$ratingrows = mysql_num_rows($ratingquery);
				if($ratingrows  > 0)
					{
						while($ratingdata = mysql_fetch_array($ratingquery))
						{
							$rating = $rating + $ratingdata['irating'] ;
							$ratingcomments = $ratingdata['strdescription'] ;
						}
						//$ratingaverage = $rating / $ratingrows ;	
						$ratingaverage2 = $rating / $ratingrows ;
						$ratingaverage = number_format($ratingaverage2,2);
						$roundratingavg = round($ratingaverage);
						if($roundratingavg == 1)	
						{
							$strrating = "Horrible" ;
							$strimage = "horrible.gif" ;
						}
						else if($roundratingavg == 2)	
						{
							$strrating = "Bad" ;
							$strimage = "bad.gif" ;
						}
						else if($roundratingavg == 3)	
						{
							$strrating = "Poor" ;
							$strimage = "poor.gif" ;
						}
						else if($roundratingavg == 4)	
						{
							$strrating = "Below Average" ;
							$strimage = "belowavg.gif" ;
						}
						else if($roundratingavg == 5)	
						{
							$strrating = "Average" ;
							$strimage = "average.gif" ;
						}
						else if($roundratingavg == 6)	
						{
							$strrating = "Above Average" ;
							$strimage = "aboveavg.gif" ;
						}
						else if($roundratingavg == 7)	
						{
							$strrating = "Good" ;
							$strimage = "good.gif" ;
						}
						else if($roundratingavg == 8)	
						{
							$strrating = "Very Good" ;
							$strimage = "vgood.gif" ;
						}
						else if($roundratingavg == 9)	
						{
							$strrating = "Superb" ;
							$strimage = "superb.gif" ;
						}
						else if($roundratingavg == 10)	
						{
							$strrating = "Excellent" ;
							$strimage = "excellent.gif" ;
						}
					}
					else
					{
							$strrating = "Not Rated" ;
							$strimage = "" ;
					}
				
				
					?>
			<tr >
			<td class="tdfeatured" ><?php echo $strsellerfirstname.  $strsellerlasttname ;?></td>
			<td class="tdfeatured" style="padding-left:8px;"  ><?php echo $strsellercountry ;?></td>
			<td class="tdfeatured" style="padding-left:8px;"  ><?php echo $strnativelang ;?></td>
			<td class="tdfeatured" style="padding-left:8px;"  ><?php echo $strsocialnetwork ;?></td>
			<td class="tdfeatured" style="padding-left:8px;" ><?php echo $ratingaverage." (".$strrating." )" ;?></td>
			<td class="tdfeatured" style="padding-left:8px;"  ><?php echo $strproductname ;?></td>
			<td class="tdfeatured"  style="padding-left:8px;" align="center" >$<?php echo $productamount ;?>.00</td>
			<td class="tdfeatured" style="padding-left:8px;" >$<?php echo $commisison ;?>.00</td>
			<td class="tdfeatured" style="padding-left:8px;"><?php echo $date ;?></td>
			<td class="tdfeatured" style="padding-left:8px;"><?php echo $duedate ;?></td>
			<td class="tdfeatured" style="padding-left:8px;"><?php echo $status2 ; ?></td>
	
				<td class="tdfeatured" >
				<form name="commissionusersform" action="#" method="post">
					<input  type="button" class="btn1" value=" Send Notice " onClick="javascript: sendnotice(<?php echo $id ; ?>)">
					<?php if($sellerstatus == 1) { ?>
					<input  type="submit" class="btn1" value=" Banned User" onClick="return bannconfirmation()">
					<input type="hidden" name="comisionid" value="<?php echo $id ;?>">
					<input type="hidden" name="hdnstatus" value="0">
					<?php } else { ?>
					<input  type="submit" name="submit" id="submit" class="btn1" value=" Active User " onClick="return activeconfirmation()">
					<input type="hidden" name="hdnstatus" value="1">
					<input type="hidden" name="comisionid" value="<?php echo $id ;?>">
					<?php } ?>
				</form>	
				</td>
			</tr>
			<?php
				}
			}
			else
			{
			?>
			<tr background="images/bg_part.gif">
			
			<td class="formtext" colspan="11" align="center">No Users to pay Commission.</td>
			
			</tr>
			<?php
			}
			?>
			</table>
		 </td>
      </tr>
	
    </table></td>
  </tr>
  
</table>
</body>
</html>
