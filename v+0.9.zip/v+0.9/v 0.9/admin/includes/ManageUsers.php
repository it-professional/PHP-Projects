<?php
include("openconn.php");
$bigtitle = "" ;
$title = "" ;
$subtitle = "" ;
$image = "" ;
?>
<?php
if(isset($_POST['hdnstatus']) && $_POST['hdnstatus'] != "")
{
	$userid =     $_POST['userid'] ; 
	$status =  $_POST['hdnstatus'] ;
	$query2 = mysql_query("UPDATE tblmember SET istatus = '$status' WHERE iid = '$userid'");
}

?>

<script language="javascript">
function NewWindow(mypage,myname,w,h,scroll,resize)
{
			w=w-100;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
}
function sendwarning(cid)
{

	NewWindow("sendwarning.php?cid="+cid,"sendnotice",'640','420','Yes','No');
}

function viewmessage2(id)
{

window.open("viewmessage.php?id="+id,"View Email Message","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=150, height=140");

}
function confirmation()
{
	var confirm1 = "" ;
	if(status == 0)
	{
		confirm1 = confirm("Are you sure you want to Bann this User. ");
	}
	else
	{
		confirm1 = confirm("Are you sure you want to Active this User. ");
	}	

if(confirm1 == true)
{
//alert("bannuser.php?id="+iid+"&setstatus="+status) ;
 window.location.href = "bannuser.php?id="+iid+"&setstatus="+status ; 
}
}

function bannconfirmation()
{
	var answer = confirm ("Do you really want to Bann this User?")
	if (answer)	 return true;
	else  return false;
}
function activeconfirmation()
{
	var answer = confirm ("Do you really want to Active this User?")
	if (answer)	 return true;
	else  return false;
}
</script>
<head>
<title>PickmeFriend</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table  border="0"  width="100%" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong>Manage Registered User's</strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr >
    <td align="center" valign="top" background="images/inner_06.jpg" ><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="innertable">
      <tr>
        <td  valign="top" >
			<table cellpadding="0" width="100%"   cellspacing="0" border="0">
			<tr background="images/bg_part.gif">
			<td class="formtext" width="10%" ><b>Name</b></td>
			<td class="formtext" width="15%" ><b>Email</b></td>
			<td class="formtext" width="10%"  ><b>Country</b></td>
			<td class="formtext"  width="15%"><b>Native Language</b></td>
			<td class="formtext"  width="15%"><b>Social Network</b></td>
			<td class="formtext" width="15%" ><b>Average Rating</b></td>
			<td class="formtext" align="left"  width="15%"><b>Status</b></td>
			<td class="formtext"  align="right" width="10%">&nbsp;</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		<?php
			
				$query3 = mysql_query("select * from tblmember order by iid desc");
				$query3rows = mysql_num_rows($query3);
				if($query3rows > 0)
				{
					while($data3 = mysql_fetch_array($query3))
					{
						$userid = $data3['iid'] ;
						$strsellernickname = $data3['strnickname'] ;	
						$strselleremailaddress = $data3['stremail'] ;
						$strsellercountry = $data3['strcountry'] ;
						$strnativelang = $data3['strnativelang'] ;
						$strsocialnetwork = $data3['strsocialnetwork'] ;
						$sellerstatus = $data3['istatus'] ;
						$rating = 0 ;
						$ratingaverage = "" ;
						
						if($sellerstatus == 0)
						{
							$userstatus = "Banned" ;
						}
						else
						{
							$userstatus = "Active" ;
						}	
						
						$ratingquery = mysql_query("select * from  tblrating where iratingto = '$userid' order by iid asc");
						$ratingrows = mysql_num_rows($ratingquery);
						if($ratingrows  > 0)
							{
								while($ratingdata = mysql_fetch_array($ratingquery))
								{
									$rating = $rating + $ratingdata['irating'] ;
									$ratingcomments = $ratingdata['strdescription'] ;
								}
								//$ratingaverage = $rating / $ratingrows ;	
								$ratingaverage2 = $rating / $ratingrows ;
								$ratingaverage = number_format($ratingaverage2,2);
								$roundratingavg = round($ratingaverage);
								if($roundratingavg == 1)	
								{
									$strrating = "Horrible" ;
									$strimage = "horrible.gif" ;
								}
								else if($roundratingavg == 2)	
								{
									$strrating = "Bad" ;
									$strimage = "bad.gif" ;
								}
								else if($roundratingavg == 3)	
								{
									$strrating = "Poor" ;
									$strimage = "poor.gif" ;
								}
								else if($roundratingavg == 4)	
								{
									$strrating = "Below Average" ;
									$strimage = "belowavg.gif" ;
								}
								else if($roundratingavg == 5)	
								{
									$strrating = "Average" ;
									$strimage = "average.gif" ;
								}
								else if($roundratingavg == 6)	
								{
									$strrating = "Above Average" ;
									$strimage = "aboveavg.gif" ;
								}
								else if($roundratingavg == 7)	
								{
									$strrating = "Good" ;
									$strimage = "good.gif" ;
								}
								else if($roundratingavg == 8)	
								{
									$strrating = "Very Good" ;
									$strimage = "vgood.gif" ;
								}
								else if($roundratingavg == 9)	
								{
									$strrating = "Superb" ;
									$strimage = "superb.gif" ;
								}
								else if($roundratingavg == 10)	
								{
									$strrating = "Excellent" ;
									$strimage = "excellent.gif" ;
								}
							}
							else
							{
									$strrating = "Not Rated" ;
									$strimage = "" ;
							}
						
					
					?>
			<tr >
			<td class="tdfeatured" width="10%"><?php echo $strsellernickname ; ?></td>
			<td class="tdfeatured" width="15%"><?php echo $strselleremailaddress ; ?></td>
			<td class="tdfeatured" width="10%"  ><?php echo $strsellercountry ;?></td>
			<td class="tdfeatured" width="15%"><?php echo $strnativelang ;?></td>
			<td class="tdfeatured" width="15%"  ><?php echo $strsocialnetwork ;?></td>
			<td class="tdfeatured" width="15%" ><?php echo $ratingaverage." (".$strrating." )" ;?></td>
			<td class="tdfeatured" width="15%"><?php echo $userstatus ; ?></td>
	
				<td class="tdfeatured" width="10%">
				<form name="commissionusersform" action="#" method="post">
					<input  type="button" class="btn1" value=" Send Warning " onClick="javascript: sendwarning(<?php echo $userid ; ?>)">
					<?php if($sellerstatus == 1) { ?>
					<input  type="submit" class="btn1" value=" Banned User" onClick="return bannconfirmation()">
					<input type="hidden" name="userid" value="<?php echo $userid ;?>">
					<input type="hidden" name="hdnstatus" value="0">
					<?php } else { ?>
					<input  type="submit" name="submit" id="submit" class="btn1" value=" Active User " onClick="return activeconfirmation()">
					<input type="hidden" name="hdnstatus" value="1">
					<input type="hidden" name="userid" value="<?php echo $userid ;?>">
					<?php } ?>
				</form>	
				</td>
			</tr>
			<?php
			}
			}
			else
			{
			?>
			<tr background="images/bg_part.gif">
			
			<td class="formtext" colspan="11" align="center">No Registered Users.</td>
			
			</tr>
			<?php
			}
			?>
			</table>
		 </td>
      </tr>
	
    </table></td>
  </tr>
  
</table>
</body>
</html>
