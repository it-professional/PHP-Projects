<?php
function addToCart( $id, $quantity )
{
	if($id != "")
	{	
		$query = "Select * from product where ProductID = '$cid'";
		$res = mysql_query( $query );
		$rows = mysql_num_rows( $res );
		$obj = mysql_query($res);
		if($rows < 1)
		{
			$msg = "This product is NO longer Available in the Stock";
			header("Location: cart.php");
		}
		$i = $_SESSION['count'];
		$_SESSION['productid'.$i] = $obj->ProductID;
		$_SESSION['Quantity'.$i] = quantity;
		$_SESSION['count'] = $_SESSION['count']+1;
		$msg = "Product Added Succefully in Cart";
		header("Location: cart.php");
	}
}

function createThumb($source,$dest) {
 
    $thumb_size = 336;
 	$y=0;
    $size = getimagesize($source);
    $width = $size[0];
    $height = $size[1];
 
    if($width> $height) {
        $x = ceil(($width - $height) / 2 );
        $width = $height;
    } elseif($height> $width) {
        $y = ceil(($height - $width) / 2);
        $height = 100;
    }
 
    $new_im = ImageCreatetruecolor($thumb_size,$thumb_size);
    $im = imagecreatefromjpeg($source);
    imagecopyresampled($new_im,$im,0,0,$x,$y,$thumb_size,$thumb_size,$width,$height);
    imagejpeg($new_im,$dest,100);
 
}

function createThumb_p($spath, $dpath, $maxd) {
 $src=@imagecreatefromjpeg($spath);
 if (!$src) {return false;} else {
  $srcw=imagesx($src);
  $srch=imagesy($src);
  if ($srcw<$srch) {$height=$maxd;$width=floor($srcw*$height/$srch);}
  else {$width=$maxd;$height=floor($srch*$width/$srcw);}
  if ($width>$srcw && $height>$srch) {$width=$srcw;$height=$srch;}  //if image is actually smaller than you want, leave small (remove this line to resize anyway)
  $thumb=imagecreatetruecolor($width, $height);
  if ($height<100) {imagecopyresized($thumb, $src, 0, 0, 0, 0, $width, $height, imagesx($src), imagesy($src));}
  else {imagecopyresampled($thumb, $src, 0, 0, 0, 0, $width, $height, imagesx($src), imagesy($src));}
  imagejpeg($thumb, $dpath);
  return true;
 }}

// Get MAx
function getMaximum($Table,$Field){

	
	$strQry="SELECT MAX(" . $Field . ")+1 as UID FROM " . $Table . " ";
	
	$nResult =mysql_query($strQry);

	if (mysql_num_rows($nResult)>=1){
		while ($row=mysql_fetch_object($nResult)){
			if(@$row->UID) 
				$maxID=$row->UID;
			else
				$maxID=1;
		}
	}	
	
	return $maxID;	
}

// Return name
function ReturnName($TableName,$FieldName,$IDField,$ID){

	
	$retName="";

	$strQry="SELECT $FieldName FROM $TableName WHERE $IDField=$ID";
	//print($strQry);

	$nResult =mysql_query($strQry) or die("Unable 2 Work");
	

	if (mysql_num_rows($nResult)>=1){
		
		$row=mysql_fetch_object($nResult);
		$retName=$row->$FieldName;
	}	
	
	return $retName;		
}


   ##############################################################################################################
   ##
   ##    create a thumb by resizing the image
   ##
   ##############################################################################################################
   function FcCreateThumbnail($imgPath,  $fileName,  $newWidth, $newHeight)
   {

    ###################################################################################
    ## $imgPath: path for the big image (the uplaoded one)
    ## $imgsmallPath : path for the small image
    ## $fileName : name for the already uploaded file
    ## $filesmallName :  name for the to be copied and resized trumbnail image
    ## $newWidth : the new width (to be used for the trumbnail)
    ## $newHeight : the new height (to be used for the trumbnail)
    ###################################################################################



    ################################
    ### getting the image in php ###
    ################################
    
    $im_file_name = $imgPath.'/'.$fileName;

    $image_attribs = @getimagesize($im_file_name);

    if($image_attribs[2] == '2'){

           $im_old = imagecreatefromjpeg($im_file_name);

    }elseif($image_attribs[2] == '1'){

           //echo $im_file_name;
           //$im_old = IMAGECREATEFROMGIF($im_file_name);
           //$im_old = IMAGECREATEFROMSTRING($);

    }elseif($image_attribs[2] == '3'){

           $im_old = imagecreatefrompng($im_file_name);

     }




     ######################################
     ### stting up the trumbnail object ###
     ######################################

     //$ratio = ($width > $height) ? $newWidth/$image_attribs[0] : $newHeight/$image_attribs[1];
     //$th_width = $image_attribs[0] * $ratio;
     //$th_height = $image_attribs[1] * $ratio;
     $th_width = $newWidth;
     $th_height = $newHeight;
     $im_new = imagecreatetruecolor($th_width,$th_height);
     imageAntiAlias($im_new,true);





     ###############################
     ### write ime image to dick ###
     ###############################

     // path + name of the file
  //  $th_file_name = $imgsmallPath.'/'.$filesmallName;

     // if image is a GIF copy it
     // GIF
   //  if($image_attribs[2] == '1')
    // {
           // copy the iamge as we do not have a function like this
      //     $raspuns = copy($im_file_name, $th_file_name);

     // else if the image JPG or PNG
     //}elseif($image_attribs[2] != '1'){

           // resample image (only JPG, PNG)
       //    @imagecopyresampled($im_new,$im_old,0,0,0,0,$th_width,$th_height, $image_attribs[0], $image_attribs[1]);

           //check to see if the image is JPG or PNG (no GIF allowed)
           // JPG
        //   if($image_attribs[2] == '2'){
				//die($im_new);
        //            $return = imagejpeg($im_new,$th_file_name,100);

           // PNG
         //  }elseif($image_attribs[2] == '3'){

          //          $return = imagepng($im_new,$th_file_name);

         //  }
      //}
     $myReturnArray = array($return, $file_nameNew);
      return $myReturnArray;
      }

?>
