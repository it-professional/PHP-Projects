<?php
include("openconn.php");

if(isset($_POST['deletemediation']))
{
	$gethdnmediationid = $_POST['hdndeletemediationid'] ; 
	$deletemediationquery2 = mysql_query("DELETE FROM tblmediationmessages WHERE imediationid = '$gethdnmediationid'");
	$deletemediationquery = mysql_query("DELETE FROM tblmediation  WHERE iid = '$gethdnmediationid'");	
}

?>


<html>
<head>
<script language="javascript">
function NewWindow(mypage,myname,w,h,scroll,resize)
{
			w=w-100;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
}
function viewmessage(pid,buyerid)
{

	NewWindow("viewmessages.php?PID="+pid+"&bid"+buyerid,"Viewmessages",'700','520','Yes','No');
}
function viewmediation(mediator)
{

	NewWindow("viewmediation.php?mediationid="+mediator,"viewmediation",'550','320','Yes','No');
}
function sendmessage(mediation,type)
{

	NewWindow("sendmessage.php?mediationid="+mediation+"&sendmessageto="+type,"sendmessage",'700','520','Yes','No');
}

function viewmessage2(id)
{

window.open("viewmessage.php?id="+id,"View Email Message","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=150, height=140");

}
function deleteconfirmation(iid)
{

var deleteconfirm = confirm("Are you sure you want to delete this Mediation .");

if(deleteconfirm == true)
{
	return true ;
}
else
{
	return false ;
}
}

</script>

<title>PickmeFriend</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/gh.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>
<body bgcolor="#88b7d5" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td rowspan="2"><img src="images/i_content.gif" alt="B" width="65" height="44" border="0" /></td>
        <td width="100%"><img src="images/pixel.gif" alt="C" width="1" height="24" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" align="right" background="images/bg_part.gif"><div align="left"> <span class="heads"><strong>Mediation Between Users</strong></span></div></td>
        <td><img src="images/end_part.gif" alt="A" width="25" height="20" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right" class="head"><div align="center"><?php if($masg == 1)echo $msg?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" background="images/inner_06.jpg"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="innertable">
      <tr>
        <td width="100%" valign="top">
			<table cellpadding="0"  cellspacing="0" border="0">
			<tr background="images/bg_part.gif" >
			<td class="formtext" width="10%" >Product Name</td>
			<td class="formtext" width="13%" >Mediator Nick</td>
			<td class="formtext" width="13%" >Opponent Nick</td>
			<td class="formtext" width="12%" >Favoured to</td>
			<td class="formtext" width="10%" >Phase</td>
			<td class="formtext" width="15%" >Mediation Start Date</td>
			<td class="formtext" width="15%" >Mediation Close Date</td>
			<td class="formtext" width="25%">&nbsp;</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<?php
			$query = mysql_query("SELECT * FROM tblmediation order by iid asc");
			$rows = mysql_num_rows($query);
			if($rows > 0)
			{
				while($data = mysql_fetch_array($query))
				{
					
					$mediationid = $data['iid'] ;
					$productid = $data['ipid'] ;
					$mediatorid = $data['imediatorid'] ;
					$mediationtoid = $data['itoid'] ;
					$mediationstartdate = $data['ddate'] ;
					$phase = $data['iphase'] ;
					$strfavoured = $data['strfavouredto'] ;
					$mediationclosedate = $data['dmediationclosedate'] ;
					
					if($phase > 0)
					{
						$strphase = "Closed" ;
					}
					else
					{
						$strphase = "Continued" ;
					}	
					
					$query2 = mysql_query("SELECT strproductname FROM tblproducts WHERE iid = '$productid'");
					$data2 = mysql_fetch_array($query2);
					$productname = $data2['strproductname'] ;
					
					$query3 = mysql_query("SELECT strnickname FROM tblmember WHERE iid = '$mediatorid'");
					$data3 = mysql_fetch_array($query3);
					$mediatornickname = $data3['strnickname'] ;
					
					$query3 = mysql_query("SELECT strnickname FROM tblmember WHERE iid = '$mediationtoid'");
					$data3 = mysql_fetch_array($query3);
					$mediationtoidnickname = $data3['strnickname'] ;
					
					
							
					
			?>
			<tr >
			<td width="10%" class="tdfeatured"><?php echo $productname ?></td>
			<td class="tdfeatured" width="13%" ><?php echo $mediatornickname ;?></td>
			<td class="tdfeatured" width="13%" ><?php echo $mediationtoidnickname ;?></td>
			<td class="tdfeatured" width="12%" ><?php echo $strfavoured ; ?></td>
			<td class="tdfeatured"  width="10%" ><?php echo $strphase ; ?></td>
			<td class="tdfeatured" width="15%" ><?php echo $mediationstartdate ; ?></td>
			<td class="tdfeatured" width="15%" ><?php echo $mediationclosedate ; ?></td>
			<td class="tdfeatured" width="25%" >
				<table cellpadding="0" cellspacing="0" border="0" width="100%">
					<tr>
				<form name="mediationform" method="post">
				<input type="hidden" name="hdndeletemediationid" id="hdndeletemediationid" value="<?php echo $mediationid ; ?>" >
				<input  type="button" class="btn1" value=" View Mediation " onClick="javascript: viewmediation(<?php echo $mediationid ; ?>)">
			    <input  type="button" class="btn1" value=" Reply to Mediator " onClick="javascript: sendmessage(<?php echo $mediationid ; ?>,'Mediator')">
			 	<input  type="button" class="btn1" value=" Reply to Opponent " onClick="javascript: sendmessage(<?php echo $mediationid ; ?>,'Opponent')">
				 <input name="deletemediation"  type="submit" class="btn1" onClick="javascript: deleteconfirmation(<?php echo $mediationid ; ?>)" value=" Delete Mediation">			
				</form>
				</tr>
			</table>
		</td>		
			</tr>
			<?php
				}
			}
			else
			{
			?>
			<tr background="images/bg_part.gif">
			<td class="formtext" colspan="11" align="center">There is no Mediation Between any User.</td>
			</tr>
			<?php
			}
			?>
			</table>
		 </td>
      </tr>
	
    </table></td>
  </tr>
  
</table>
</body>
</html>
