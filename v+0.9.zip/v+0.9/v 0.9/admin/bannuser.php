<?php
include("../include/config.php");
$iid = $_GET['id'] ;
$status =  $_GET['setstatus'] ;
$query = mysql_query("SELECT * FROM tblcommission WHERE iid = '$iid'");		
$bought = mysql_fetch_array($query) ;
$sellerid =  $bought['isellerid'];
$query2 = mysql_query("UPDATE tblmember SET istatus = '$status' WHERE iid = '$sellerid'");
echo "UPDATE tblmember SET istatus = '$status' WHERE iid = '$sellerid'" ;
exit();
?>
<script language="javascript">
	window.location.href = "index.php?pg=Commission" ;
</script>	

