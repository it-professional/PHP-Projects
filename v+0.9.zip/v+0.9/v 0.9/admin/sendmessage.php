<title>Send Message</title>
<link href="../include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="wysiwyg.js"></script>



<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?php 
include("../include/config.php");
if(isset($_POST['submit']))
{
	$mediationid = $_POST['hdnmediationid'] ;
	$sendmessagto = $_POST['hdnsendmessgeto'] ;
	$prodid = $_POST['hdnproductid'] ;
	$msg= $_POST['postmessage'] ;
	$send = $_POST['hdnsend'] ;
	$todaydate = date("Y-m-d");
	
	$query15 = "INSERT INTO tblmediationmessages(ipid,imediationid,bactive,strmessage,ifromuid,itouid,ddate) VALUES('$prodid','$mediationid','1','$msg','0','$sendmessagto','$todaydate')";
		
		$query5 = mysql_query($query15);
			
	?>
		<script language="javascript">
			window.location.href = 'sendmessage.php?mediationid=<?php echo $mediationid ;?>&sendmessageto=<?php echo $send ;?>' ;
		</script>
<?php
}
?>

<?php
$mediationid = $_GET['mediationid'];
$sendmessage = $_GET['sendmessageto'];


$mediationquery = mysql_query("SELECT * FROM tblmediation where iid ='$mediationid'");
$mediationdata = mysql_fetch_array($mediationquery);
$mediatorid =  $mediationdata['imediatorid'] ;
$productid = $mediationdata['ipid'] ;
$opponentid  = $mediationdata['itoid'] ;

?>
<tr>
<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
	<font face="verdana" size="+1" color="#000000"><b><?php echo $productname ;?>&nbsp; Mediation Messages</b></font>
</td>
</tr>
<?php
//$query2 = mysql_query("select * from tblmediationmessages where ipid = '$productid' AND ((ifromuid = '0' AND itouid = '$messageto') OR (ifromuid = '$messageto' and itouid = '0')) ORDER BY ddate ASC");

if($sendmessage == "Mediator")
{
$sendmessageto = $mediatorid ;
$sqlquery2 = "select * from tblmediationmessages where ipid = '$productid' AND ifromuid = '0' AND itouid = '$mediatorid' ORDER BY ddate ASC";
}
else
{
$sendmessageto = $opponentid ;
$sqlquery2 = "select * from tblmediationmessages where ipid = '$productid' AND ifromuid = '0' AND itouid = '$opponentid' ORDER BY ddate ASC";
}
//echo $sqlquery2 ;
$query2 = mysql_query($sqlquery2) ; 
$rows = mysql_num_rows($query2);
if($rows > 0)
{
	while($data2 = mysql_fetch_array($query2))
	{
		$fromuser = $data2['ifromuid'] ;
		//Getting Users info
			if($fromuser > 0)
			{
				$query11 = mysql_query("select * from tblmember where iid = '$fromuser'");
				$rows2 = mysql_num_rows($query11);
				if($rows2 > 0)
				{
					$data = mysql_fetch_array($query11);
					$firstname = $data['strfirstname'] ;
					$lastname = $data['strlastname'] ;
					$nick = $data['strnickname'] ;	
					$country = $data['strcountry'] ;
					$city = $data['strcity'] ;
						
				}
			}
			else
			{
					$firstname = "" ;
					$lastname = "" ;
					$nick = "Admiin" ;	
					$country = "" ;
					$city = "" ;
			}	
			//Getting Messages Information
			$message = $data2['strmessage'] ;
			$posteddate = $data2['ddate'] ;

?>

			<?php if($firstname != "") { ?>
			<tr>
				<td class="SubHeading">
					<span class="Heading">By</span> <?php echo $firstname ;?>&nbsp;<?php echo $lastname ;?>
				</td>
			</tr>
			<?php } ?>
			<tr>
				<td class="SubHeading">
					<span class="Heading">From</span> <?php echo $nick ;?>
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<span class="Heading">Posted On</span> <?php echo $posteddate ;?>
				</td>
			</tr>
			<tr>
				<td class="Heading">
					Message:-
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<?php echo $message ;?>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><hr width="50%" /></td></tr>
		<?php		
	
//	}
	}
	}
	
	?>
	
<tr>
		<td class="Heading">
			Post New Message
		</td>
	</tr>
	
	<form name="sendmessage" action="sendmessage.php"  method="post">
	<tr>
		<td>
			
			  <textarea id="postmessage" name="postmessage" ></textarea>
				<script language="javascript">
					generate_wysiwyg('postmessage');
				</script>
		</td>
	</tr>
	<tr>
		<td>
			<input type="hidden" name="hdnmediationid" value="<?php echo $mediationid ;?>" />
			<input type="hidden" name="hdnsendmessgeto" value="<?php echo $sendmessageto ;?>" />
			<input type="hidden" name="hdnproductid" value="<?php echo $productid ;?>" />
			<input type="hidden" name="hdnsend" value="<?php echo $sendmessage ; ?>" />
			<input type="submit" name="submit" value=" Submit " />
		</td>
	</tr>
	</form>

</table>	