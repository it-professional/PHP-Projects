<?
include("../include/config.php");
$iid = $_GET['id'] ;
$query = mysql_query("Delete FROM tblboughtproducts where iid = '$iid'");
?>
