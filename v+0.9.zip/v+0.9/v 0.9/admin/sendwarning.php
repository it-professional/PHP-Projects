<title>Send Warning</title>
<link href="../include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="wysiwyg.js"></script>



<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?php 
include("../include/config.php");
if(isset($_POST['submit']))
{
	$strsubject =  $_POST['subject'] ;
	$sendwarningtoid = $_POST['hdnuserid'] ;
	$strmessage = $_POST['postmessage'] ;
	$todaydate = date("Y-m-d");
	if($strsubject == "" )
	{
		$strsubject = "Warning Message" ;
	}	
	
	$sqlquery = "INSERT INTO tblwarningmessages(strsubject,ifromid,itoid,strmessage,ddate) VALUES('$strsubject','0','$sendwarningtoid','$strmessage','$todaydate')";
		
		$insertinquery = mysql_query($sqlquery);
		if($insertinquery)
		{
			$query7 = mysql_query("select stremail from tblmember where iid = '$sendwarningtoid'");
			$data7 = mysql_fetch_array($query7);
			$stremailid = $data7['stremail'] ;	
			
			
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: voskysinteractive.com";
		
			$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
			$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
			$strHTML .= "<br>".$strmessage."<br><br>";
			$strHTML .= "</td></tr></table>";
			
			$strHTML = stripslashes($strHTML);	
		
			mail($stremailid,$strsubject,$strHTML,$headers);
		}
		
			
	?>
		<script language="javascript">
			window.location.href = 'sendwarning.php?cid=<?php echo $sendwarningtoid ;?>' ;
		</script>
<?php
}
?>
<?php
$getuserid = $_GET['cid'] ;

$query = mysql_query("SELECT * FROM tblwarningmessages WHERE itoid = '$getuserid'");	
$getrows = mysql_num_rows($query);	
if($getrows > 0)
{
	while($wardingdata = mysql_fetch_array($query))
	{
		
		$strsubject = $wardingdata['strsubject'] ;
		$strwarningmessage = $wardingdata['strmessage'] ;
		$posteddate = $wardingdata['ddate'] ;
		
		$userquery = mysql_query("select * from tblmember where iid = '$getuserid'");
		$userdata = mysql_fetch_array($userquery);
		$strsellerfirstname = $userdata['strfirstname'] ;	
		$strsellerlasttname = $userdata['strlastname'] ;


?>
<tr>
<td class="SubHeading">
	<span class="Heading">To :</span> <?php echo $strsellerfirstname . $strsellerlasttname ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Posted On : </span> <?php echo $posteddate ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Subject : </span> <?php echo $strsubject ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Message:</span> 
</td>
</tr>
<tr>
<td class="SubHeading">
<?php echo $strwarningmessage ; ?> 
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?php }
	}
?>

<tr>
		<td class="Heading" style="padding-bottom:10px;">
			Post New Message
		</td>
	</tr>
	
	
	<form name="sendmessage" action="sendwarning.php"  method="post">
	<tr>
		<td class="SubHeading">
			<span style="padding-right:10px; ">Subject:</span>  <input type="text" name="subject" size="35" />
		</td>
	</tr>
	<tr>
		<td style="padding-top:9px;">
			
			  <textarea id="postmessage" name="postmessage" ></textarea>
				<script language="javascript">
					generate_wysiwyg('postmessage');
				</script>
		</td>
	</tr>
	<tr>
		<td>
			<input type="hidden" name="hdnuserid" value="<?php echo $getuserid ; ?>" />
			<input type="submit" name="submit" value=" Submit " />
		</td>
	</tr>
	</form>

</table>	