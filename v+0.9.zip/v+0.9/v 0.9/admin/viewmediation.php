<title>View Mediations</title>
<link href="../include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="../include/editor/wysiwyg.js"></script>

<table border="0" cellpadding="0" cellspacing="0" width="100%">

<?php
include("../include/config.php");
$mediationid = $_GET['mediationid'];


$query1 = mysql_query("SELECT * FROM tblmediation WHERE iid = '$mediationid'");
$data1 = mysql_fetch_array($query1);
$productid = $data1['ipid'] ; 
$mediatorid = $data1['imediatorid'] ;

// Get the Product name
$query2 = mysql_query("SELECT strproductname FROM tblproducts WHERE iid  = '$productid'");
$data2 = mysql_fetch_array($query2);
$productname = $data2['strproductname'] ;




?>
<tr>
		<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
			<font face="verdana" size="+1" color="#000000"><b><?php echo $productname ;?>&nbsp; Mediation Messages</b></font>
		</td>
</tr>
<?php
$query3 = mysql_query("SELECT * FROM tblmediationmessages WHERE imediationid = '$mediationid'");
$rows = mysql_num_rows($query3);
if($rows > 0)
{
	while($data3 = mysql_fetch_array($query3))
	{
		$fromuser = $data3['ifromuid'] ;
		//Getting Users info
		$query4 = mysql_query("select * from tblmember where iid = '$fromuser'");
		$rows2 = mysql_num_rows($query4);
		if($rows2 > 0)
		{
			$data4 = mysql_fetch_array($query4);
			$firstname = $data4['strfirstname'] ;
			$lastname = $data4['strlastname'] ;
			$nick = $data4['strnickname'] ;	
			$country = $data4['strcountry'] ;
			$city = $data4['strcity'] ;
				
	//	}
		//Getting Messages Information
		$message = $data3['strmessage'] ;
		$posteddate = $data3['ddate'] ;
		//Displaying messages in date descending order
		?>

			
			<tr>
				<td class="SubHeading">
					<span class="Heading">From</span> <?php echo $nick ;?>
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<span class="Heading">Posted On</span> <?php echo $posteddate ;?>
				</td>
			</tr>
			<tr>
				<td class="Heading">
					Message:-
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<?php echo $message ;?>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><hr width="50%" /></td></tr>
		<?php		
	}
	}
	}
	
?>

</table>	