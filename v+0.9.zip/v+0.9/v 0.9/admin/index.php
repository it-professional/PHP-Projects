<?php
ob_start();
session_start();

if($_SESSION["login"]==1)
{
}
else
{
header("Location: login.php"); 
}
?>
<HTML>
<HEAD>
<TITLE>PickmeFriend</TITLE>
<STYLE TYPE="text/css">@import url(calendar-green.css);</STYLE>

<STYLE TYPE="text/css">
<!--
.style2 {
	color: #000000;
	font-size: 16px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style61 {color: #FFFFFF}
.style14 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
}
.style15 {
	font-size: 12px;
	color: #FFFF66;
}
.style22 {color: #C60000}
-->
</STYLE>
<LINK HREF="css/style.css" REL="stylesheet" TYPE="text/css">
</HEAD>

<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LEFTMARGIN="0" TOPMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0">
<TABLE WIDTH="100%" HEIGHT="100%" BORDER="1" CELLPADDING="0" CELLSPACING="0">
  <TR HEIGHT="0">
  <TD HEIGHT="0" COLSPAN="2"><?php include("includes/header.php");?></TD>
  </TR>
  <TR> 
    <TD WIDTH="21%" HEIGHT="500" VALIGN="top" BGCOLOR="#f1f3f5"><?php include("includes/menu.php");?></TD>
    <TD WIDTH="79%" HEIGHT="100%" VALIGN="top" CLASS="tbl"> 
      <DIV ALIGN="center">
     		    
<?php

		if($_GET["pg"]	== "Latestnews")			include("includes/LatestNews.php");//total peaple
		else if($_GET["pg"]	== "TOS")				include("includes/TermsOfServices.php");//admin
		else if($_GET["pg"]	== "Aboutus")				include("includes/AboutUs.php");//admin
		else if($_GET["pg"]	== "legal")				include("includes/Legal.php");//admin
		else if($_GET["pg"]	== "Latestwork")				include("includes/LatestWork.php");//admin
		else if($_GET["pg"]	== "homepage")				include("includes/homepg.php");//admin
		else if($_GET["pg"]	== "menu1")				include("includes/Menu1pg.php");//admin
		else if($_GET["pg"]	== "menu2")				include("includes/Menu2pg.php");//admin
		else if($_GET["pg"]	== "menu3")				include("includes/Menu3pg.php");//admin
		else if($_GET["pg"]	== "productchar")				include("includes/productcharacteristics.php");//admin
		else if($_GET["pg"]	== "productcharattributes")				include("includes/productattributes.php");//admin
		else if($_GET["pg"]	== "ReleaseMoneyUsers")				include("includes/releasemoneyuser.php");//admin
		else if($_GET["pg"]	== "Mediation")				include("includes/mediation.php");//admin
		else if($_GET["pg"]	== "ContactUs")				include("includes/contactususer.php");//admin
		else if($_GET["pg"]	== "Commission")				include("includes/commissionusers.php");
		else if($_GET["pg"]	== "RegisteredUsers")				include("includes/ManageUsers.php");
		else if($_GET["pg"]	== "ReportAbuses")				include("includes/ViewReportAbuses.php");
		
		
				
				
		else if($_GET["pg"]	== "admin")				include("includes/admin.php");//admin
		else if($_GET["pg"]	== "changpass")			include("includes/cpass.php");//change pass

		else
		{
		?>
		<SPAN CLASS="fonte"><BR><BR><BR>
		</SPAN><SPAN CLASS="style2"><IMG SRC="images/cpanel.png" WIDTH="48" HEIGHT="48" ALIGN="absmiddle"> Administration Home</SPAN><BR>
        <?php
		}
		?>
    </DIV>  
	
	  </TD>
  </TR>
</TABLE>

</BODY>
</HTML>
