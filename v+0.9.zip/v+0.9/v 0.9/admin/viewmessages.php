<title>View Messages</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>

<table border="0" cellpadding="0" cellspacing="0" width="100%">

<?php
include("../include/config.php");
$productid = $_GET['PID'];
$markeduserid = $_GET['bid'];


$query5 = mysql_query("select strproductname,iuid from tblproducts where iid = '$productid'");
$data5  = mysql_fetch_array($query5);
$name = $data5['strproductname'] ;
$productowner = $data5['iuid'];


?>
<tr>
		<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
			<font face="verdana" size="+1" color="#000000"><b><?php echo $name ;?>&nbsp; Messages</b></font>
		</td>
</tr>
<?php
$query2 = mysql_query("select * from tblmessages where ipid = '$productid' AND ((ifromuid = '$productowner' AND itouid = '$markeduserid') OR (ifromuid = '$markeduserid' and itouid = '$productowner')) ORDER BY ddate ASC");
$rows = mysql_num_rows($query2);
if($rows > 0)
{
	while($data2 = mysql_fetch_array($query2))
	{
		$fromuser = $data2['ifromuid'] ;
		//Getting Users info
		$query1 = mysql_query("select * from tblmember where iid = '$fromuser'");
		$rows2 = mysql_num_rows($query1);
		if($rows2 > 0)
		{
			$data = mysql_fetch_array($query1);
			$firstname = $data['strfirstname'] ;
			$lastname = $data['strlastname'] ;
			$nick = $data['strnickname'] ;	
			$country = $data['strcountry'] ;
			$city = $data['strcity'] ;
				
	//	}
		//Getting Messages Information
		$message = $data2['strmessage'] ;
		$posteddate = $data2['ddate'] ;
		//Displaying messages in date descending order
		?>

			<tr>
				<td class="SubHeading">
					<span class="Heading">By</span> <?php echo $firstname ;?>&nbsp;<?php echo $lastname ;?>
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<span class="Heading">From</span> <?php echo $nick ;?>
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<span class="Heading">Posted On</span> <?php echo $posteddate ;?>
				</td>
			</tr>
			<tr>
				<td class="Heading">
					Message:-
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<?php echo $message ;?>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><hr width="50%" /></td></tr>
		<?php		
	}
	}
	}
	else
	{
	?>
	<tr>
		<td class="SubHeading" width="100%">
			There is no Message now yet.
		</td>
	</tr>
	<?php
}	


//echo("select * from tblmessages where ipid = '$productid' AND iuid IN($arrMarkedUsers) ORDER BY ddate ASC");
//end;

?>

</table>	