<title>Send Notice</title>
<link href="../include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="wysiwyg.js"></script>



<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?php 
include("../include/config.php");
if(isset($_POST['submit']))
{
	$commissionid = $_POST['hdncommissionid'] ;
	$strmessage = $_POST['postmessage'] ;
	$todaydate = date("Y-m-d");
	
	$sqlquery = "INSERT INTO tblcommissionmessages(icommissionid,strmessage,ddate) VALUES('$commissionid','$strmessage','$todaydate')";
		
		$insertinquery = mysql_query($sqlquery);
		if($insertinquery)
		{
			$getemailidqu = mysql_query("SELECT * FROM tblcommission WHERE iid = '$commissionid'");
			$getdata = mysql_fetch_array($getemailidqu) ;		
			$sellerid =  $getdata['isellerid'];
			
			$query7 = mysql_query("select stremail from tblmember where iid = '$sellerid'");
			$data7 = mysql_fetch_array($query7);
			$stremailid = $data7['stremail'] ;	
			
			
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: voskysinteractive.com";
		
			$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
			$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
			$strHTML .= "<b>Commission Message : </b>";
			$strHTML .= "<br>".$strmessage."<br><br>";
			$strHTML .= "</td></tr></table>";
			
			$strHTML = stripslashes($strHTML);	
		
			mail($stremailid,"Commission Notice",$strHTML,$headers);
		}
		
			
	?>
		<script language="javascript">
			window.location.href = 'sendnotice.php?cid=<?php echo $commissionid ;?>' ;
		</script>
<?php
}
?>
<?php
$getcommissionid = $_GET['cid'] ;

$query = mysql_query("SELECT * FROM tblcommissionmessages WHERE icommissionid = '$getcommissionid'");	
$getrows = mysql_num_rows($query);	
if($getrows > 0)
{
	while($bought = mysql_fetch_array($query))
	{
		$id = $bought['iid'];
		$commissionid =  $bought['icommissionid'];
		$message =  $bought['strmessage'];
		$posteddate =  $bought['ddate'];
		
		$query4 = mysql_query("SELECT * FROM tblcommission WHERE iid = '$commissionid'");
		$bought = mysql_fetch_array($query4) ;		
		$id = $bought['iid'];
		$prodid =  $bought['ipid'];
		$sellerid =  $bought['isellerid'];
		
						
		$query2 = mysql_query("select * from tblproducts where iid = '$prodid'");
		$rows2 = mysql_num_rows($query2);
		$data2 = mysql_fetch_array($query2);
		$strproductname = $data2['strproductname'] ;
		
		$query3 = mysql_query("select * from tblmember where iid = '$sellerid'");
		$data3 = mysql_fetch_array($query3);
		$strsellerfirstname = $data3['strfirstname'] ;	
		$strsellerlasttname = $data3['strlastname'] ;


?>
<tr>
<td class="SubHeading">
	<span class="Heading">From :</span> Admin
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">To :</span> <?php echo $strsellerfirstname . $strsellerlasttname ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Posted On : </span> <?php echo $posteddate ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Message</span> 
</td>
</tr>
<tr>
<td class="SubHeading">
<?php echo $message ; ?> 
</td>
</tr>
<?php }
	}
?>
<tr>
		<td class="Heading">
			Post New Message
		</td>
	</tr>
	
	<form name="sendmessage" action="sendnotice.php"  method="post">
	<tr>
		<td>
			
			  <textarea id="postmessage" name="postmessage" ></textarea>
				<script language="javascript">
					generate_wysiwyg('postmessage');
				</script>
		</td>
	</tr>
	<tr>
		<td>
			<input type="hidden" name="hdncommissionid" value="<?php echo $getcommissionid ; ?>" />
			<input type="submit" name="submit" value=" Submit " />
		</td>
	</tr>
	</form>

</table>	