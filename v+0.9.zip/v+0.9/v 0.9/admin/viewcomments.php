<title>View Comments</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>

<table border="0" cellpadding="0" cellspacing="0" width="100%">

<?php
include("../include/config.php");
$contactusid = $_GET['cid'];


$query5 = mysql_query("select * from tblcontactus where iid = '$contactusid'");
$data5  = mysql_fetch_array($query5);
$name = $data5['strname'] ;
$email = $data5['stremail'];
$phone = $data5['strphoneno'];
$comments = $data5['strcomments']; 
$date = $data5['ddate'];


?>
<tr>
		<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
			<font face="verdana" size="+1" color="#000000"><b><?php echo $name ;?>&nbsp; Comments</b></font>
		</td>
</tr>
			<tr>
				<td class="SubHeading">
					<span class="Heading"><b>Email Address:</b></span> <?php echo $email ;?>
				</td>
			</tr>
<?php if($phone != "") { ?>
			<tr>
				<td class="SubHeading">
					<span class="Heading"><b>Phone No:</b></span> <?php echo $phone ;?>
				</td>
			</tr>
<?php }?>			
			
			<tr>
				<td class="SubHeading">
					<span class="Heading"><b>Posted On:</b></span> <?php echo $date ;?>
				</td>
			</tr>
			
			<tr>
				<td class="Heading">
					<b>Comments:-</b>
				</td>
			</tr>
			<tr>
				<td class="SubHeading">
					<?php echo $comments ;?>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><hr width="50%" /></td></tr>
		

</table>	