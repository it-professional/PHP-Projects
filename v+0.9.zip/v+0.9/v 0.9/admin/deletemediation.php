<?
include("../include/config.php");
$iid = $_GET['id'] ;
$query = mysql_query("Delete FROM tblmediationmessages where imediationid  = '$iid'");
$query2 = mysql_query("DELETE FROM tblmediation WHERE iid = '$iid'");
?>
<script language="javascript">
window.opener.location.href = window.opener.location.href ;
</script>