<?php
include("../include/config.php");
$iid = $_GET['id'] ;
$query = mysql_query("Delete FROM tblcontactus where iid = '$iid'");
?>
<script language="javascript">
window.opener.location.href = window.opener.location.href ;
</script>