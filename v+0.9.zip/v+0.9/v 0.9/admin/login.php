<?php
ob_start();
session_start();
include("includes/openconn.php");

if(isset($_GET["logout"]))
{
if($_GET["logout"]=="logout")
{
$_SESSION["login"]=0;
}
}

$wrong=0;

if(isset($_POST["Submit"]))
{
	$qry = "select * from admin where Name='$_POST[username]' and Password='$_POST[password]'";
	$ress=mysql_query( $qry );
	$objj=mysql_fetch_object($ress);
	$numrec = mysql_num_rows($ress);
	
	if($numrec>0)
	{
		$_SESSION["login"]=1;
		$_SESSION["username"]=$objj->Name;
		$_SESSION["username1"]=$objj->Name;
		
		$_SESSION["security_level"]="Admin";
		header("Location: index.php?pg=wc");
		$wrong=0;
	}
	else
	{
		$wrong=1;
	}

}

?>
<link rel="stylesheet" href="../css/ecyclezone.css" type="text/css">

<link rel="stylesheet" href="css/style" type="text/css">
<title>PickmeFriend</title><style type="text/css">
<!--
body {
	background-image: url(../back.jpg);
}
.style4 {
	color: #006633;
	font-weight: bold;
}
.style5 {color: #006633}
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; color: #ff9900;}
.style7 {color: #000000}
-->
</style>
<link href="css/style.css" rel="stylesheet" type="text/css">
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<form name="form1" method="post" action="#" enctype="multipart/form-data">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td><table width="442" align="center" cellpadding="10" cellspacing="0" bgcolor="#f1f3f5" class="tbl">
        <tr>
          <td width="288"><div align="center"><br>
            <img src="images/security.png" width="64" height="64"><br>
              <br>
                  <p class="heads">Welcome to PickmeFriend </p>
                      <p align="left" class="textbox1">&nbsp;Use a valid username and &nbsp;password to gain access to &nbsp;the administration   console.</p>
                <br>
            <br>
          </div></td>
          <td width="269"><table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="tbl">
            <tr >
              <td height="30" colspan="2" class="GreenButton"><div align="center" class="style6"><img src="images/LOGIN.GIF" width="74" height="33"></div></td>
            </tr>
            <tr>
              <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="2"><div align="center"><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#FF0000">
                  <?php
		if($wrong==1)print("Invalid Username/Password");
		?>
              </font></b></font></div></td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274"><div align="right" class="fonte style5">
                <div align="left" class="heads"><strong>Username</strong> :</div>
              </div>
              <input name="username" type="text" class="textbox1" size="32">              </td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274"><div align="right" class="fonte style4">
                <div align="left" class="heads">Password :</div>
              </div>
                <input name="password" type="password" class="textbox1" size="32">              </td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274"><input name="Submit" type="submit" class="btn1" value="LOGIN"></td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274">&nbsp;</td>
            </tr>
          </table></td>
        </tr>
        
      </table></td>
    </tr>
  </table>
</form>
