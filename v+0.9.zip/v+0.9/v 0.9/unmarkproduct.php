<?php
session_start() ;
include("checksession.php");
include("include/config.php");
$markedid = $_GET['iid'] ;

$strQry = mysql_query("DELETE FROM tblmarkedproducts WHERE iid = '$markedid'") ;	

	//echo ("1") ;
	//include('MarkedProducts.php');
?>
<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td colspan="11"><?php include('MarkedProducts.php'); ?></td></tr></table>

