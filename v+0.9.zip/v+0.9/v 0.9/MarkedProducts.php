<?php session_start(); 
include("checksession.php");
 $_SESSION["Backlink1"] = "MarkedProducts.php"  ;
?>
<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<table width="100%" cellpadding="0" cellspacing="0" >
	<tr>
		<td colspan="2" class="Heading" align="left">
			<h4 class="Heading">Marked Products</h4>
		</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td height="10" bgcolor="#999999" align="right" colspan="5">&nbsp;
					
					</td>
				</tr>
				<tr bgcolor="#CCCCCC">
				<td class="SubHeading"  align="left" width="15%"><b>Action</b></td>
					<td class="SubHeading" width="15%"><b>Name</b></td>
					<td class="SubHeading" width="55%"><b>Description</b></td>
					<td class="SubHeading" align="center" width="15%"><b>Date</b></td>						
					
				</tr>
	
		<?php
		include("include/config.php");
	
	//	$temp = 0;
		
		$markedquery2 = mysql_query("SELECT  * FROM tblmarkedproducts WHERE iuid = ".$_SESSION['loginid']." and bactive = 1");		
		$markedrows = mysql_num_rows($markedquery2);
		if($markedrows > 0)
		{
			while($markdata = mysql_fetch_array($markedquery2))
			{
				//$markeduserid = $markdata['iid'];
				$markedid = $markdata['iid'];
				$markipid =  $markdata['ipid'];
				$markeduserid =  $markdata['iuid'];
				//$query = mysql_query("select * from tblproducts where iuid = ".$_SESSION['loginid']." order by iid asc ");
				
					$query = mysql_query("select * from tblproducts where iid = '$markipid'  order by iid asc ");
					
					$rows = mysql_num_rows($query);
					if($rows >0)
					{
						
						$data = mysql_fetch_array($query)
						
						?>
						
						<?php	
							$iid = $data['iid'] ;
							$strproductname = $data['strproductname'] ;
							$productdescriptions = $data['strotherdesc'];
							$date = $data['dtdate'];
							$productownerid = $data['iuid'];
							
							$chkbanneduserquery = mysql_query("SELECT istatus FROM tblmember WHERE iid = '$productownerid'") ;
							$fetchbannedquerydata = mysql_fetch_array($chkbanneduserquery);
							$bannstatus = $fetchbannedquerydata['istatus'] ;
							if($bannstatus != 0)
							{
							
							
								if(strlen($productdescriptions)>=100)
								{
									if(!function_exists('str_split')) 
									{ 
										$productdescription = str_split1($productdescriptions,100);
									}
									else
									{
										$productdescription = str_split($productdescriptions,100);
									}	
								}	
						
			
					
		?>
		<tr>
		<td align="left" width="15%" valign="top" >
				<table >
															<tr>
															
				
																
																
	<td><a class="bluelink" onClick="viewbuyermessages(<?php echo $markipid ;?>,<?php echo $markeduserid ;?>)"><img src="images/message.jpg" border="0" title="click to View Messages"></a>
																<a class="bluelink" onClick="viewproduct(<?php echo $iid ; ?>);"><img src="images/view.jpg" border="0" title="click to View"></a>
					<a class="bluelink" onClick="javascript: viewbuyproduct(<?php echo $markipid ;?>,<?php echo $markeduserid ;?>,'MarkedProducts')"><img src="images/buy.jpg" border="0" title="click to Buy Product"></a>
					<a class="bluelink" onClick="javascript: UnMarkproduct(<?php echo $markedid ;?>)"><img src="images/buy.gif" border="0" width="24" height="24" title="click to Un Mark the Product"></a>
							</td></tr></table></td>
							
			<td class="SubHeading" width="15%" valign="top">
				<?php echo $strproductname ; ?>
			</td>
			<td class="SubHeading" align="left" width="55%" valign="top">
				<?php 
				if(strlen($productdescriptions)>=100)
				{
					 echo $productdescription[0]."&nbsp;...... " ;
				}
				else
				{	
					 echo $productdescriptions ;
				}				
				?>
			</td>
			
			
			<td class="SubHeading" align="center" width="15%" valign="top">
				<?php echo $date ; ?>
			</td>
			
		</tr>		
		<?php
			}
			}
			}
			?>
			
			<?php
			}
			else
			{
		?>
			<tr>
				<td colspan="11" class="SubHeading">
					There is no product marked now yet
				</td>
			</tr>
		<?php } ?>
		<tr bgcolor="#CCCCCC" height="5pt;">
						<td colspan="5" align="right" class="SubHeading">
							<?php echo($pagination); ?>																	
						</td>
					</tr>
		</table>
		</td>
	</tr>		
			
	
</table>
