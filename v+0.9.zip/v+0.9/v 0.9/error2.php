<?php
session_start();

if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
{
include("login.php");
}
else
{	
	
include("include/template.php");
templateheader("" , "true");
}
?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="redlink"  align="center">
			There is some error to Complete Your Transaction. Please try again.
		</td>
	</tr>
</table>



<?php
templatefooter("" , "true");
?>