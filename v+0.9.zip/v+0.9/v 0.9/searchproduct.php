<?php
session_start();
include("checksession.php");
include("include/config.php");
function str_split1($string,$string_length=1) {
        if(strlen($string)>$string_length || !$string_length) {
            do {
                $c = strlen($string);
                $parts[] = substr($string,0,$string_length);
                $string = substr($string,$string_length);
            } while($string !== false);
        } else {
            $parts = array($string);
        }
        return $parts;
    }
?>
<div id="divsupermain" style="height :200px ;width:100%; overflow-x:hidden; overflow-y:scroll" onscroll="showscroll(this.scrollTop)">
<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr bgcolor="#CCCCCC">
<td class="SubHeading" width="20%" >&nbsp;</td>
	<td class="SubHeading" width="20%" ><b>Product Name</b></td>
	<td class="SubHeading" width="60%"><b>Product Description</b></td>
	
	
</tr>
<?php

$productname = $_GET['productname'] ;
$other = $_GET['other'] ;
$characteristics = $_GET['characteristics'] ;
$attributes = $_GET['attributes'] ;
$characterlength = $_GET['characteristiclength'] ;
$characterlength = $_GET['characteristiclength'] ;
$strSearchBy = $_GET['searchby'] ;
$character = explode("," , $characteristics) ;
$attribute = explode("," , $attributes) ;
$wheredata = "" ;

	
	 if($strSearchBy == "name"){
	 	$wheredata = " WHERE strproductname like '%$productname%'" ;
		$strQry = "SELECT * FROM tblproducts $wheredata ORDER BY strproductname ASC" ;	
	 }	 
	 else{
	 	//$wheredata = " WHERE strproductname like '%$productname%'" ;
		
		while($characterlength >= 0)
		{
			$characteristicid = $character[$characterlength] ;
			$attributeid =  $attribute[$characterlength] ;
			if($attributeid != ""){
				if ($wheredata != "")
				{
					$wheredata .= " OR ";
				}
				$wheredata .= "	(icharid = $characteristicid AND iatrid = $attributeid)" ;
			}
			$characterlength-- ;
		}
		if($wheredata != "")
		{
			$strQry = "SELECT * FROM tblproducts WHERE iid in (SELECT ipid FROM tblproductfeatures WHERE $wheredata) ORDER BY strproductname ASC" ;	
		}
		else
		{
			$strQry = "SELECT * FROM tblproducts ORDER BY strproductname ASC" ;	
		}
		
	 }
	//echo $strQry ; 
	
	$query2 = mysql_query($strQry);
	$row = mysql_num_rows($query2);
	if($row > 0)
	{
		while($data = mysql_fetch_array($query2))
		{
			$iid = $data['iid'] ;
			$productname = $data['strproductname'] ;
			$productdescriptions = $data['strotherdesc'] ;
			$iuid = $data['iuid'] ;
										
			$chkbanneduserquery = mysql_query("SELECT istatus FROM tblmember WHERE iid = '$iuid'") ;
			$fetchbannedquerydata = mysql_fetch_array($chkbanneduserquery);
			$bannstatus = $fetchbannedquerydata['istatus'] ;
			if($bannstatus != 0)
			{	
			
			if(strlen($productdescriptions)>=100)
			{
				if(!function_exists('str_split')) 
				{ 
					$productdescription = str_split1($productdescriptions,100);
				}
				else
				{
					$productdescription = str_split($productdescriptions,100);
				}	
			}	
		?>
			<tr>
			<td align="left">
					<a  onClick="viewproduct(<?php echo $iid ; ?>);"><img style="cursor:pointer;" src="images/view.jpg" border="0" title="click to View"></a>
				
				<a onClick="Markproduct(<?php echo $iid ; ?> , <?php echo $iuid ;?>);"><img style="cursor:pointer;" src="images/buy.gif" border="0" width="24" height="24" title="Click to Mark the Product" /></a></td>
				<td class="Heading"  >
					<?php echo $productname ;?>
				</td>
				<td class="Subheading" align="left" >
				<?php
				if(strlen($productdescriptions)>=100)
				{
					 echo $productdescription[0]."&nbsp;...... " ;
				}
				else
				{	
					 echo $productdescriptions ;
				}
				?>	
				</td>
				
			</tr>
		<?php	
			}			
		}
	}
	else
	{
	?>
		<tr>
			<td class="SubHeading">
				No Record Found.
			</td>
		</tr>
	<?php
	}
	
	
?>
</table></div>