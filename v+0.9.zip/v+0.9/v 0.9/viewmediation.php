<?php
 session_start() ;
 include("checksession.php");
 ?>
 
 <title>View Mediation Messages</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>
<?php 
//echo($_SESSION['loginid']);

include("include/config.php");
if(isset($_POST['submit']))
{
	$mediationid = $_POST['hdnmediationid'] ;
	$mediatorid = $_POST['hdnmediatorid'] ;
	$mediationtoid = $_POST['hdnmediationtoid'] ;
	$pid = $_POST['hdnproductid'] ;
	$msg= $_POST['postmessage'] ;
	$todaydate = date("y-m-d");
	
	$sqlquery = "INSERT INTO tblmediationmessages(imediationid,ipid,bactive,strmessage,ifromuid,itouid,ddate) values('$mediationid','$pid' ,1,'$msg','$mediatorid','$mediationtoid', '$todaydate')";

	$query4 = mysql_query($sqlquery);
	if($query4)
	{
		$headers = "MIME-Version: 1.0\r\n";  
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: PickmeFriend.com";
		
		$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
		$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
		$strHTML .= "<b>Message: </b>".$sentmessage."<br><br>";
		$strHTML .= "</td></tr></table>";
			
		$strHTML = stripslashes($strHTML);	
		
		$subject = "A New Message Posted From ".$strnick ;
	
	?>
		<script language="javascript">
			window.location.href = 'main.php?pg=viewmediation.php&mediationid=<?php echo $mediationid ;?>&mediatoragainstid=<?php echo $mediationtoid ;?>' ;
		</script>
	<?php
	}
}
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?php if($_SESSION["Backlink1"] != "") {?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_SESSION["Backlink1"] ;?>');" colspan="5" >Go Back
</td>
</tr>
<?php }?>
<?php
//$productid = $_GET['ival1'];
//$fromid = $_GET['ival2'];
//$toid = $_GET['ival3'] ;
$mediationid = $_GET['mediationid'];
$mediatoagainstuserid = $_GET['mediatoragainstid']; 
$mediationfromuserid = $_SESSION['loginid'] ;
//$fromid = $_SESSION['loginid'] ;

$mediationquery = mysql_query("SELECT * FROM tblmediation where iid ='$mediationid'");
$mediationdata = mysql_fetch_array($mediationquery);
$fromid =  $mediationdata['imediatorid'] ;
$productid = $mediationdata['ipid'] ;
$toid  = $mediationdata['itoid'] ;

$query5 = mysql_query("select strproductname,iuid from tblproducts where iid = '$productid'");
$data5  = mysql_fetch_array($query5);
$name = $data5['strproductname'] ;
$productowner = $data5['iuid'];


?>
<tr>
		<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
			<font face="verdana" size="+1" color="#000000"><b><?php echo $name ;?>&nbsp; Messages</b></font>
		</td>
</tr>
<?php

//$sqlquery2 = "select * from tblmediationmessages where ipid = '$productid' AND ((ifromuid = '$mediationfromuserid' AND itouid = '$mediatoagainstuserid') OR (ifromuid = '0' and itouid = '$mediationfromuserid') OR (ifromuid = '$mediatoagainstuserid' and itouid = '$mediationfromuserid') OR (ifromuid = '$mediationfromuserid' and itouid = '0')) ORDER BY ddate ASC";

$sqlquery2 = "select * from tblmediationmessages where ipid = '$productid' AND ((ifromuid = '$mediationfromuserid' AND itouid = '$mediatoagainstuserid') OR (ifromuid = '0' and itouid = '$mediationfromuserid') OR (ifromuid = '$mediatoagainstuserid' and itouid = '$mediationfromuserid') OR (ifromuid = '$mediationfromuserid' and itouid = '0') OR (ifromuid = '0' and itouid = '$mediatoagainstuserid') OR (ifromuid = 'mediatoagainstuserid' and itouid = '0')) ORDER BY ddate ASC";

//echo $sqlquery2 ;
$query2 = mysql_query($sqlquery2);
$rows = mysql_num_rows($query2);
if($rows > 0)
{
	while($data2 = mysql_fetch_array($query2))
	{
		$fromuser = $data2['ifromuid'] ;
		//Getting Users info
		if($fromuser > 0)
		{
		$query1 = mysql_query("select * from tblmember where iid = '$fromuser'");
		$rows2 = mysql_num_rows($query1);
		if($rows2 > 0)
		{
			$data = mysql_fetch_array($query1);
			$firstname = $data['strfirstname'] ;
			$lastname = $data['strlastname'] ;
			$nick = $data['strnickname'] ;	
			$country = $data['strcountry'] ;
			$city = $data['strcity'] ;
				
		}
		}
		else
		{
			$firstname = "" ;
			$lastname = "" ;
			$nick = "Admin" ;	
			$country = "" ;
			$city = "" ;
		}
		//Getting Messages Information
		$message = $data2['strmessage'] ;
		$posteddate = $data2['ddate'] ;
		
		// SE Different Background FOR ADMIN , Seller And Buyer
		if($fromuser == $mediationfromuserid)
		{
			$backgroundcolor = "#CCCCFF" ;
		}
		else if($fromuser == 0)	
		{
			$backgroundcolor = "#FFCCCC" ;
		}
		else
		{
			$backgroundcolor = "#FFFF99" ;
		}	
		
		//Displaying messages in date descending order
		?>

			<tr bgcolor=<?php echo $backgroundcolor ;?>>
				<td class="SubHeading">
					<span class="Heading">From</span> <?php echo $nick ;?>
				</td>
			</tr>
			<tr bgcolor=<?php echo $backgroundcolor ;?>>
				<td class="SubHeading">
					<span class="Heading">Posted On</span> <?php echo $posteddate ;?>
				</td>
			</tr>
			<tr bgcolor=<?php echo $backgroundcolor ;?>>
				<td class="Heading">
					Message:-
				</td>
			</tr>
			<tr bgcolor=<?php echo $backgroundcolor ;?>>
				<td class="SubHeading">
					<?php echo $message ;?>
				</td>
			</tr>
			<tr bgcolor=<?php echo $backgroundcolor ;?>><td>&nbsp;</td></tr>
			<tr><td><hr width="50%" /></td></tr>
		<?php		
	//}
	}
	}
	else
	{
	?>
	<tr>
		<td class="SubHeading" width="100%">
			There is no Message now yet.
		</td>
	</tr>
	<?php
}	


//echo("select * from tblmessages where ipid = '$productid' AND iuid IN($arrMarkedUsers) ORDER BY ddate ASC");
//end;

?>




	<tr>
		<td class="Heading">
			Post New Message
		</td>
	</tr>
	
	<form name="messages" action="viewmediation.php"  method="post">
	<tr>
		<td>
			
			  <textarea id="postmessage" name="postmessage" ></textarea>
				<script language="javascript">
					generate_wysiwyg('postmessage');
				</script>
		</td>
	</tr>
	<tr>
		<td>
			<input type="hidden" name="hdnmediationid" value="<?php echo $mediationid ;?>" />
			<input type="hidden" name="hdnmediatorid" value="<?php echo $mediationfromuserid ;?>" />
			<input type="hidden" name="hdnmediationtoid" value="<?php echo $mediatoagainstuserid ; ?>" />
			<input type="hidden" name="hdnproductid" value="<?php echo $productid ;?>" />
			<input type="submit" name="submit" value=" Submit " />
		</td>
	</tr>
	</form>

</table>	