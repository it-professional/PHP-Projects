<?php

//echo(decryptId(encryptId(113,'ABCDZYX0987654321JUI200789'),'ABCDZYX0987654321JUI200789'));
//echo(encryptId(113,'ABCDZYX0987654321JUI200789'));

// unchanged, thanx Tom, Andy, fsx.nr01
function base64_url_encode($input) {
    return strtr(base64_encode($input), '+/=', '-_,');
    }

function base64_url_decode($input) {
    return base64_decode(strtr($input, '-_,', '+/='));
    }

// some variables are used for clarity, they can be avoided and lines can be shortened:

function encryptId($int, $TableSalt='') {
    global $GlobalSalt;    // global secret for salt.
   
    $HashedChecksum = substr(sha1($TableSalt.$int.$GlobalSalt), 0, 6);
    // The length of the "HashedChecksum" is another little secret,
    // but when the integers are small, it reveals...
   
    $hex = dechex($int);
    // The integer is better obfuscated by being HEX like the hash.
   
    return base64_encode($HashedChecksum.$hex);
    // reordered, alternatively use substr() with negative lengths...
    }

function decryptId($string, $TableSalt='') {
    // checks if the second part of the base64 encoded string is correct.
    global $GlobalSalt;    // global secret for salt.
    $parts = base64_decode($string);
    $hex = substr($parts, 6);
    $int = hexdec($hex);
    $part1 = substr($parts, 0, 6);    // The "checksum/salt" is always the same length
   
    return substr(sha1($TableSalt.$int.$GlobalSalt), 0, 6) === $part1
        ? $int
        : false;    // distinguish "0" and "false"
    }
?>