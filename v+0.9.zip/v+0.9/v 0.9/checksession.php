<?
if (!isset($_SESSION["loginid"]) || $_SESSION['loginid']  == "")
{
	?>
		<SCRIPT LANGUAGE="JavaScript">			
			window.location.href = "login.php";
		</SCRIPT>
	<?	
	end ;	
}
?>