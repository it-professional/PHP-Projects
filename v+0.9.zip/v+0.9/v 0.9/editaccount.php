<?php
session_start();
include("include/config.php");
include("checksession.php");
?>
<?php
include("include/template.php");
templateheader("" , "true");
?>
   <link href="include/css/rfnet.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="include/js/datetimepicker_css.js"></script>
<script language="JavaScript">
function closewindow()
{
	this.window.close();
	window.location.href = "main.php" ;
}

function editaccountrequired()
{
	
	if(document.editaccount.country.value == '')
	{
		alert("Please Enter your Country ");
		return false ;
		document.editaccount.country.focus() ;		
	}
	else if(document.editaccount.nlang.value == '')
	{
		alert("Please Enter your Native Language");
		return false ;
		document.editaccount.nlang.focus() ;		
	}
	else if(document.editaccount.socialnetwork.value == '')
	{
		alert("Please Select Most Used Social Network");
		return false ;
		document.editaccount.socialnetwork.focus() ;		
	}
	
	else if(document.getElementById("password").value != '')
	{
		if(document.getElementById("cpassword").value == '')
		{
			alert("Please Confirm your Password");
			return false ;
			document.getElementById("cpassword").focus();
		}
		if(document.getElementById("cpassword").value != document.getElementById("password").value)
		{
			alert("Password and Confirm Password does not match");
			return false ;
			document.getElementById("cpassword").focus();
		}
	}
	else
	{
		return true ;
	}
}


function deleteproduct(ival)
		{
			if ( ! confirm("Are you sure you want to delete this Picture ?") )
			{							
					return false;
			}
			else
			{	
				document.getElementById("hdndeletepictue").value = "DeletePicture" ;
				document.deletepicture.submit();
			}		
		}
</script>
<?php
// Delete Picture

if($_POST['hdndeletepictue'] != "")
{
	$strqry = "select * from tblmember where iid = '".$_SESSION['loginid']."'";
	$row = mysql_query( $strqry );
	$res = mysql_fetch_array ( $row );
	$path = "images/accountpictures/" . $res["strpicture"];
	if(file_exists($path))
	{
		$delete = unlink($path) ;
		$q = "UPDATE tblmember SET strpicture = '' WHERE iid = '".$_SESSION['loginid']."'";
		$recordSet = mysql_query ($q);
		$message = "Picture Has Been Deleted" ;
	}
	else
	{
		$message = "No Picture Found Of This Name" ;	
	}	
}


if(isset($_POST['submit']))
{

function deletePhoto($cid)
{
	// function for delete a photo
	$strqry = "select * from tblmember where iid = '$cid'";
	$row = mysql_query( $strqry );
	$res = mysql_fetch_array ( $row );
	if($res["strpicture"] != "" )
	{
		$path = "images/accountpictures/" . $res["strpicture"];
		if($do = unlink( $path )){
		
		//	unlink( "includes/images/".$res["image"] );
			$q = "UPDATE tblmember SET strpicture = '' WHERE iid = '$cid'";
			$recordSet = mysql_query ($q);
		}
		return $do;		
	} else
	return 1;
}

	$id = $_POST['iid'] ;
	$firstname = $_POST['fname'] ;
	$nickname = $_POST['nick'] ;
	$lastname = $_POST['lname'] ;
	$company = $_POST['company'] ;
	$email = $_POST['email'] ;
	$country = $_POST['country'] ;
	$city = $_POST['city'] ;
	$address = $_POST['address'] ;
	$phone = $_POST['phone'] ;
	$nlang = $_POST['nlang'] ;
	$Mlang = $_POST['Mlang'] ;
	$dbirth = $_POST['dbirth'] ;
	$socialnetwork = $_POST['socialnetwork'] ;
	$picture = $_FILES['picture']['name'] ;
	$date = date("y-m-d");
	$paypalid = $_POST['paypalid'];
	if($paypalid != "")
	{
		$bflag = 0 ;
	}
	else
	{
		$bflag = 1 ;
	}
	
	$nquery = '' ;
	
	if($_FILES['picture']['error'] <= 0)
	{
		
		if( ($_FILES["picture"]["type"] == "image/gif" || $_FILES["picture"]["type"] == "image/jpg" || $_FILES["picture"]["type"] ==  "image/jpeg" || $_FILES["picture"]["type"] ==  "image/pjpeg" || $_FILES["picture"]["type"] ==  "image/png"))
		{
			
			deletePhoto($id) ;
			move_uploaded_file($_FILES["picture"]["tmp_name"],
			"images/accountpictures/". $_FILES["picture"]["name"]);
			$nquery = mysql_query("update tblmember set strfirstname = '$firstname' , strlastname = '$lastname' , strcompany =  '$company' , strcountry = '$country' , strcity =  '$city' , straddress = '$address' , strphone = '$phone' , strnativelang = '$nlang' ,  strmangedlang = '$Mlang' , ddateofbirth = '$dbirth' , strsocialnetwork = '$socialnetwork' , strpicture = '$picture' , dtdatetime = NOW(), strpaypalemailid = '$paypalid', iflag = '$bflag' where iid = '$id' ");	
			
			if($_POST['password'] != '')
			{
				$password = $_POST['password'] ;
				//$password = md5($password);				
				//	$salt = 's+(_a*';
				//	$salt_pass = md5($password.$salt);						
					$mailquery = mysql_query("select strnickname from tblmember where where iid = '$id'");
					$mailrow = mysql_num_rows($mailquery);
					if($mailrow > 0)
					{
						$maildata = mysql_fetch_array($mailquery);
						$nname = $maildata['strnickname'] ;
					}	
					
					$encpassword = $nname.$password ;
					$salt = 's+(_a*';
					$salt_pass = md5($encpassword.$salt);	
				mysql_query("update tblmember set strpassword = '$salt_pass' where iid = '$id' ");
			}	
		
			
			$msg = 'true' ;		
		}
		else
		{
			$msg = 1 ;
			$msg = 'false' ;
			$message = "Only JPG and GIF images are Allowed" ;
		?>
			<script language="JavaScript">
				window.opener.location.href = window.opener.location.href ;
			</script>
		<?php	
		}

	}
	else
	{	
		$nquery = mysql_query("update tblmember set strfirstname = '$firstname' , strlastname = '$lastname' , strcompany =  '$company' , strcountry = '$country' , strcity =  '$city' , straddress = '$address' , strphone = '$phone' , strnativelang = '$nlang' ,  strmangedlang = '$Mlang' , ddateofbirth = '$dbirth' , strsocialnetwork = '$socialnetwork', dtdatetime = NOW() , strpaypalemailid = '$paypalid' , iflag = '$bflag' where iid = '$id' ");
	
	if($_POST['password'] != '')
			{
				$password = $_POST['password'] ;
				//$password = md5($password);
				//$salt = 's+(_a*';
				//$salt_pass = md5($password.$salt);
				$mailquery = mysql_query("select strnickname from tblmember where iid = '$id'");
					$mailrow = mysql_num_rows($mailquery);
					if($mailrow > 0)
					{
						$maildata = mysql_fetch_array($mailquery);
						$nname = $maildata['strnickname'] ;
					}	
					
					$encpassword = $nname.$password ;
					$salt = 's+(_a*';
					$salt_pass = md5($encpassword.$salt);
				mysql_query("update tblmember set strpassword = '$salt_pass' where iid = '$id' ");
			}
			$msg = 'true' ;	
			
	}
	
	if($msg == 'true')
	{
		$message = "Your Account Has Been Edited" ;
	?>
			<script language="JavaScript">
				//window.opener.location.href = window.opener.location.href ;
				window.location.href = "editaccount.php?message=1" ;
			</script>
	<?php
	}

}
?>



<table cellpadding="0" cellspacing="0" border="0"  >
<tr >
	<td class="Heading">
	  	Edit Account
	</td>	
	<tr><td>&nbsp;</td></tr>
<?php
if($message != "")
{
?>
<tr>
<td colspan="2" align="center" class="redlink">
<b><?php echo $message ;
$message = "" ;
 ?></b>
</td>
</tr>
<?php
}
?>	

<?php
if(isset($_GET['message']) && $_GET['message'] != "")
{
	$messageno = $_GET['message'] ;
	
	if($messageno == 1)
	{
		$strmessage = "Your Account Has Been Edited" ;
	}	
?>
<tr>
<td colspan="2" align="center" class="redlink">
<b><?php echo $strmessage ;
 ?></b>
</td>
</tr>
<?php
}
?>
	
<?php
$query = mysql_query("select * from tblmember where iid = '".$_SESSION['loginid']."'  ");
while($data = mysql_fetch_array($query))
{
	$iid = $data['iid'];
	$firstname = $data['strfirstname'] ;
	$nickname = $data['strnickname'] ;
	$lastname = $data['strlastname'] ;
	$company = $data['strcompany'] ;
	$email = $data['stremail'] ;
	$country = $data['strcountry'] ;
	$city = $data['strcity'] ;
	$address = $data['straddress'] ;
	$phone = $data['strphone'] ;
	$nlang = $data['strnativelang'] ;
	$Mlang = $data['strmangedlang'] ;
	$dbirth = $data['ddateofbirth'] ;
	$socialnetwork = $data['strsocialnetwork'] ;
	$password = $data['strpassword'] ;
	$password = md5($password);
	$picture = $data['strpicture'] ;
	$date = date("y-m-d");
	$paypalemailid = $data['strpaypalemailid'] ;
	
}

?>	
	<form action="editaccount.php" method="post" name="editaccount" enctype="multipart/form-data" onSubmit="return editaccountrequired()">
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">First Name:</td>
							<td>
								<input type="text" id="fname" name="fname" value="<?php echo $firstname ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Last Name:</td>
							<td>
								<input type="text" id="lname" name="lname" value="<?php echo $lastname ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Nick :</td>
							<td >
								<input value="<?php echo $nickname ;?>" readonly="readonly" style="background:#EBEBE4; border:solid; border:#CCCCCC;"  type="text" id="nick" name="nick" size="30">
							</td>
						</tr>
						
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Company:</td>
							<td>
								<input type="text" id="company" name="company" value="<?php echo $company ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Email Address:</td>
							<td>
								<input type="text" value="<?php echo $email ;?>" readonly="readonly" style="background:#EBEBE4; border:solid; border:#CCCCCC;" id="email" name="email"  size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Country:</td>
							<td>
								<input type="text" id="country" name="country" value="<?php echo $country ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">City:</td>
							<td>
								<input type="text" id="city" name="city" value="<?php echo $city ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Address:</td>
							<td>
								<input type="text" id="address" name="address" value="<?php echo $address ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Phone No. :</td>
							<td>
								<input type="text" id="phone" name="phone" value="<?php echo $phone ; ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">PayPal Email ID:</td>
							<td>
								<input type="text" id="paypalid" name="paypalid" value="<?php echo $paypalemailid ?>" size="30">
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Native Language:</td>
							<td>
								<select name="nlang" id="nlang" style="width:205px;">
										<?php 
											$languagequery = mysql_query("SELECT * FROM tbllanguages order by iid");
											while($languagedata = mysql_fetch_array($languagequery))
											{
												$strnativelanguage = $languagedata['language_name'] ;
										?>
										<option value="<?php echo $strnativelanguage?>" <?php if($strnativelanguage == $nlang) { ?> selected="selected" <?php }?>><?php echo $strnativelanguage ;?></option>
										<?php }?>
										</select>
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">2d Managed Language:</td>
							<td>
								<select name="Mlang" id="Mlang" style="width:205px;">
										<?php 
											$managelanguagequery = mysql_query("SELECT * FROM tbllanguages order by iid");
											while($managedlanguagedata = mysql_fetch_array($managelanguagequery))
											{
												$strmanagelanguage = $managedlanguagedata['language_name'] ;
										?>
										<option value="<?php echo $strmanagelanguage?>" <?php if($strmanagelanguage == $Mlang) { ?> selected="selected" <?php }?>><?php echo $strmanagelanguage ;?></option>
										<?php }?>
										</select>
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Date of Birth:</td>
							<td>
								<input type="Text" name="dbirth" readonly="readonly" style="background:#EBEBE4; border:solid; border:#CCCCCC;" id="dbirth" value="<?php echo $dbirth ?>"  size="30"> 
					<a href="javascript:NewCssCal('dbirth','yyyymmdd')"><img src="images/cal.gif" width="16" height="16" alt="Pick a date" title="Pick a Date" ></a>
								
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">*Most Used Social Network:</td>
							<td>
								<select id="socialnetwork" name="socialnetwork"  style="width:205px;">
									<option value=""></option>
									<option <?php if($socialnetwork == "facebook") { ?> selected="selected" <?php }?> value="facebook">Face Book</option>
									<option <?php if($socialnetwork == "myspace") { ?> selected="selected" <?php }?> value="myspace">My Space</option>
									<option  <?php if($socialnetwork == "twitter") { ?> selected="selected" <?php }?> value="twitter">Twitter</option>
									<option <?php if($socialnetwork == "youtube") { ?> selected="selected" <?php }?> value="youtube">You Tube</option>
									<option <?php if($socialnetwork == "google") { ?> selected="selected" <?php }?> value="google">Google</option>
									<option <?php if($socialnetwork == "yahoo") { ?> selected="selected" <?php }?> value="yahoo">Yahoo</option>
									<option <?php if($socialnetwork == "squidoo") { ?> selected="selected" <?php }?> value="squidoo">Squidoo</option>
									<option <?php if($socialnetwork == "bloglines") { ?> selected="selected" <?php }?> value="bloglines">Bloglines</option>
									<option <?php if($socialnetwork == "other") { ?> selected="selected" <?php }?> value="other">other</option>
									
								</select>
							</td>
						</tr>
						
						
						
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Password:</td>
							<td>
								<input type="password" name="password" id="password"   size="30"> 
								<input type="hidden" name="hdnpasswrd" id="hdnpasswrd" value="<?php echo $password ?>" >						
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;" class="Heading">Confirm Password:</td>
							<td>
								<input type="password" name="cpassword" id="cpassword"  size="30"> 
							</td>
						</tr>
						<tr>
							<td style="padding-left:10px; padding-top:10px;"  class="Heading">
								Your Picture:
							</td>
							<td>
								<input name="picture" id="picture"   type="file" >
							</td>
						</tr>
						<?php if($picture != '') { ?>
						<tr>
							<td></td>
							<td style="padding-top:10px; padding-left:5px;">
								<img align="absmiddle" src="images/accountpictures/<?php echo $picture ;?>"  border="0" width="90" width="68" >
							<a style="padding-left:60px;" onClick="Javascript:return deleteproduct(<?php echo $iid ; ?>);"><img src="images/Delete.gif" border="0" title="click to Delete the Picture"></a>
							</td>
						</tr>
						<?php }?>
						
						<tr>
						<td colspan="2" align="center" style="padding-top:20px;" bgcolor="">
						<input type="hidden" name="iid" value="<?php echo $iid ;?>">
						<input type="submit" name="submit" value=" OK " class="Heading"     >
						<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">
						</td>
						</tr>
				<input type="hidden" name="action" value="Signup">
				</form>
				
<form name="deletepicture" method="post">
<input type="hidden" name="hdndeletepictue" id="hdndeletepictue" value="" />
</form>

</table>
<?php
templatefooter("" , "true");
?>