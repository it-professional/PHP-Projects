<?php 
session_start();
include("checksession.php");
?>
<title> Give Ratings </title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>
<?php
include("include/config.php");
$ratingmessage = "" ;
?>
<?php 
if(isset($_POST['rating']) &&  $_POST['rating'] != "") 
{
	$ratingno = $_POST['rating'] ;
	$ratingdescription = $_POST['ratingdescription'] ;
	$boughtid = $_POST['hdnboughtid'] ;
	//$backlink = $_POST['hdnbacklink'] ; 
	$ratingfrom = $_SESSION['loginid'] ;
	$today = date("Y-m-d");
	$query1 = mysql_query("SELECT * From tblboughtproducts WHERE iid = '$boughtid'");
	$data1 = mysql_fetch_array($query1);
	$prodid = $data1['ipid'] ;
	
	$backlink = $_SESSION["Backlink1"] ;
	$blink = explode(".php",$backlink);
	if($blink[0] == 'boughtproducts')
	{
		$ratingto = $data1['isellerid'] ;
	}
	else
	{
		$ratingto = $data1['ibuyerid'] ;
	}
	
		$sqlquery = "INSERT INTO tblrating(iratingfrom,iratingto,irating,strdescription,ddate) VALUES('$ratingfrom','$ratingto','$ratingno','$ratingdescription','$today')";
	
	
	$query2 = mysql_query($sqlquery);
	if($query2)
	{
//	echo $_GET['backlink'] ;
	?>
		<script language="javascript">
			window.location.href = 'main.php?pg=<?php echo $backlink ;?>' ;
		</script>
	<?php
	}
}
?>


<table cellpadding="0" cellspacing="0" border="0" width="100%" >
<?php if($_SESSION["Backlink1"] != '')  { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onclick="javascript: goback('<?php echo $_SESSION["Backlink1"] ;?>');"  colspan="5">Go Back
</td>
</tr><?php } ?>
<?php if($ratingmessage != "" ) {?>
<tr><td class="redlink" align="center"><?php echo $ratingmessage ; ?></td></tr>
<?php } ?>
<tr><td>&nbsp;</td></tr>
<form name="ratingform" method="post">
<tr>
	<td class="SubHeading" colspan="2">
		<b>Select Rating:</b>
		<select name="rating" id="rating" class="SubHeading">
			<option value="">Select Rating</option>
			<option value="10">10-Excellent</option>
			<option value="9">9-Superb</option>
			<option value="8">8-Very Good</option>
			<option value="7">7-Good</option>
			<option value="6">6-Above Average</option>
			<option value="5">5-Average</option>
			<option value="4">4-Below Average</option>
			<option value="3">3-Poor</option>
			<option value="2">2-Bad</option>
			<option value="1">1-Horrible</option>
		</select>
	</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
	<td class="SubHeading">
		<b>Comments:</b>
	</td>
</tr>
<tr>
	<td class="SubHeading">
		<textarea id="ratingdescription" name="ratingdescription" ></textarea>
				<script language="javascript">
					generate_wysiwyg('ratingdescription');
				</script>
	</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
	<td>
		<input type="hidden" value="<?php echo $_GET['bid'] ; ?>" name="hdnboughtid" id="hdnboughtid"  />
	
		<input type="submit" class="SubHeading" value=" Submit " onclick="return ratingrequired()" />
	</td>
</tr>
</form>
</table>