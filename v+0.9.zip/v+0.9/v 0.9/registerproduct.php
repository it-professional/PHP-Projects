<?php
session_start() ;
include("include/config.php");
include("checksession.php");
include("include/template.php");
templateheader("" , "true");
$message ="" ;
?>


<?php
if(isset($_POST['productname']) && $_POST['productname'] != "")
{
$productname = $_POST['productname'] ;
$productprice = $_POST['productprice'] ;
$other = $_POST['other'] ;
$otherdescription = $_POST['otherdescription'] ;
$characteristics = $_POST['hdncharacter'] ;
$attributes = $_POST['hdnatribut'] ;
$characterlength = $_POST['hdnlength'] ;
$attributelength =  $_POST['hdnlength'] ;
$picture = $_FILES['picture']['name'] ;

$date = date("y-m-d");
$userid = $_SESSION['loginid'] ;

// Before Insertion check Paypal Account of Login User

$chkpaypalaccount = mysql_query("SELECT strpaypalemailid FROM tblmember WHERE iid = '$userid'");
$fetchpaypalid = mysql_fetch_array($chkpaypalaccount);
$paypalaccountid = $fetchpaypalid['strpaypalemailid'] ;

if($paypalaccountid != "")
{


	$sqlinsetionquery = "" ;
	if($_FILES['picture']['error'] > 0)
	{
		$sqlinsetionquery ="insert into tblproducts(strproductname,iproductprice , strother , strotherdesc , iuid ,  dtdate) values('$productname' ,'$productprice', '$other' , '$otherdescription' , '$userid'  , '$date')" ;
		
	}
	else  
	{
		if( ($_FILES["picture"]["type"] == "image/jpeg" || $_FILES["picture"]["type"] == "image/gif" || $_FILES["picture"]["type"] ==  "image/jpg" || $_FILES["picture"]["type"] ==  "image/pjpeg" || $_FILES["picture"]["type"] ==  "image/png"))
		{
				$randomnumer = rand();	
				$strpicturename = "Product_".$randomnumer."_".$_FILES["picture"]["name"] ;			
				move_uploaded_file($_FILES["picture"]["tmp_name"],
				"images/productpictures/".$strpicturename);
				$sqlinsetionquery ="insert into tblproducts(strproductname,iproductprice , strother , strotherdesc , iuid ,  dtdate , strpicture) values('$productname' ,'$productprice', '$other' , '$otherdescription' , '$userid'  , '$date' , '$strpicturename')" ;
		}
		else
		{
			
			$sqlinsetionquery = "" ;
			$message = "Only JPG and GIF Images are allowed" ;
		}
	}
	
	
	if($sqlinsetionquery != "")
	{
		$query1 = mysql_query($sqlinsetionquery) ;
		
		if($query1)
		{
			$query2 = mysql_query("select max(iid) as iid from tblproducts");
			$data = mysql_fetch_array($query2);
			$iid = $data['iid'] ;
			$character = explode("," , $characteristics) ;
			$attribute = explode("," , $attributes) ;
			while($characterlength >= 0)
			{
				$chat = $character[$characterlength] ;
				$atr = 	$attribute[$characterlength] ;
				
				$query2 = mysql_query("insert into tblproductfeatures (ipid , icharid , iatrid) values ( '$iid' , '$chat' , '$atr')");
				$characterlength-- ;
			}	
			$message  = "Thank you for registering your Product" ;
			?>
			<script language="JavaScript" >
			window.location.href = "main.php?pg=selleraccount.php";
			</script>
		<?php
		}
	}
}
else
{
	$message  = "Your Pay Pal Account Email Address is Empty. <br> Please First Register your PayPal Email Address using Edit Account link. " ;
}	


?>
<?php 
}
?>
<table cellpadding="0" cellspacing="0" border="0" align="center">
	<?php if($message != '') { ?>
	<tr>
		<td class="redlink" style="padding:10px;" align="center" colspan="2">
			<b><?php echo $message ;
			$message = "" ;
			?></b>
		</td>
	</tr>
	<?php }?>
	
	<tr>
		<td class="Heading" style="padding:10px;" align="center" colspan="2">
			Register Product To Sell
		</td>
	</tr>		

	<form action="registerproduct.php" method="post" name="editaccount" enctype="multipart/form-data" onSubmit="return registerproducts()" >

	<tr>
		<td class="SubHeading" style="padding-right:7px;">
			*Name:
		</td>
		<td style="padding-top:5px;">
			<input class="SubHeading" type="text" name="productname" id="productname" size="30" />
		</td>
	</tr>
	<tr>
		<td class="SubHeading" style="padding-right:7px;">
			*Price:
		</td>
		<td style="padding-top:5px;" class="SubHeading">
			$<input class="SubHeading" type="text" name="productprice" id="productprice" size="26" />.00
		</td>
	</tr>
	<tr>
		<td class="Heading" style="padding-top:8px; padding-bottom:5px;"  >
			Charteristics
		</td>
		<td class="Heading"  align="center" style="padding-top:8px; padding-bottom:5px;" >&nbsp;
			
		</td>
	</tr>
	
			<?php
				include("include/config.php");
				$query1 = mysql_query("select * from tblproductcharacteristics where bactive = 'Active' order by ipchid asc");
				while($data = mysql_fetch_array($query1))
				{
					$ipid = $data['ipchid'] ;
					$characteristics = $data['strcharacteristicsname'] ;
				?>
				<tr>
					<td class="SubHeading" style="padding-right:7px;">
						<?php echo $characteristics ;?>
						<input type="hidden"  id="hdncharacteristic" name="hdncharacteristic" value="<?php echo $ipid ; ?>" >
					</td>
					<td class="SubHeading" style="padding-right:7px; padding-top:5px;">
						<select name="attributes" id="attributes" style="width:162px;">
	
				<?php	
					$query2 = mysql_query("select * from tblproductattributes where ipchid = '$ipid' and bactive = 'Active' order by iid asc  ");
					while($data2 = mysql_fetch_array($query2))
					{
						$iaid = $data2['iid'] ;
						$attribute = $data2['strattribute'] ;
						
				?>
					<option value="<?php echo $iaid?>"><?php echo $attribute ;?></option>
						
				<?php	
					}
				?>
				</select>
					</td>
			</tr>		
				<?php	
				}
			?>
			<tr>
				<td class="SubHeading" style="padding-right:7px;">
					Other:
				</td>
				<td style="padding-top:5px;">
					<input class="SubHeading" type="text" name="other" id="other" size="30">
				</td>
		</tr>
		
		<tr>
			<td class="SubHeading" style="padding-right:7px;">
				Description:
			</td>
			<td style="padding-top:5px;">
			<textarea class="SubHeading" cols="30"  rows="3" name="otherdescription" id="otherdescription"></textarea>
			</td>
		</tr>
		
		<tr>
			<td style="padding-left:10px; padding-top:10px;"  class="SubHeading">
				Product Picture:
			</td>
			<td style="padding-top:5px; padding-left:5px;">
				<input class="SubHeading"  name="picture" id="picture"  type="file" >
			</td>
		</tr>
		
	
		
		
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td align="center" colspan="2">
				<input type="hidden" name="hdncharacter" id="hdncharacter" value="">
				<input type="hidden" name="hdnatribut" id="hdnatribut" value="">
				<input type="hidden" name="hdnlength" id="hdnlength" value="">
				<input class="SubHeading" type="submit" name="submit" value=" OK " >
				<input class="SubHeading" type="button" value=" Cancel " name="cancel">
			</td>
		</tr>
		</form>
	
</table><?php
templatefooter("" , "true");
?>