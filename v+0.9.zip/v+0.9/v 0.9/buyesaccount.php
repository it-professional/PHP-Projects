<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td width="75%" valign="top" class="content">		
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td class="content">	
						<span  class="heading">Buyers Account Information</span><br />
						<p class="content">Buyers Account Information will be published here</p>
					</td>
				</tr>
			</table>		
		</td>
		<td width="25%" valign="top" style="padding-right:10px;">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td bgcolor="#000000" align="center" class="whiteheading"  >Main Menu 1</td>
				</tr>
				<tr>
					<td bgcolor="#DBE2FF" style="padding-left:5px; padding-right:5px; height:164px;" valign="top" class="content">
						item 1 <br>
						item 2 <br>
					</td>
				</tr>
				<tr>
					<td bgcolor="#000000" align="center" class="whiteheading" >Main Menu 2</td>
				</tr>
				<tr>
					<td bgcolor="#DBE2FF" style="padding-left:5px; padding-right:5px; height:164px;" valign="top" class="content">
						item 1 <br>
						item 2 <br>
					</td>
				</tr>
			</table>
		</td>
					
	</tr>
</table>
