<?php session_start() ;
include("checksession.php");
?>
<title>Mediation Message</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>
<?php 
include("include/config.php");
if(isset($_POST['submit']))
{
	$boughtuserid = $_POST['hdnboughtuserid'] ;
	$productowner = $_POST['hdnproductownerid'] ;
	$boughtproductid = $_POST['hdnboughtid'] ;
	$mediatorid = $_SESSION['loginid'] ;
	$pid = $_POST['hdnproductid'] ;
	$msg= $_POST['postmessage'] ;
	$hdnbacklink = $_POST['hdnbacklink'] ;
	$todaydate = date("Y-m-d");
	
	if($hdnbacklink == "boughtproducts.php")
	{
	$sqlquery4 = "INSERT INTO tblmediation(ipid,imediatorid,itoid,ddate) values('$pid' ,'$mediatorid','$productowner','$todaydate')";
	}
	else
	{
	$sqlquery4 = "INSERT INTO tblmediation(ipid,imediatorid,itoid,ddate) values('$pid' ,'$mediatorid','$boughtuserid','$todaydate')";
	}
	$query4 = mysql_query($sqlquery4);
	if($query4)
	{
		$qurye6 = mysql_query("SELECT MAX(iid) as iid FROM tblmediation");
		$data6 = mysql_fetch_array($qurye6);
		$mediationid = $data6['iid'];
		
		if($hdnbacklink == "soldproducts.php")
		{
		$query15 = "INSERT INTO tblmediationmessages(ipid,imediationid,bactive,strmessage,ifromuid,itouid,ddate) VALUES('$pid','$mediationid','1','$msg','$mediatorid','$boughtuserid','$todaydate')";
		}
		else
		{
			$query15 = "INSERT INTO tblmediationmessages(ipid,imediationid,bactive,strmessage,ifromuid,itouid,ddate) VALUES('$pid','$mediationid','1','$msg','$mediatorid','$productowner','$todaydate')";
		}
		$query5 = mysql_query($query15);
		
		// GET emailid of product buyer 
		$mailquery = mysql_query("select stremail from tblmember where iid = '$boughtuserid'");
		$maildata = mysql_fetch_array($mailquery);
		$buyeremailid = $maildata['stremail'] ;
		
		// Get emailid of Product owner
		$mailquery2 = mysql_query("select stremail from tblmember where iid = '$productowner'");
		$maildata2 = mysql_fetch_array($mailquery2);
		$productownerid = $maildata2['stremail'] ;
		
		// Get Mediator Nick
		$mailquery3 = mysql_query("select strnickname from tblmember where iid = '$mediatorid'");
		$maildata3 = mysql_fetch_array($mailquery3);
		$receivernick = $maildata3['strnickname'] ;
		
		// Get Product Name
		$mailquery4 = mysql_query("select strproductname from tblmember where iid = '$ipid'");
		$maildata4 = mysql_fetch_array($mailquery4);
		$productname = $maildata4['strproductname'] ;
		
		
		$headers = "MIME-Version: 1.0\r\n";  
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: PickmeFriend.com";
		
		$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
		$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
		$strHTML .= "Mediation is going to start against".$productname." Product.<br> It is first Mediation message and it is started from ";
		$strHTML .= "<b>".$receivernick."</b><br>";
		$strHTML .= "<b>Message: </b>".$receivernick."<b><br>";
		$strHTML .= "</td></tr></table>";
			
		$strHTML = stripslashes($strHTML);	
		
		$subject = "Mediation Started" ;
		
		  mail($buyeremailid,$subject,$strHTML,$headers);
		  mail($productownerid,$subject,$strHTML,$headers);
		  mail("arbitration@pickmefriend.com",$subject,$strHTML,$headers);
		
		
	?>
		<script language="javascript">
			window.location.href = 'main.php?pg=<?php echo $hdnbacklink ; ?>' ;
		</script>
	<?php
	}
}
?>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?php if($_GET['blink'] == 'boughtproducts.php')  { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('mediation.php?boughtproductid=<?php echo $_GET['boughtproductid'] ;?>&blink=boughtproducts');" colspan="5" >Go Back 
</td>
</tr>
<?php } else if($_GET['blink'] == 'soldproducts.php') {?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('mediation.php?boughtproductid=<?php echo $_GET['boughtproductid'] ;?>&blink=soldproducts.php');" colspan="5" >Go Back 
</td>
</tr>
<?php } else {  ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_GET['blink'];?>');" colspan="5" >Go Back
</td>
</tr>
<?php } ?>
<?php
$boughtproductid = $_GET['boughtproductid'];

$query1 = mysql_query("SELECT * FROM tblboughtproducts where iid = '$boughtproductid'");
$data = mysql_fetch_array($query1) ;

$productid = $data['ipid'] ;
$sellerid = $data['isellerid'] ;
$buyerid = $data['ibuyerid'] ;
//$productowner = $_SESSION['loginid'];



$query2 = mysql_query("SELECT strproductname FROM tblproducts WHERE iid = '$productid'");
$data2 = mysql_fetch_array($query2);
$productname = $data2['strproductname'] ;

?>
<tr>
		<td colspan="2" width="100%" valign="top"  align="left" bgcolor="#CCCCCC" class="Heading">
			<font face="verdana" size="+1" color="#000000"><b><?php echo $productname ;?>&nbsp; Mediation</b></font>
		</td>
</tr>
<tr>
		<td class="Heading">
			Description
		</td>
	</tr>
	
	<form name="mediation" action="continuemediaton.php"  method="post">
	<tr>
		<td>
			
			  <textarea id="postmessage" name="postmessage" ></textarea>
				<script language="javascript">
					generate_wysiwyg('postmessage');
				</script>
		</td>
	</tr>
	<tr>
		<td>

			
			<input type="hidden" name="hdnproductownerid" value="<?php echo $sellerid ;?>" />
			<input type="hidden" name="hdnboughtuserid" value="<?php echo $buyerid ;?>" />
			<input type="hidden" name="hdnproductid" value="<?php echo $productid?>" />
			<input type="hidden" name="hdnbacklink" value="<?php echo $_GET['blink'] ;?>" />
			<input type="hidden" name="hdnboughtid" value="<?php echo $boughtproductid ;?>"  />
			<input type="submit" name="submit" value=" Submit " />
		</td>
	</tr>
	</form>

</table>	