<?php session_start();
include("checksession.php");
$_SESSION["Backlink1"] = "buy.php";

if(isset($_GET["ysroll"]) && $_GET["ysroll"] != "")
{
	$yscrollpostion = $_GET["ysroll"];
}	
else
{
	$yscrollpostion = 0 ;
}	
if(isset($_GET["externalbackscrolllink"]) && $_GET["externalbackscrolllink"] != "")
{
	$externalscrollpostion = $_GET["externalbackscrolllink"];
}
else
{
	$externalscrollpostion = 0 ;
}
 ?>
<script type="text/javascript" src="include/js/functions.js"></script>

<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<table cellpadding="0" cellspacing="0" border="0" align="left" width="100%">
	<!--<tr>
		<td colspan="11" align="center" class="redlink" id="markedstatus">&nbsp;
		
		</td>
	</tr>-->
	<tr>
		<td class="Heading" style="padding:10px;" align="left" colspan="2">
			Search Products
		</td>
	</tr>
	<!--<tr>
		<td colspan="4" class="SubHeading" style="padding-right:7px;">
			<input type="radio" value="name" onclick="changevalue('name');"  id="searchby" name="searchby" />
			<u class="Heading" style="text-decoration:none">Search By Name:</u>
		</td>
	</tr>
	<tr>
		<td class="SubHeading" style="padding-right:7px;">
			*Name:
		</td>
		<td style="padding-top:5px;">
			<input class="SubHeading" type="text" name="productname" id="productname" size="30" />
		</td>
	</tr>
	<tr style="height:10pt;"><td colspan="11"></td></tr>
	<tr style="height:10pt;"><td colspan="11"><hr   width="70%" /></td></tr>
-->
	<tr>
		<td colspan="4" class="SubHeading" style="padding-right:7px;">
			<!--<input type="radio" value="char" onclick="changevalue('char');" checked="checked" id="searchby" name="searchby" />--><u class="Heading" style="text-decoration:none">Select Characteristics:</u>
		</td>
	</tr>
	<tr>
			<?php
				include("include/config.php");
				$noofrecords = 1;
				function str_split1($string,$string_length=1) {
        if(strlen($string)>$string_length || !$string_length) {
            do {
                $c = strlen($string);
                $parts[] = substr($string,0,$string_length);
                $string = substr($string,$string_length);
            } while($string !== false);
        } else {
            $parts = array($string);
        }
        return $parts;
    }
				
			
				$query1 = mysql_query("select * from tblproductcharacteristics  where bactive = 'Active' order by ipchid asc");
				while($data = mysql_fetch_array($query1))
				{
					$ipid = $data['ipchid'] ;
					$characteristics = $data['strcharacteristicsname'] ;
				?>
				
					<td class="SubHeading" style="padding-right:7px;">
						<?php echo $characteristics ;?>
						<input type="hidden"  id="hdncharacteristic" name="hdncharacteristic" value="<?php echo $ipid ; ?>" >
					</td>
					<td class="SubHeading" style="padding-right:7px; padding-top:5px;">
						<select name="attributes" id="attributes" style="width:162px;">
						<option value=""></option>
	
				<?php	
					
					$query2 = mysql_query("select * from tblproductattributes where ipchid = '$ipid' and bactive = 'Active' order by iid");
					while($data2 = mysql_fetch_array($query2))
					{
						$iaid = $data2['iid'] ;
						$attribute = $data2['strattribute'] ;
						
				?>
					<option value="<?php echo $iaid?>"><?php echo $attribute ;?></option>
						
				<?php	
					}
					$noofrecords++ ;
				?>
					</select>
				</td>
					
				<?php
				if($noofrecords == 4){
				?>
				</tr><tr>
				<?php
				$noofrecords = 1 ;	
				}
				}
			?>
			
				<td class="SubHeading" style="padding-right:7px;">
					Other:
				</td>
				<td style="padding-top:8px;">
					<input class="SubHeading" type="text" name="other" id="other" size="30">
				</td>
				</tr>
				<tr style="height:10pt;"><td colspan="11"></td></tr>
				<tr style="height:10pt;"><td colspan="11"><hr   width="70%" /></td></tr>
		
				<tr>
					<td colspan="4" width="100%">
						<table cellpadding="0" cellspacing="0" border="0">
							<tr>
								<td>
									<h4 class="Heading"><a href="javascript: showhidesearch();" class="Heading" style="text-decoration:none;">Advance Search</a></h4>			
								</td>
							</tr>
							<tr id="tradvance" style="display:none;">
								<td class="SubHeading">
									Advance Search Cretirea will be here
								</td>
							</tr>
						</table>
					</td>
					
				</tr>
		<tr>
			<td align="center" colspan="4">
				<input type="hidden" name="hdnsearchby" id="hdnsearchby" value="char" />
				<input class="SubHeading" type="button" name="submit" value=" Search  " onClick="javascript: searchingproducts()" >
				<input class="SubHeading" type="button" value=" Reset "  onclick="refresh1()" />
				
			</td>
		</tr>
		
		<tr><td>&nbsp;</td></tr>
		
		<tr>
		<td colspan="2" class="Heading" align="left">
			<h4 class="Heading">View Products</h4>
			<input type='hidden' id='scrollpos' />
		</td>
	</tr>

<?php

		/* Pagination Functionality */
 /* Set current, prev and next page */
	$page = (!isset($_GET['page']))? 1 : $_GET['page']; 
	$prev = ($page - 1);
	$next = ($page + 1);
	
	/* Max results per page */
	$max_results = 20;
	
	/* Calculate the offset */
	$from = (($page * $max_results) - $max_results);
	
	
    $q = "SELECT * FROM tblproducts ORDER BY strproductname ASC ";
	$result = mysql_query($q);
	
   /* Error occurred, return given name by default */
   $num_rows = mysql_num_rows($result);
   
  	/* Grabbing the total rows*/
   $total_results = mysql_num_rows($result);
   
   /* Counting total pages*/
   $total_pages = ceil($total_results / $max_results);
   //mysql_close($mysqlconn);
   /* Initializing the pagination*/
   $pagination = "";
   
   /* Create a PREV link if there is one */

	if($page > 1)
	{
		$pagination .= "<a href=main.php?pg=buy.php&action=".$HTTP_GET_VARS["action"]."&page=".$prev.">&lt; &lt;&nbsp;Previous&nbsp;</a>";
	}
	else
	{
		$pagination .= "<label class=csstext>&lt; &lt;&nbsp;Previous&nbsp;</label>";
	}
	/* Loop through the total pages */
	for($i = 1; $i <= $total_pages; $i++)
	{
		if(($page) == $i)
		{
			$pagination .= "<label class=csstextbold>[".$i."]</label>";
		}
		else
		{
			$pagination .= "<a href=main.php?pg=buy.php&action=".$HTTP_GET_VARS["action"]."&page=".$i.">&nbsp;".$i."&nbsp;</a>";
		}
	}
	
	/* Print NEXT link if there is one */
	
	if($page < $total_pages)
	{
		$pagination .= "<a href=main.php?pg=buy.php&action=".$HTTP_GET_VARS["action"]."&page=".$next.">&nbsp;Next&nbsp;&gt;&gt</a>";
	}
	else
	{
		$pagination .= "<label class=csstext>&nbsp;Next&nbsp;&gt;&gt</label>";
	}
?>	

<?php if($MarkBidMessage != "" ) {?>
<tr>
	<td>
		<?php echo $MarkBidMessage ;?>
	</td>
</tr>
<?php }?>


	<tr>
		<td colspan="11">
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td height="6" colspan="11" bgcolor="#999999" align="right" >&nbsp;
					
					</td>
				</tr>				
				<tr>
					<td colspan="11" id="seachproduct">
					<div id="divsupermain" style="height :200px ;width:100%; overflow-x:hidden; overflow-y:scroll" onscroll="showscroll(this.scrollTop)">
					
						<table cellpadding="0" width="100%" cellspacing="0" border="0">
							<tr bgcolor="#CCCCCC">
							<td class="SubHeading">&nbsp;</td>
								<td class="SubHeading" width="25%"><b>Product Name</b></td>
								<td class="SubHeading" width="65%"><b>Product Description</b></td>
								
							</tr>
							
								
							<?php 
								$strQry = "SELECT * FROM tblproducts ORDER BY strproductname ASC LIMIT $from, $max_results" ;	
								$query2 = mysql_query($strQry);
								$row = mysql_num_rows($query2);
								if($row > 0)
								{
									while($data = mysql_fetch_array($query2))
									{
										$iid = $data['iid'] ;					
										$productname = $data['strproductname'] ;
										$productdescriptions = $data['strotherdesc'] ;
										$iuid = $data['iuid'] ;
										
										$chkbanneduserquery = mysql_query("SELECT istatus FROM tblmember WHERE iid = '$iuid'") ;
										$fetchbannedquerydata = mysql_fetch_array($chkbanneduserquery);
										$bannstatus = $fetchbannedquerydata['istatus'] ;
										if($bannstatus != 0)
										{										
											if(strlen($productdescriptions)>=100)
											{
												if(!function_exists('str_split')) 
												{ 
													$productdescription = str_split1($productdescriptions,100);
												}
												else
												{
													$productdescription = str_split($productdescriptions,100);
												}	
											}	
																		
										
									?>
									
										<tr>
											<td align="left" >
												<table>
													<tr>
														<td ><a  href="javascript: viewproductonbuy(<?php echo $iid ; ?>);" name="productview" id="productview"><img style="cursor:pointer;" src="images/view.jpg" border="0" title="click to View"></a></td>
														<td><a onClick="Markproduct(<?php echo $iid ; ?> , <?php echo $iuid ;?>);"><img style="cursor:pointer;" src="images/buy.gif" border="0" width="24" height="24" title="Click to Mark the Product" /></a></td>
													</tr>
												</table>
												
										   </td>
										   
											<td class="Heading" width="25%"  >
												<?php echo $productname ;?>
											</td>
											<td class="Subheading" align="left" width="65%" >
											<?php
											if(strlen($productdescriptions)>100)
											{
												 echo  $productdescription[0] ."&nbsp;......." ;
											}
											else
											{ 
												
												echo $productdescriptions ;
											}	 
											 ?>
											</td>
											
										</tr>
									<?php	
										}
									}
								}
								else
								{
								?>
									<tr>
										<td class="SubHeading" colspan="11">
											No Product Found.
										</td>
									</tr>
								<?php
								}
								?>	
							</table></div>
						
					</td>
				</tr>
				
			
	<tr bgcolor="#CCCCCC" height="5pt;">
		<td  colspan="11" align="right" class="SubHeading">&nbsp;
			<?php echo $pagination ;?>
		</td>
	</tr>
</table>
</td></tr></table>
<script type="text/javascript">
	document.getElementById("divsupermain").scrollTop = <?php echo $yscrollpostion  ?> 
	document.getElementById("tdmain").scrollTop = <?php echo $externalscrollpostion  ?>

</script>
