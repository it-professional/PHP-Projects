<?php
session_start();
include("checksession.php");
$message = "" ;
// For To Delte The Picture
include("include/config.php");
if($_POST['hdndeletepictue'] != "")
{
	$productid = $_POST['productid'] ;
	$strdeleteqry = "select * from tblproducts where iid = '$productid'";
	$deleterow = mysql_query( $strdeleteqry );
	$deleteres = mysql_fetch_array ( $deleterow );
	$path = "images/productpictures/" . $deleteres["strpicture"];
	if(file_exists($path))
	{
			$delete = unlink($path) ;
			$q = "UPDATE tblproducts SET strpicture = '' WHERE iid = '$productid'";
			$recordSet = mysql_query ($q);
			$message  = "Picture Has Been Deleted" ;
	}
	else
	{
		$message = "No Picture of this name found" ;
	}
}
if(isset($_POST['productname']))
{
include("include/config.php");
$productid = $_POST['productid'] ;
$productname = $_POST['productname'] ;
$productprice = $_POST['productprice'] ;
$other = $_POST['other'] ;
$otherdescription = $_POST['otherdescription'] ;
$characteristics = $_POST['hdncharacter'] ;
$attributes = $_POST['hdnatribut'] ;
$characterlength = $_POST['hdnlength'] ;
//$attributelength =  $_GET['attributelength'] ;
$picture = $_FILES['picture']['name'] ;
$date = date("y-m-d");
$userid = $_SESSION['userid'] ;
$nquery = 'false' ;

/*echo $characterlength."<br>" ;
echo $characteristics."<br>" ;
echo $attributes."<br>" ;
end;
exit();*/

function deletePhoto($cid)
{
	// function for delete a photo
	$strqry = "select * from tblproducts where iid = '$cid'";
	$row = mysql_query( $strqry );
	$res = mysql_fetch_array ( $row );
	if($res["strpicture"] != "" )
	{
		$path = "images/productpictures/" . $res["strpicture"];
		if($do = unlink( $path )){
		
		//	unlink( "includes/images/".$res["image"] );
			$q = "UPDATE tblproducts SET strpicture = '' WHERE iid = '$cid'";
			$recordSet = mysql_query ($q);
		}
		return $do;		
	} else
	return 1;
}


if($_FILES['picture']['error'] <= 0)
{
	if( ($_FILES["picture"]["type"] == "image/gif" || $_FILES["picture"]["type"] == "image/jpg" || $_FILES["picture"]["type"] ==  "image/jpeg" || $_FILES["picture"]["type"] ==  "image/pjpeg" || $_FILES["picture"]["type"] ==  "image/png"))
	{
		deletePhoto($productid) ;
		
		$randomnumer = rand();	
		$strpicturename = "Product_".$randomnumer."_".$_FILES["picture"]["name"] ;			
		move_uploaded_file($_FILES["picture"]["tmp_name"],
		"images/productpictures/".$strpicturename);
		$nquery = mysql_query("update tblproducts set strproductname = '$productname' ,iproductprice = '$productprice', strother = '$other' , strotherdesc = '$otherdescription' , strpicture = '$strpicturename' where iid = '$productid'");
		$nquery = 'true' ;
	}
	else
	{
		$nquery = 'false' ;
		$msg = 1 ;
		$message = "Only JPG and GIF images are Allowed" ;
	?>
		<script language="JavaScript">
		window.opener.location.href = window.opener.location.href ;
		</script>
	<?php	
	}
}
else
{	
	$nquery = mysql_query("update tblproducts set strproductname = '$productname' ,iproductprice = '$productprice',strother = '$other' , strotherdesc = '$otherdescription' where iid = '$productid'");
	$nquery = 'true' ;
}

if($nquery == 'true')
{
$query3 = mysql_query("select iid from tblproductfeatures where ipid = '$productid' order by iid asc");
$data = mysql_fetch_array($query3);
$iid = $data['iid'] ;
$character = explode("," , $characteristics) ;
$attribute = explode("," , $attributes) ;
while($characterlength >= 0)
{
	$chat = $character[$characterlength] ;
	$atr = 	$attribute[$characterlength] ;
	
	$query2 = mysql_query("update tblproductfeatures set icharid = '$chat' , iatrid = '$atr' where iid = '$iid'");
	$characterlength-- ;
	$iid++ ;
}	
$message = "Record is updated successfully." ;
?>
<script language="javascript">
//this.window.close();
	//window.opener.location.href = 'main.php?pg=selleraccount.php' ;
	window.opener.location.href = window.opener.location.href ;
</script>
<?php
}
else
{
	//$message = "There is some error to update this product" ;
?>
<script language="javascript">
//var msg = "There is some error to update this product" ;
//window.location.href = "editproduct.php?PID=<?php echo $productid ;?>&message="+msg ;
window.opener.location.href = window.opener.location.href ;
</script>
<?php

}
}
?>


<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<script language="javascript" type="text/javascript" src="include/js/jcap.js"></script>
<script language="javascript" type="text/javascript" src="include/js/md5.js"></script>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function deletenewproductpicture(ival)
{
	if ( ! confirm("Are you sure you want to delete this Picture ?") )
	{							
			return false;
	}
	else
	{	
			document.getElementById("hdndeletepictue").value = "DeletePicture" ;
			document.deletepicture.submit();
			//window.location.href= "deleteproductpic.php?id="+ival ;	
	}		
}


function closewindow()
{
this.window.close();
//window.location.href = "mian.php?pg=selleraccount.php"
}		
</script>		
<table cellpadding="0" cellspacing="0" border="0" width="100%" >
<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onclick="javascript: goback('selleraccount.php');" colspan="5">Go Back
</td>
</tr>
<?php
include("include/config.php");
$query = mysql_query("select * from tblproducts where iid = '".$_GET['PID']."'");
while($data = mysql_fetch_array($query))
{
	$productid = $data['iid'];
	$productname = $data['strproductname'] ;
	$productprice = $data['iproductprice'] ;
	$other = $data['strother'];
	$otherdesc = $data['strotherdesc'];
	$picture = $data['strpicture'];	
}

?>
 <tr>
		<td colspan="2" width="100%"  align="left" bgcolor="#CCCCCC" class="Heading"><font face="verdana" size="+1" color="#000000"><b>Edit <?php echo $productname; ?></b></font></td>
</tr>
<?php if($message != "") {?>
 <tr>
		<td colspan="2" width="100%"  align="center" class="redlink"><b><?php echo $message ; ?></b></td>
</tr>
<?php } ?>

</table>
<table cellpadding="0" cellspacing="0" border="0" style="padding-top:12px;" >
<form name="editproduct" action="main.php?pg=editproduct.php&PID=<?php echo $_GET['PID']?>" method="post" enctype="multipart/form-data" onSubmit="return editedproduct()">
<tr>
	<td class="Heading">
		Product Name:
	</td>
	<td style="padding-top:8px;">
		<input type="text" class="SubHeading" name="productname" size="30" id="productname" value="<?php echo $productname; ?>" />
		<input type="hidden" name="productid" id="productid" value="<?php echo $_GET['PID'] ;?>" />
</tr>
<tr>
	<td class="Heading">
		Product Price:
	</td>
	<td style="padding-top:8px;" class="SubHeading">
		$<input type="text" class="SubHeading" name="productprice" size="28" id="productprice" value="<?php echo $productprice; ?>" />.00
		
</tr>
<tr><td>&nbsp;</td></tr>
 <tr>
		<td colspan="2"  align="center"  class="SubHeading"><font  class="SubHeading" size="+1" color="#000000"><b>Characteristics </b></font></td>
</tr>


<?php
$query2 = mysql_query("select * from tblproductfeatures where ipid = '".$_GET['PID']."' order by iid asc");
while($data2 = mysql_fetch_array($query2))
{
	$characteristicid = $data2['icharid'] ;
	$attributeid = $data2['iatrid'] ;
	
	$query3 = mysql_query("select * from tblproductcharacteristics where ipchid = '$characteristicid'  order by ipchid asc");
	while($data = mysql_fetch_array($query3))
	{
		$characteristics = $data['strcharacteristicsname'] ;
	?>
	<tr>
		<td class="Heading">
		 <?php echo $characteristics ?>:
		 <input type="hidden"  id="hdncharacteristic" name="hdncharacteristic" value="<?php echo $characteristicid ; ?>" >
		</td>
	
<?php	
	$query4 = mysql_query("select * from tblproductattributes where iid = '$attributeid' ");
	while($data2 = mysql_fetch_array($query4))
	{
		
		$attribute = $data2['strattribute'] ;	
	?>
		<td  class="SubHeading" style="padding-top:8px;">
			<select name="attributes" id="attributes" class="SubHeading" style="width:162px;">
			<?php
				$query5 = mysql_query("select * from tblproductattributes where ipchid = '$characteristicid' ");
					while($data5 = mysql_fetch_array($query5))
					{
						$iaid = $data5['iid'] ;
						$attributevalue = $data5['strattribute'] ;
			?>
				
				<option value="<?php echo $iaid ;?>" <?php if($attributevalue == $attribute) { ?> selected="selected" <?php }?> ><?php echo $attributevalue ;?></option>
					<?php } ?>
			</select>
		</td>
			
	<?php
	}
	?>
	</tr>
	<?php
	}

}

?>

<tr>
	<td class="Heading">
		Other:
	</td>
	<td class="SubHeading" style="padding-top:8px;">
		<input class="SubHeading" type="text" value="<?php echo $other?>" name="other" id="other" size="30">
	</td>
</tr>
<tr>
	<td class="Heading">
		Other's Description:
	</td>
	<td class="SubHeading" style="padding-top:8px;">
	<textarea class="SubHeading" cols="30"  rows="3" name="otherdescription" id="otherdescription"><?php echo $otherdesc?></textarea>
	</td>
</tr>
<?php if($picture != '') { ?>
<tr>
<td>
</td>
<td>
<img src="images/productpictures/<?php echo $picture ;?>" border="0" width="90" height="68">
<a style="padding-left:60px;" onClick="Javascript:return deletenewproductpicture(<?php echo $productid ; ?>);"><img src="images/Delete.gif" border="0" title="click to Delete"></a>
</td>
</tr>
<?php } ?>
<tr>
<td style="padding-left:10px; padding-top:10px;"  class="Heading">
	Upload Picture:
</td>
<td style="padding-top:5px; padding-left:5px;">
	<input name="picture" id="picture"  type="file" >
</td>
</tr>


<tr><td>&nbsp;</td></tr>
<tr>
			<td align="center" colspan="2">
			<input type="hidden" name="hdncharacter" id="hdncharacter" value="">
			<input type="hidden" name="hdnatribut" id="hdnatribut" value="">
			<input type="hidden" name="hdnlength" id="hdnlength" value="">
			<input class="SubHeading" type="submit" name="submit" value=" OK " >
			<input class="SubHeading" type="button" value=" Cancel " name="cancel" onclick="closewindow()">
			</td>
</tr>

</form>
<form name="deletepicture" method="post">
<input type="hidden" name="productid" id="productid" value="<?php echo $_GET['PID'] ;?>" />
<input type="hidden" name="hdndeletepictue" id="hdndeletepictue" value="" />
</form>
</table>