<?php session_start();
include("checksession.php");
 $_SESSION["Backlink1"] = "soldproducts.php"  ;
 ?>
<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<table width="100%" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td colspan="2" class="Heading" align="left">
			<h4 class="Heading">Sold Products</h4>
		</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td height="10" bgcolor="#999999" align="right" colspan="5">&nbsp;
					
					</td>
				</tr>
				<tr bgcolor="#CCCCCC">
				<td class="SubHeading"  align="left" width="18%"><b>Action</b></td>
					<td class="SubHeading" width="15%"><b>Name</b></td>
					<td class="SubHeading" width="45%"><b>Description</b></td>
					<td class="SubHeading" align="center" width="10%"><b>Date</b></td>						
					
				</tr>
	
		<?php
		include("include/config.php");
	
	//	$temp = 0;
		
		$query = mysql_query("SELECT * FROM tblboughtproducts WHERE isellerid = '".$_SESSION['loginid']."' and istatus = 1");		
		$rows = mysql_num_rows($query);
		if($rows > 0)
		{
			while($bought = mysql_fetch_array($query))
			{
				$boughtid = $bought['iid'];
				$prodid =  $bought['ipid'];
				$buyer =  $bought['ibuyerid'];
				$date =  $bought['ddate'];
				
				$query2 = mysql_query("select * from tblproducts where iid = '$prodid'  order by iid asc ");
				
				$rows2 = mysql_num_rows($query2);
				if($rows2 >0)
				{
					
					$data = mysql_fetch_array($query2)
					
					?>
					
					<?php	
						$iid = $data['iid'] ;
						$strproductname = $data['strproductname'] ;
						$productdescriptions = $data['strotherdesc'];
						$date = $data['dtdate'];
						$productownerid = $data['iuid'];
						
						
						if(strlen($productdescriptions)>=100)
						{
							if(!function_exists('str_split')) 
							{ 
								$productdescription = str_split1($productdescriptions,100);
							}
							else
							{
								$productdescription = str_split($productdescriptions,100);
							}	
						}	
						
			
					
		?>
		<tr>
		
		<td align="left" width="18%" valign="top">
				<table >
				<tr>
																
	<td><a class="bluelink" onClick="viewbuyermessages(<?php echo $iid ;?>,<?php echo $buyer ;?>)"><img src="images/message.jpg" border="0" title="click to View Messages"></a>
	<!--<a class="bluelink" onClick="viewsoldproduct(<?php // echo $boughtid ; ?>,'soldproducts.php');"><img src="images/view.jpg" border="0" title="click to View"></a>-->
	<a class="bluelink" onClick="viewproduct(<?php echo $iid ; ?>);"><img src="images/view.jpg" border="0" title="click to View"></a>
	
				<?php 
						//$mediationquery = mysql_query("SELECT * FROM tblmediation where imediatorid = '".$_SESSION['loginid']."' AND ipid = '$prodid'");
						$mediationquery = mysql_query("SELECT * FROM tblmediation where ipid = '$prodid'");
						$mediatorrows = mysql_num_rows($mediationquery);
						if($mediatorrows > 0)
						{
							$mediationdata = mysql_fetch_array($mediationquery);
							$iid =  $mediationdata['iid'] ;
							$ipid = $mediationdata['ipid'] ;
							$mediator = $mediationdata['imediatorid'] ;
							
						//	$query21 = mysql_query("SELECT distinct ifromuid FROM tblmediationmessages WHERE ipid  = '$ipid' and itouid = '$mediator'");
						//	$data21 = mysql_fetch_array($query21);
						//	$productownerid = $data21['ifromuid'] ;
				?>
				<a class="bluelink" onClick="javascript: alert('Mediation against this product already started');"><img src="images/mediation.jpg" border="0" width="35" height="30" title="click for Mediation"></a>
				<a class="bluelink" onClick="viewmediation(<?php echo $iid ; ?>,<?php echo $buyer ;?>);"><img src="images/viewmediation.jpg" border="0" width="35" height="30" title="click to view Mediation"></a>
				<?php } else  { ?>
				<a class="bluelink" onClick="mediationconfirmation(<?php echo $boughtid ; ?>,'soldproducts.php');"><img src="images/mediation.jpg" border="0" width="35" height="30" title="click for Mediation"></a>
				<?php } ?>
				
				<?php
					$ratingfrom = $_SESSION['loginid'] ;
					 $chkratingquery = mysql_query("SELECT * FROM tblrating Where iratingfrom = '$ratingfrom' AND iratingto = '$buyer'");
					$chkrows = mysql_num_rows($chkratingquery);
					if($chkrows > 0)
					{
					?>
					<a class="bluelink" onClick="javascript: alert('You Already Rated this Buyer');"><img src="images/rating.jpg" border="0" width="30" height="30" title="click To Give Rating"></a>	
	<?php } else { ?>	
				<a class="bluelink" onClick="giverating(<?php echo $boughtid ; ?>);"><img src="images/rating.jpg" border="0" width="30" height="30" title="click To Give Rating"></a>	
				<?php }?>
																</td>		
															</tr>
														</table>
			</td>
			
			<td class="SubHeading" width="15%" valign="top">
				<?php echo $strproductname ; ?>
			</td>
			<td class="SubHeading" align="left" width="45%" valign="top">
				<?php 
				if(strlen($productdescriptions)>=100)
				{
					 echo $productdescription[0]."&nbsp;...... " ;
				}
				else
				{	
					 echo $productdescriptions ;
				}				
				?>
			</td>
			
			
			<td class="SubHeading" align="center" width="10%" valign="top">
				<?php echo $date ; ?>
			</td>
			
		</tr>		
		<?php			
				//}
			}
			}
			?>
			
			<?php
			}
			else
			{
		?>
			<tr>
				<td colspan="11" class="SubHeading">
					No Product is sold.
				</td>
			</tr>
		<?php } ?>
		<tr bgcolor="#CCCCCC" height="5pt;">
						<td colspan="5" align="right" class="SubHeading">
							<?php echo($pagination); ?>																	
						</td>
					</tr>
		</table>
		</td>
	</tr>		
			
	
</table>
