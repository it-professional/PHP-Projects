<?php 
session_start();
include("checksession.php");

?>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table cellpadding="0" cellspacing="0" border="0" width="99%" >
<?php if($_GET['blink'] != '')  { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2"  onclick="javascript: goback('<?php echo $_GET['blink'].".php" ; ?>');" colspan="5">Go Back
</td>
</tr>
<?php } ?>
<?php
include("include/config.php");
include("include/configvariables.php");
$commissionid = $_GET['commissionid'] ;
$query = mysql_query("select * from tblcommission where iid = '$commissionid' ");
$bought = mysql_fetch_array($query) ;

	$id = $bought['iid'];
	$prodid =  $bought['ipid'];
	$sellerid =  $bought['isellerid'];
	$getproductamount = $bought['iproductamount'];
	$getcommisison = $bought['icommission'];
	$date =  $bought['ddate'];
	$duedate = $bought['dduedate'];
	$status = $bought['istatus'];
	
	if($status == 0)
	{
		$status2 = "Not Paid" ;
	}
	else
	{
		$status2 = "Paid" ;
	}
	
	$productamount = number_format($getproductamount,'2') ;
	$commisison = number_format($getcommisison,2);
	
	$query2 = mysql_query("select * from tblproducts where iid = '$prodid'  order by iid asc ");
	$rows2 = mysql_num_rows($query2);
	$data2 = mysql_fetch_array($query2);
	$strproductname = $data2['strproductname'] ;	
	
	$mailquery = mysql_query("select stremail,strnickname from tblmember where iid = '$sellerid'");
	$maildata = mysql_fetch_array($mailquery);
	$selleremailid = $maildata['stremail'] ;
	$ownernick = $maildata['strnickname'] ;
	
?>
 <tr>
		<td colspan="2" width="100%"  align="left" bgcolor="#CCCCCC" class="Heading"><font face="verdana" size="2" color="#000000"><?php echo $productname; ?>&nbsp;Commission Detail</font></td>
</tr>

 <tr>
	<td class="Heading">
		Seller:
	</td>
	<td class="SubHeading" align="left">
	<?php echo $ownernick?>
	</td>
</tr>
<tr>
	<td class="Heading">
		Product Name:
	</td>
	<td class="SubHeading" align="left">
	<?php echo $strproductname?>
	</td>
</tr>
<tr>
	<td class="Heading">
		Product Amount:
	</td>
	<td class="SubHeading" align="left">
	<?php echo "$".$productamount ; ?>
	</td>
</tr>
<tr>
	<td class="Heading">
		Commission:
	</td>
	<td class="SubHeading" align="left">
	<?php echo "$".$commisison ; ?>
	</td>
</tr>
<tr>
	<td class="Heading">
		Product Sold Date:
	</td>
	<td class="SubHeading" align="left">
	<?php echo $date?>
	</td>
</tr>
<tr>
	<td class="Heading">
		Due Date:
	</td>
	<td class="SubHeading" align="left">
	<?php echo $duedate ;?>
	</td>
</tr>
<tr>
	<td class="Heading">
		Status:
	</td>
	<td class="SubHeading" align="left">
	<?php echo $status2 ;?>
	</td>
</tr>

<tr><td>&nbsp;</td></tr>
<tr>
	<td colspan="2" align="center">


<!--Paypal Transaction Form-->

<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="<?php echo $global_owneremailid_forpaypal ;?>">
<input type="hidden" name="lc" value="US">
<input type="hidden" name="button_subtype" value="products">
<input type="hidden" name="cn" value="Add special instructions to the seller">
<input type="hidden" name="no_shipping" value="2">
<input type="hidden" name="rm" value="1">
<input type="hidden" name="return" value= "http://localhost/aamirwork/ebay site/v 0.9/success2.php" >
<input type="hidden" name="cancel_return" value="http://localhost/aamirwork/ebay site/v 0.9/error2.php">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="item_name" value="<?php echo $strproductname ;?>"/>
<input type="hidden" name="item_number" value="<?php echo $id ; ?>">
<input type="hidden" name="amount" value="<?php echo $commisison ; ?>"/>
<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynowCC_LG.gif:NonHosted">
<input type="hidden" name="quantity" value="1"/>
<input type="image" src="images/pay.jpg" border="0" name="submit" alt="Pay Button">
</form>
				
</td>
</tr>
</table>