<?php session_start() ;
include("checksession.php");
$pd = $_GET['PID'] ;
$_SESSION['Backlink'] = "viewproduct.php?PID=$pd" ;
include("include/config.php");
?>
<title>Report Abuses</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="include/editor/wysiwyg.js"></script>

<?php
$strmessage = "" ;
if(isset($_POST['postmessage']) && $_POST['postmessage'] != "")
{
	$abusemessage = $_POST['postmessage'] ;
	$abusefrom = $_SESSION['loginid'] ;
	$productid = $_POST['hdnprodid'] ;
	$today = date("Y-m-d");
	
	$query = mysql_query("select strproductname from tblproducts where iid = '$productid'");
	$data = mysql_fetch_array($query) ;
	$productname = $data['strproductname'] ;
	
	$userquery = mysql_query("select strnickname from tblmember where iid = '$abusefrom'");
	$userdata = mysql_fetch_array($userquery);
	$abusefromnick = $userdata['strnickname'] ;	

	$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
	$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
	$strHTML .= "<b>Product Name : </b>".$productname."<br>";
	$strHTML .= "<b>Abuse From : </b>".$abusefromnick."<br>";		
	$strHTML .= "<b>Abuse Message : </b>".$abusemessage. "<br>";
	$strHTML .= "</td></tr></table>";
	
	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: PickmeFriend.com";
	
	$insertionquery = mysql_query("INSERT INTO tblreportabuses(ipid,ifromid,strmessage,ddate) VALUES('$productid','$abusefrom','$abusemessage','$today')");
	if($insertionquery)
	{
		$email = mail("reportabuse@pickmefriend.com","Report Abuse Message",$strHTML,$headers);
		$strmessage = "Your Report has been submitted successfully" ;
	
	?>
	<script language="javascript">
		window.location.href = "main.php?pg=viewproduct.php&PID=<?php echo $productid ;?>" ;
	</script>
	<?php
	}
	else
	{
		$strmessage = "There is some error to Submit your Report" ;
	?>
	<script language="javascript">
		window.location.href = "main.php?pg=reportabuse.php&PID=<?php echo $productid ;?>" ;
	</script>
	<?php	
	}
}
?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">

<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_SESSION['Backlink'] ;?>');"  colspan="5">Go Back
</td>
</tr>

<?php
	 if($strmessage != "") 
	 {
	 ?>
	 	<tr>
			<td class="redlink" align="center">
				<?php echo $strmessage ;?>
			</td>
		</tr>
		<tr><td>&nbsp;</td></tr>
	 <?php
	 }
?>
<?php

$reportabuser = $_SESSION['loginid'] ;
$reportquery = mysql_query("SELECT * FROM tblreportabuses WHERE ifromid = '$reportabuser' AND ipid = '".$_GET['PID']."'");
$abuserows = mysql_num_rows($reportquery);
if($abuserows > 0) 
{
	while($abusedata = mysql_fetch_array($reportquery))
	{
		$productid = $abusedata['ipid'] ;
		$fromid =$abusedata['ifromid'] ;
		$reportmessage = $abusedata['strmessage'] ;
		$posteddate = $abusedata['ddate'] ;
		
		$query = mysql_query("select iuid from tblproducts where iid = '$productid'");
		$data = mysql_fetch_array($query);
		$productowner = $data['iuid'];
		
		$userquery = mysql_query("select strnickname from tblmember where iid = '$productowner'");
		$userdata = mysql_fetch_array($userquery);
		$ownernick = $userdata['strnickname'] ;	
		
		$userquery2 = mysql_query("select strnickname from tblmember where iid = '$fromid'");
		$userdata2 = mysql_fetch_array($userquery2);
		$fromnick = $userdata2['strnickname'] ;	
?>
<tr>
<td class="SubHeading">
	<span class="Heading">From :</span> <?php echo $fromnick  ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">To :</span> <?php echo $ownernick ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Posted On : </span> <?php echo $posteddate ;?>
</td>
</tr>
<tr>
<td class="SubHeading">
	<span class="Heading">Message:</span> 
</td>
</tr>
<tr>
<td class="SubHeading">
<?php echo $reportmessage ; ?> 
</td>
</tr>

<tr><td align="center"><hr width="60%" /></td></tr>

<?php
}
?>
<tr><td>&nbsp;</td></tr>
<?php
 }?>




<tr>
	<td class="Heading">
		Description
	</td>
</tr>

<form name="reportabuse" action="reportabuse.php"  method="post">
<tr>
	<td>
		
		  <textarea id="postmessage" name="postmessage" ></textarea>
			<script language="javascript">
				generate_wysiwyg('postmessage');
			</script>
	</td>
</tr>
<tr>
	<td>

		
		<input type="hidden" name="hdnprodid" value="<?php echo $_GET['PID']?>" />
		<input type="submit" name="submit" value=" Submit " />
	</td>
</tr>
</form>



</table>