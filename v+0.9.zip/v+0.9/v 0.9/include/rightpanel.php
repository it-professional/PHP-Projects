<?php
$strregistrationmessage = "" ;
if(isset($_GET['registrationmessage']) && $_GET['registrationmessage'] != "")
{
	$getregistrationmessage = $_GET['registrationmessage'] ;
	
	if($getregistrationmessage == 1)
	{
		$strregistrationmessage =  "Email Address of this name already exists." ;
	}
	if($getregistrationmessage == 2)
	{
		$strregistrationmessage = "Nick of this name already exists." ;
	}
	
}

?>

<table border="0" width="100%"  style=" border-color:#C2C4C8;" cellpadding="0" cellspacing="0">
	
	<tr>
		<td>
			<table border="1" width="100%" style=" border-color:#C2C4C8;" cellpadding="0" cellspacing="0">
				<tr>
					<td bgcolor="#B7C6FF" style="width:231px; height:31px;" class="Heading" align="center">
						Register For Free 
					</td>
				</tr>
				<tr>
					<td valign="top" bgcolor="#DBE2FF" style="width:275px; height:255px" class="content">
				
						
						<?php 
						if(!isset($_GET['step']))
						{
						?>
							
							<form name="registerform"  action="functions.php" method="post">
								<table border="0" cellpadding="0" cellspacing="0" width="100%">
								<?php if($strregistrationmessage != "" ) {?>
								<tr>
									<td class="redlink" align="center" colspan="2">
										<?php echo $strregistrationmessage ;?>
									</td>
								</tr>
								<?php }?>
								
								<tr>
									<td class="SubHeading" style="padding-top:3px;">*Nick :
									</td>
									<td  style="padding-top:3px;">
									<input  type="text" id="nick" name="nick" size="18" />
									</td>
								</tr>
								
								
								<tr>
									<td  class="SubHeading" style="padding-top:3px;">*Email Address:
									</td>
									<td  style="padding-top:3px;">
									<input  type="text" id="email" name="email" size="18" />
									</td>
								</tr>
								<tr>
									<td  class="SubHeading" style="padding-top:3px;">*Country:
									</td>
									<td  style="padding-top:3px;">
										<select name="country" id="country" style="width:133px;">
										<?php 
											$countryquery = mysql_query("SELECT * FROM tblcountries order by id");
											while($countrydata = mysql_fetch_array($countryquery))
											{
												$strcountry = $countrydata['country_name'] ;
										?>
										<option value="<?php echo $strcountry?>"><?php echo $strcountry ;?></option>
										<?php }?>
										</select>
								</td>
								</tr>
								
								
								<tr>
									<td class="SubHeading" style="padding-top:3px;">*Native Language:		
									</td>
									<td  style="padding-top:3px;">							
									<select name="nlang" id="nlang" style="width:133px;">
										<?php 
											$languagequery = mysql_query("SELECT * FROM tbllanguages order by iid");
											while($languagedata = mysql_fetch_array($languagequery))
											{
												$strnativelanguage = $languagedata['language_name'] ;
										?>
										<option value="<?php echo $strnativelanguage?>" <?php if($strnativelanguage == "English") { ?> selected="selected" <?php }?>><?php echo $strnativelanguage ;?></option>
										<?php }?>
										</select>
									</td>
								</tr>
								
								
								<tr>
									<td  class="SubHeading" style="padding-top:3px;">*Social Network:
									</td>
									<td  style="padding-top:3px;">
									<select id="socialnetwork" name="socialnetwork"  style="width:133px;" >
											<option value="facebook">Face Book</option>
											<option value="myspace">My Space</option>
											<option value="twitter">Twitter</option>
											<option value="youtube">You Tube</option>
											<option value="google">Google</option>
											<option value="yahoo">Yahoo</option>
											<option value="squidoo">Squidoo</option>
											<option value="bloglines">Bloglines</option>
											<option value="google">other</option>
											
										</select>
									</td>
								</tr>
								
								
								<tr>
									<td>&nbsp;</td>
									<td class="content" align="left" style="padding-top:3px;">
										<div class="captcha">
											<script language="javascript" type="text/javascript">
												cimg() ;
											</script>
											<noscript>[This resource requires a Javascript enabled browser.]</noscript>
										</div>
									</td>
								</tr>
								<tr>
									<td   class="SubHeading" style="padding-top:3px;">
										*Verify Code:
										</td>
									<td  style="padding-top:3px;">
										<input name="uword" id="uword" size="18" maxlength="18"  type="text" />
									</td>
								</tr>
								
													
								
								
								<tr>
								<td  align="center" colspan="2" style="padding-top:10px;" bgcolor="">
								<input type="hidden" name="action" value="HomeSignup" />
								<?php if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') { ?>
								<input type="submit" name="submit" value=" Register " class="Heading"  onclick="return signuprequired()" />
								<?php } else { ?>
								<input type="submit" name="submit" value=" Register " class="Heading"  onclick="return alreadysignin()" />
								<?php } ?>
								<!--<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">-->
								</td>
								</tr>
								
						
							</table></form>	
							<?php }
         						  if(isset($_GET['step']) && $_GET['step'] == 'abc2def')	
								  {
							?>
							<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
							<td class="SubHeading">
								You have Successfully Registered. To Confirm Your Registration. Plese Check your E-mail.
							</td>
							</tr></table>
							<?php
								}
								if(isset($_GET['step']) && $_GET['step'] == 'abc3def')
								{
									$iid = $_GET['temp'] ;
									$chkquery = mysql_query("Select strphase From tblmember_temp Where strtemppassword = '$iid'");
									$chkrows = mysql_num_rows($chkquery);
									if($chkrows > 0)
									{
										$chkdata = mysql_fetch_array($chkquery);
										$chkphase = $chkdata['strphase'] ;
										if($chkphase == "false" || $chkphase == "NULL" || $chkphase == "")
										{	
								?>
								<form name="registerform3" action="functions.php" method="post">
								<table border="0" cellpadding="0" cellspacing="0" width="100%">
								<tr>
									<td colspan="2" class="SubHeading" style="padding:10px;" > Please enter your permanent <br /> password below. that will be used <br />when you Login. </td>
								</tr>
								
								
								<tr><td>&nbsp;</td></tr>
								
								
								<tr>
									<td class="SubHeading" style="padding-left:5px;">*Password</td>
									<td>
										<input  type="password" name="password" size="20" />
									</td>
								</tr>
								<tr>
									<td class="SubHeading" style="padding-left:5px;" >*Confirm Password</td>
									<td style="padding-top:8px;">
										<input  type="password" name="cpassword" size="20" />
									
									</td>
								</tr>
								<tr><td>&nbsp;</td></tr>
								<tr>
									<td colspan="2" style="padding-left:10px; padding-top:20px;" align="center">
										<input type="hidden" name="action" value="Password" />
										<?php if(isset($_GET['action2']) && $_GET['action2'] != "") { ?>
										<input type="hidden" name="action2" value="<?php echo $_GET['action2'] ;?>" />
										<?php } else { ?>
										<input type="hidden" name="action2" value="" />
										<?php } ?>
										<input type="hidden" name="hid" value="<?php echo $iid ;?>" />
											
										<input type="submit" name="submit" value=" OK " class="Heading"      onclick="return signuppasswordrequired()" />
										<!--<input type="button" name="cancel" value=" Cancel " class="Heading"  onClick="javascript: closewindow();">-->
									</td>
								</tr>
								</table></form>
								<?php }
									  else
									  {
									  ?>
									  <table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td colspan="2" class="SubHeading" style="padding:10px;" align="center"> You have already Confirm your registration.</td>
										</tr>
										<tr>
											<td colspan="2" class="SubHeading" style="padding:10px;" align="center">Now you can <a href="login.php" class="bluelink">Login</a> or again <a href="registeruser.php" class="bluelink">Register your account.</a> </td>
										</tr>
									</table>
									  <?php
									  }
								} 	
								else
								{
								?>
								<table border="0" cellpadding="0" cellspacing="0" width="100%">
									<tr>
										<td colspan="2" class="redlink" style="padding:10px;" align="center">No Registration Confirmation. </td>
									</tr>
									<tr>
										<td colspan="2" class="SubHeading" style="padding:10px;" align="center">Now you can <a href="login.php" class="bluelink">Login</a> or again <a href="registeruser.php" class="bluelink">Register your account.</a> </td>
									</tr>
								</table>
								<?php
								}
						}		
								
								
								 ?>
						
					</td>
				</tr>
			</table>
		</td>
	</tr>			

	<tr>
		<td style="padding-top:5px;">
			<table border="1" width="100%" style=" border-color:#C2C4C8;" cellpadding="0" cellspacing="0">
				<tr>
					<td bgcolor="#B7C6FF" style="width:231px; height:41px;" class="Heading" align="center">
						Latest Work
					</td>
				</tr>
				<tr>
					<td valign="top" bgcolor="#DBE2FF" style="width:223px; height:185px" class="content">
						<span class="content">
				<div id="scrollingContainer">
					<div id="scrollingContent">
				<?php 
				include("include/config.php");
				$userquery = mysql_query("select * from tblmember order by iid asc limit 10");
				while($data = mysql_fetch_array($userquery))
				{
					$iid = $data['iid'];
					$nickname = $data['strnickname'] ;
					$company = $data['strcompany'] ;
					$country = $data['strcountry'] ;
					$city = $data['strcity'] ;
					$address = $data['straddress'] ;
					$nlang = $data['strnativelang'] ;
					$socialnetwork = $data['strsocialnetwork'] ;	
					$ratingaverage = "" ;
					$rating = 0 ;
					
					$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
					$strHTML .= "<tr><td valign = top class='SubHeading' align=left colspan=3 width=100%><font size=2>";
					$strHTML .= "<b>Nick : </b>".$nickname."<br>";
					if($country != "") 
					{
						$strHTML .= "<b>Country : </b>".$country."<br>";	
					}
					if($city != "")
					{	
						$strHTML .= "<b>City : </b>".$city. "<br>";
					}
					if($company != "") 
					{
						$strHTML .= "<b>Company : </b>".$company."<br>";	
					}
					if($nlang != "") 
					{
						$strHTML .= "<b>Native Language : </b>".$nlang."<br>";	
					}
					if($socialnetwork != "") 
					{
						$strHTML .= "<b>Social Network : </b>".$socialnetwork."<br>";	
					}
					
					$ratingquery = mysql_query("select * from  tblrating where iratingto = '$iid' order by iid asc");
					$ratingrows = mysql_num_rows($ratingquery);
					if($ratingrows  > 0)
					{
						while($ratingdata = mysql_fetch_array($ratingquery))
						{
							$rating = $rating + $ratingdata['irating'] ;
							$ratingcomments = $ratingdata['strdescription'] ;
						}
						//$ratingaverage = $rating / $ratingrows ;	
						$ratingaverage2 = $rating / $ratingrows ;
						$ratingaverage = number_format($ratingaverage2,2);
						$roundratingavg = round($ratingaverage);
						if($roundratingavg == 1)	
						{
							$strrating = "Horrible" ;
							$strimage = "horrible.gif" ;
						}
						else if($roundratingavg == 2)	
						{
							$strrating = "Bad" ;
							$strimage = "bad.gif" ;
						}
						else if($roundratingavg == 3)	
						{
							$strrating = "Poor" ;
							$strimage = "poor.gif" ;
						}
						else if($roundratingavg == 4)	
						{
							$strrating = "Below Average" ;
							$strimage = "belowavg.gif" ;
						}
						else if($roundratingavg == 5)	
						{
							$strrating = "Average" ;
							$strimage = "average.gif" ;
						}
						else if($roundratingavg == 6)	
						{
							$strrating = "Above Average" ;
							$strimage = "aboveavg.gif" ;
						}
						else if($roundratingavg == 7)	
						{
							$strrating = "Good" ;
							$strimage = "good.gif" ;
						}
						else if($roundratingavg == 8)	
						{
							$strrating = "Very Good" ;
							$strimage = "vgood.gif" ;
						}
						else if($roundratingavg == 9)	
						{
							$strrating = "Superb" ;
							$strimage = "superb.gif" ;
						}
						else if($roundratingavg == 10)	
						{
							$strrating = "Excellent" ;
							$strimage = "excellent.gif" ;
						}
					}
					else
					{
							$strrating = "Not Rated" ;
							$strimage = "" ;
					}
					if($strimage != "")
					{
						$strHTML .= "<b>Average Rating: </b><img  align='absmiddle' src='images/$strimage' border='0' />".$ratingaverage." (".$strrating." )<br>";
					}
					else
					{
						$strHTML .= "<b>Average Rating: </b>".$ratingaverage." (".$strrating." )<br>";
					}	
					$strHTML .= "</td></tr></table><br><hr><br>";
					$strHTML = stripslashes($strHTML);	
					
					echo $strHTML ;
				}	
					
				?>

				</div>
			 		 </div>
						<script type="text/javascript">
							initSlidingContent('scrollingContainer',1);
						</script>
			</span>
					</td>
				</tr>
			</table>
		</td>
	</tr>				
			
	
	
	
	
</table>