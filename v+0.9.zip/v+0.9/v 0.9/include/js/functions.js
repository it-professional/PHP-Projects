function showscroll(postop){
	document.getElementById('scrollpos').value=postop;
	
	}
	function showexternalscroll(postop2){
	document.getElementById('externalscrollpos').value=postop2;
	
	}

function goback(pageurl)
{
	mainpagecontent(pageurl);
}
function 	logincontent(page)
{
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)
	{
		 alert ("Browser does not support HTTP Request")
		 return
	}
		var url= page;
		url = "main.php?pg="+page;
		xmlHttp.onreadystatechange=loginstatechanges 
		xmlHttp.open("GET",url,true)
		xmlHttp.send(null)
}
		
		function loginstatechanges() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("logincontent").innerHTML=xmlHttp.responseText ;						
			 } 
		}
		


function signuprequired()
{
	if(document.registerform.nick.value == '')
	{
		alert("Please Enter your Nick ");
		return false ;
		document.registerform.nick.focus() ;		
	}
	else if(document.registerform.email.value == '')
	{
		alert("Please Enter your Email Address");
		return false ;
		document.registerform.email.focus() ;		
	}
	
	else if (echeck(document.registerform.email.value)==false)
	{
		alert("Please enter Valid email address.");	
		return false;				
		document.registerform.email.focus();
		
	}
	else if(document.registerform.country.value == '')
	{
		alert("Please Enter your Country ");
		return false ;
		document.registerform.country.focus() ;		
	}
	else if(document.registerform.nlang.value == '')
	{
		alert("Please Enter your Native Language");
		return false ;
		document.registerform.nlang.focus() ;		
	}
	else if(document.registerform.socialnetwork.value == '')
	{
		alert("Please Select Most Used Social Network");
		return false ;
		document.registerform.socialnetwork.focus() ;		
	}
	else if(document.registerform.uword.value == '')
	{
		alert("Please Enter Verification Code");
		return false ;
		document.registerform.uword.focus() ;		
	}
	else if(!jcap())
	{
		  return false ;  
		  document.registerform.uword.focus() ;	
	}
	else
	{
		return true ;
	}
}

function alreadysignin()
{
	alert('You are already Sign in. For Registratin First Sign out.'); 
	return false ;
}

function echeck(str)
{
	var at="@"
	var dot="."
	var underscore="_"
	var lat=str.indexOf(at)
	var lstr=str.length
	var ldot=str.indexOf(dot)
	var lunderscore=str.indexOf(underscore)

	if (str.indexOf(at)==-1)
	{
	   //alert("Invalid E-mail ID")
	   return false
	}
		//check @ on start,end and its existance 
	if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr)
	{
	  //alert("Invalid E-mail ID")
	  return false
	}
			//check . on start,end and its existance		
	if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr)
	{
		return false
	}
	
	if (str.indexOf(underscore)==0 || str.indexOf(underscore)==lat-1 || str.indexOf(underscore)==lstr)
	{
		return false;
	}

	 return true					

}

function signuppasswordrequired()
{
var password = document.registerform3.password.value ;
var confirmpass = document.registerform3.cpassword.value ;

if(password == '')
{
alert("Please Enter Your Password");
return false ;
document.registerform3.password.focus();
}
else if(confirmpass == '')
{
alert("Please Confirm Your Password");
return false ;
document.registerform3.confirmpass.focus();
}

else if(confirmpass != password)
{
alert("Your Password and Confirm Password does not match.");
return false ;
document.registerform3.confirmpass.focus();
}
else
{
return true ;
}
}

function IsNumeric(strString)
   //  check for valid numeric strings	
   {
   var strValidChars = "0123456789.";
   var strChar;
   var blnResult = true;

   if (strString.length == 0) return false;

   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }
   return blnResult;
   }


function registerproducts()
{
	var productname = document.getElementById("productname").value;
	var productprice = document.getElementById("productprice").value ;
	if(productname == '')
	{
		alert("Please Enter Product Name");
		return false ;
		document.getElementById("productname").focus();
	}
	else if(productprice == '')
	{
		alert("Please Enter Product Price");
		return false ;
		document.getElementById("productprice").focus();
	}
	else if(!IsNumeric(productprice))
	{
		alert("Please Enter Numeric Product Price");
		return false ;
		document.getElementById("productprice").focus();
	}
	else
	{
		var other = document.getElementById("other").value;
		var description = document.getElementById("otherdescription").value ;
		//var imagename = document.getElementById("image").src;
		
		var characteristics = "" ;
		var attributes = "" ;
		var characterlength = document.getElementsByName('hdncharacteristic').length - 1 ; 
		var attributelength = document.getElementsByName('attributes').length - 1 ;
	
		for (i = document.getElementsByName('hdncharacteristic').length - 1; i >= 0; i--) 
		{
				characteristics = characteristics + document.getElementsByName('hdncharacteristic')[i].value + ","
				document.getElementById("hdncharacter").value = characteristics ;
		}
		for (j = document.getElementsByName('attributes').length - 1; j >= 0; j--) 
		{
				attributes = attributes + document.getElementsByName('attributes')[j].value + ","
				document.getElementById("hdnatribut").value = attributes ;
		}
		document.getElementById("hdnlength").value = characterlength ;
		
		// url = "productregistered.php?productname="+productname+"&other="+other+"&otherdescription="+description+"&characteristics="+characteristics+"&attributes="+attributes+"&characteristiclength="+characterlength+"&attributelength="+attributelength ;
		//mainpagecontent(url) ;
		
		//window.location.href = "productregistered.php?productname="+productname+"&other="+other+"&otherdescription="+description+"&characteristics="+characteristics+"&attributes="+attributes+"&characteristiclength="+characterlength+"&attributelength="+attributelength ;
		return true ;
		
	}
}


function editedproduct()
{
	var productname = document.getElementById("productname").value;
	var productprice = document.getElementById("productprice").value ;
	if(productname == '')
	{
		alert("Please Enter Product Name");
		return false ;
		document.getElementById("productname").focus();
	}
	else if(productprice == '')
	{
		alert("Please Enter Product Price");
		return false ;
		document.getElementById("productprice").focus();
	}
	else if(!IsNumeric(productprice))
	{
		alert("Please Enter Numeric Product Price");
		return false ;
		document.getElementById("productprice").focus();
	}
	else
	{
		var productid = document.getElementById("productid").value;
		var other = document.getElementById("other").value;
		var description = document.getElementById("otherdescription").value ;
		var characteristics = "" ;
		var attributes = "" ;
		var characterlength = document.getElementsByName('hdncharacteristic').length - 1 ; 
		var attributelength = document.getElementsByName('attributes').length - 1 ;
	
		for (i = document.getElementsByName('hdncharacteristic').length - 1; i >= 0; i--) 
		{
				characteristics = characteristics + document.getElementsByName('hdncharacteristic')[i].value + ","
				document.getElementById("hdncharacter").value = characteristics ;
		}
		for (j = document.getElementsByName('attributes').length - 1; j >= 0; j--) 
		{
				attributes = attributes + document.getElementsByName('attributes')[j].value + ","
				document.getElementById("hdnatribut").value =  attributes ;
		}
		
		document.getElementById("hdnlength").value = characterlength ;
	//	url = "productedited.php?productname="+productname+"&other="+other+"&otherdescription="+description+"&characteristics="+characteristics+"&attributes="+attributes+"&characteristiclength="+characterlength+"&attributelength="+attributelength+"&productid="+productid ;
	//	window.location.href = url ;
		return true ;
	}
}


function viewbuyproduct(pid , pownerid, backlink)
{
		url = "viewbuyproduct.php?productid="+pid+"&pmarkeduserid="+pownerid+"&blink="+backlink ;
		mainpagecontent(url) ;
}

function paycommission(commid,backlink)
{
		url = "paycommission.php?commissionid="+commid+"&blink="+backlink ;
		mainpagecontent(url) ;
}


function releasemoney(boughtproductid)
{
	if ( ! confirm("Are you sure you want to Release Money of this product ?") )
	{							
		return false;
	}
	else
	{
		var url= "releasemoney.php?id="+boughtproductid+"&blink=boughtproducts";
		mainpagecontent(url) ;
	}

	//xmlHttp=GetXmlHttpObject()
	//if (xmlHttp==null)
	 //{
	//	 alert ("Browser does not support HTTP Request")
	//	 return
	 //}
	//var url= "releasemoney.php?id="+boughtproductid;
	//url=url+"&sid="+Math.random()
	//xmlHttp.onreadystatechange=releasemoneystatechanged 
	//xmlHttp.open("GET",url,true)
	//xmlHttp.send(null)-->
}

function releasemoneystatechanged()
{
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
	{ 
		
		document.getElementById("tdmain").innerHTML=xmlHttp.responseText ;
		if(xmlHttp.responseText == 1){
			
			mainpagecontent("boughtproducts.php") ;
		}
		if(xmlHttp.responseText == 2)
		{
			alert("Money already released of this product.");	
		}		
	} 
}


function buyproducts()
{
	var productname = document.getElementById("productname").value;
	if(productname == '')
	{
		alert("Please Enter Product Name");
		document.getElementById("productname").focus();
	}
	else
	{
		var other = document.getElementById("other").value;
		var description = document.getElementById("otherdescription").value ;
		var characteristics = "" ;
		var attributes = "" ;
		var characterlength = document.getElementsByName('hdncharacteristic').length - 1 ; 
		var attributelength = document.getElementsByName('attributes').length - 1 ;
	
		for (i = document.getElementsByName('hdncharacteristic').length - 1; i >= 0; i--) 
		{
				characteristics = characteristics + document.getElementsByName('hdncharacteristic')[i].value + ","
		}
		for (j = document.getElementsByName('attributes').length - 1; j >= 0; j--) 
		{
				attributes = attributes + document.getElementsByName('attributes')[j].value + ","
		}
		
		url = "buyproduct.php?productname="+productname+"&other="+other+"&otherdescription="+description+"&characteristics="+characteristics+"&attributes="+attributes+"&characteristiclength="+characterlength+"&attributelength="+attributelength ;
		mainpagecontent(url) ;
	}
}

	function NewWindow(mypage,myname,w,h,scroll,resize)
		{
			w=w-50;
			var winl = (screen.width-w)/2;
			var wint = (screen.height-h)/2;
			var settings  ='height='+h+',';
			settings +='width='+w+',';
			settings +='top='+wint+',';
			settings +='left='+winl+',';
			settings +='scrollbars='+scroll+',';
			settings +='resizable='+resize;
			win=window.open(mypage,myname,settings);
			if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
		}
		
	function showhidesearch()
	{
		if(document.getElementById("tradvance").style.display == "none"){			
			document.getElementById("tradvance").style.display = "block";
		}
		else{
			document.getElementById("tradvance").style.display = "none";
		}
	}
		function editproduct(ival)
		{
			var editpageurl ="editproduct.php&PID="+ival ; 
			//mainpagecontent(editpageurl);
			window.location.href = "main.php?pg="+editpageurl ;
		}
		
		<!--function viewproduct(ival,backpagelink)		{
			//NewWindow("viewproduct.php?PID="+ival,"frmViewProperty",'400','400','Yes','Yes');		
			//var viewpageurl ="viewproduct.php?PID="+ival+"&backlink="+backpagelink ; 
			//mainpagecontent(viewpageurl);
		//}-->
		function viewproduct(ival)
		{
			var viewpageurl ="viewproduct.php?PID="+ival ; 
			mainpagecontent(viewpageurl);
		}
		function viewproductonbuy(ival)
		{
			var backscroll = document.getElementById('scrollpos').value;
			var externalbackscroll = document.getElementById('externalscrollpos').value;
			var viewpageurl ="viewproduct.php?PID="+ival+"&backscrolllink="+backscroll+"&externalbackscroll="+externalbackscroll ; 
			mainpagecontent(viewpageurl);
		}
		function viewsoldproduct(ival,backpagelink)
		{
			//NewWindow("viewproduct.php?PID="+ival,"frmViewProperty",'400','400','Yes','Yes');		
			var viewpageurl ="viewsoldproducts.php?bid="+ival+"&backlink="+backpagelink ; 
			mainpagecontent(viewpageurl);
		}
		function ratingrequired()
		{
			var rating = document.getElementById("rating").value ;
			var description = document.getElementById("ratingdescription").value ;
			var boughtid = document.getElementById("hdnboughtid").value ;
			if(rating == "")
			{
				alert("Please Select Rating Scale.");
				return false ;
				rating.focus();
			}
			else
			{
				//var pageurl = "rating.php?bid="+boughtid+"&backlink="+backlink+"&rating="+rating+"&description="+description ; 
				//mainpagecontent(pageurl);
				return true ;
			}
		}
		function giverating(ival)
		{
			var viewpageurl ="main.php?pg=rating.php&bid="+ival ; 
			//mainpagecontent(viewpageurl);
			window.location.href = viewpageurl ;
		}
		//function viewrating(prodid, backpagelink2,backpagelink1)
		//{
			//var viewpageurl ="viewrating.php?PID="+prodid+"&backlink2="+backpagelink2+"&backlink="+backpagelink1 ; 
			//mainpagecontent(viewpageurl);
		//}
		function viewrating(prodid)
		{
			var viewpageurl ="viewrating.php?PID="+prodid ; 
			mainpagecontent(viewpageurl);
		}
		
		function viewbuyerrating(boughtid, backpagelink2,backpagelink1)
		{
			var viewpageurl ="viewbuyerrating.php?bid="+boughtid+"&backlink2="+backpagelink2+"&backlink="+backpagelink1 ; 
			mainpagecontent(viewpageurl);
		}
		function GoToViewRating(raterid,ratingtoid)
		{
			var viewpageurl ="rating2.php?rid="+raterid+"&bid="+ratingtoid ; 
			mainpagecontent(viewpageurl);
		}
		function viewbuyerratingcomments(boughtid)
		{
			var viewpageurl ="viewbuyerratingcomments.php?bid="+boughtid ; 
			mainpagecontent(viewpageurl);
		}
		function viewmarkeduserratingcomments(markeduserid,pid)
		{
			var viewpageurl ="viewbuyerratingcomments.php?bid="+markeduserid+"&PID="+pid ; 
			mainpagecontent(viewpageurl);
		}
		function ViewAgainstMarkedUserRating(raterid,ratingtoid,pid)
		{
			var viewpageurl ="rating2.php?rid="+raterid+"&bid="+ratingtoid+"&PID="+pid ; 
			mainpagecontent(viewpageurl);
		}
		function viewwarnings(userid)
		{
			var viewpageurl ="viewwarnings.php?uid="+userid ; 
			mainpagecontent(viewpageurl);
		}
		function mediationconfirmation(iboughtproductid , backpagelink)
		{
		
		var confirm1 = confirm("Are you sure you want to Mediate against this product. ");
		
		if(confirm1 == true)
		{
		 
			var viewpageurl ="mediation.php?boughtproductid="+iboughtproductid+"&blink="+backpagelink ; 
			mainpagecontent(viewpageurl);
		}
			
		}
		function mediation(ival,backpagelink)
		{
			var goingpageurl = "continuemediaton.php&blink="+backpagelink+"&boughtproductid="+ival ;
			window.location.href = "main.php?pg="+goingpageurl ;
		}
		function viewmediation(mediationid,againsetuserid)
		{
			var goingpageurl = "viewmediation.php&mediationid="+mediationid+"&mediatoragainstid="+againsetuserid ;
		//	mainpagecontent(goingpageurl);
			window.location.href = "main.php?pg="+goingpageurl ;
		}
	
	
	function deleteproduct(ival)
		{
			if ( ! confirm("Are you sure you want to delete this Product ?") )
			{							
					return false;
			}
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= "deleteproduct.php?id="+ival;
			url=url+"&sid="+Math.random() ;
			xmlHttp.onreadystatechange=Unmarkedproductstatechanged ;
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
	
		}
		
function Markproduct(iid,iuid)
{
	if ( ! confirm("Are you sure you want to mark this Product ?") )
	{							
		return false;
	}		
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)
	 {
		 alert ("Browser does not support HTTP Request")
		 return
	 }
	var url= "markproduct.php?iid="+iid;
	url=url+"&sid="+Math.random() ;
	xmlHttp.onreadystatechange=markedproductstatechanged ;
	xmlHttp.open("GET",url,true)
	xmlHttp.send(null)
}		
function markedproductstatechanged() 
{ 
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
	{ 
		if(xmlHttp.responseText == 1){
			alert("Product marked successfully.");
			//document.getElementById("markedstatus").innerHTML= "Product Marked Successfully" ;
		}
		if(xmlHttp.responseText == 2){
			alert("You can not Mark this product. It is your own product.");
			//document.getElementById("markedstatus").innerHTML= "Product Marked Successfully" ;
		}
		if(xmlHttp.responseText == 0){
			alert("Product already marked.");	
			//document.getElementById("markedstatus").innerHTML= "Product already marked" ;
		}
		
	} 
}

function UnMarkproduct(iid,iuid)
{
	if ( ! confirm("Are you sure you want to Un Mark this Product ?") )
	{							
		return false;
	}		
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)
	 {
		 alert ("Browser does not support HTTP Request")
		 return
	 }
	var url= "unmarkproduct.php?iid="+iid;
	url=url+"&sid="+Math.random() ;
	xmlHttp.onreadystatechange=Unmarkedproductstatechanged ;
	xmlHttp.open("GET",url,true)
	xmlHttp.send(null)
}		
function Unmarkedproductstatechanged() 
{ 
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
	{ 
		document.getElementById("tdmain").innerHTML=xmlHttp.responseText ;						
	} 
	
	<!--if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete"){ 
		//if(xmlHttp.responseText == 1){
			//alert("Product Un Marked Successfully.");
			
		//}
		//if(xmlHttp.responseText == 0){
			//alert("Product cannot unmarked .");	
//		}
		
//	} -->
}

function markedusers(temp)
{

	//NewWindow("Markedusers.php?PID="+temp,"frmEditProperty",'600','900','Yes','No');
	var goingpageurl = "Markedusers.php?PID="+temp ;
	mainpagecontent(goingpageurl) ;
}

function sendmessage(productid,userid)
{

	NewWindow("messages.php?PID="+productid+"&UID="+userid,"Messaging",'600','400','Yes','No');
}

function viewmessages(productid)
{

	NewWindow("sellermessages.php.php?PID="+productid,"viewMessaging",'600','400','Yes','No');
}

function viewbuyermessages(productid,ibid)
{

	//NewWindow("messages.php?PID="+productid+"&bid="+ibid,"viewMessaging",'600','400','Yes','No');
	var goingpageurl = "messages.php&PID="+productid+"&bid="+ibid ;
	//mainpagecontent(goingpageurl);
	window.location.href = "main.php?pg="+goingpageurl ;
}
function viewmarkedusermessages(productid,ibid,backlink)
{

	//NewWindow("messages.php?PID="+productid+"&bid="+ibid,"viewMessaging",'600','400','Yes','No');
	var goingpageurl = "messages.php&PID="+productid+"&bid="+ibid+"&blink="+backlink ;
	//mainpagecontent(goingpageurl);
	window.location.href = "main.php?pg="+goingpageurl ;
}



function searchproduct(page)
{
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)
	 {
		 alert ("Browser does not support HTTP Request")
		 return
	 }
		var url= page;
		url=url+"&sid="+Math.random()
		xmlHttp.onreadystatechange=searchproductstatechanged 
		xmlHttp.open("GET",url,true)
		xmlHttp.send(null)
}		
function searchproductstatechanged() 
{ 
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
	{ 
		document.getElementById("seachproduct").innerHTML=xmlHttp.responseText ;						
	} 
}
function changevalue(strval)
{
	document.getElementById("hdnsearchby").value = strval;
}
function searchingproducts()
{
	//	var productname = document.getElementById("productname").value;
		var characteristics = "" ;
		var attributes = "" ;
		var strsearchtype;
		var characterlength = document.getElementsByName('hdncharacteristic').length - 1 ; 
		var attributelength = document.getElementsByName('attributes').length - 1 ;

		var strsearchtype = document.getElementById("hdnsearchby").value;
	//	if(productname == '' && strsearchtype == "name" )
	//		{
	//			alert("Please Enter Product Name");
	//			document.getElementById("productname").focus();
	//		}
	//	else
	//	{
	
			var other = document.getElementById("other").value;
			for (i = document.getElementsByName('hdncharacteristic').length - 1; i >= 0; i--) 
			{
					characteristics = characteristics + document.getElementsByName('hdncharacteristic')[i].value + ","
			}
			for (j = document.getElementsByName('attributes').length - 1; j >= 0; j--) 
			{
					attributes = attributes + document.getElementsByName('attributes')[j].value + ","
			}
				//url = "searchproduct.php?searchby="+strsearchtype+"&productname="+productname+"&other="+other+"&characteristics="+characteristics+"&attributes="+attributes+"&characteristiclength="+characterlength ;
				url = "searchproduct.php?searchby="+strsearchtype+"&other="+other+"&characteristics="+characteristics+"&attributes="+attributes+"&characteristiclength="+characterlength ;
				searchproduct(url) ;
									
	//	}
}	
function refresh1()
{
	document.getElementById("productname").value = "";
	document.getElementById("other").value = "";
	for (i = document.getElementsByName('hdncharacteristic').length - 1; i >= 0; i--) 
	{
			document.getElementsByName('hdncharacteristic')[i].value = "";
	}
	for (j = document.getElementsByName('attributes').length - 1; j >= 0; j--) 
	{
			document.getElementsByName('attributes')[j].value  = "";
	}
	searchingproducts();
}


function required()
{
	var email = document.getElementById("emailid").value ;
	var password = document.getElementById("password").value ;

	 if(document.getElementById("emailid").value == '')
	{
		alert("Please Enter your Email Address");
		return false ;
		document.getElementById("emailid").focus() ;		
	}
	
	else if(document.getElementById("password").value == '')
	{
		alert("Please Enter your Password");
		return false ;
		document.getElementById("password").focus() ;		
	}
	else
	{
		window.location.href = "loginprocess.php?email="+email+"&password="+password;
	}
	
}	

function login(loginemail , loginpassword)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= "loginprocess.php?email="+loginemail+"&password="+loginpassword;
			url=url+"?sid="+Math.random()				
			xmlHttp.onreadystatechange=loginstatechanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		function loginstatechanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdindexmain").innerHTML=xmlHttp.responseText ;						
			 } 
		}



		

function GetXmlHttpObject()
		{
		var xmlHttp=null;
		try
		 {
		 // Firefox, Opera 8.0+, Safari
		 xmlHttp=new XMLHttpRequest();
		 }
		catch (e)
		 {
		 //Internet Explorer
		 try
		  {
		  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		  }
		 catch (e)
		  {
		  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		 }
		return xmlHttp;
		}