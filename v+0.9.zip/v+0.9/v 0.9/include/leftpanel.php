<?php
//session_start();
?>

	<table  bgcolor="#B7C6FF" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td align="center" style="padding:6px;">
									<?php
 			if(isset($_SESSION['userid']) && $_SESSION['userid'] != '') 
			{
			echo "<span class = 'bluelink'>".$_SESSION['emailaddress']." <i>logged in. </i></span>" ;
			echo "<a href = 'logout.php' class='bluelink' style='padding-left:6px;' > Logout </a>" ;
			
			}
			else
			{
			?>
			
			<a href="login.php" class="bluelink" style="padding-left:6px;" >Login </a> 
			<?php } ?>
 
		</td>
	</tr>

	
	<tr>
		<td bgcolor="#4F76FF" style="padding-left:10px;" class="whiteheading">Buyers</td>
	</tr>
	<?php
		if(isset($_SESSION['userid']) && $_SESSION['userid'] != '')
		{	
	?>
	<tr>
		<td  style="padding:10px; height:100px" valign="top" class="bluelink" >
			
		<a href="editaccount.php"  class="bluelink">Edit Account</a> <br>	
		<a href="javascript: mainpagecontent('MarkedProducts.php')"  class="bluelink">Marked products</a><br>	
		<a href="javascript: mainpagecontent('boughtproducts.php')"  class="bluelink">Bought products</a><br>		
		<a href="javascript: mainpagecontent('buy.php')"  class="bluelink">I want to Buy (enter or buy the product)</a>
		</td>
	</tr>
	<?php
	}
	else
	{
	?>
	<tr>
		<td  style="padding:10px; height:100px" valign="top" class="bluelink" >
	<a href="javascript: mainpagecontent('buyesaccount.php')"  class="bluelink">My Buyer Account</a> <br>
		<a href="login.php"  class="bluelink">Buyers Articles</a> <br>
		<a href="#"  class="bluelink">Buyers Help</a> <br>
		<a href="#"  class="bluelink">Buyers FAQ</a> <br>		
		<a href="#"  class="bluelink">Search</a> <br>		
			
		</td>
	</tr>
	<?php
	}
	?>
	<tr>
		<td bgcolor="#4F76FF" style="padding-left:10px;" class="whiteheading">Sellers</td>
	</tr>
	<?php
		if(isset($_SESSION['userid']) && $_SESSION['userid'] != '')
		{	
	?>
	<tr>
		<td  style="padding:10px; height:100px;" valign="top" class="bluelink">
		<a href="javascript: mainpagecontent('selleraccount.php')" class="bluelink">Registered Products</a> <br>
		<a href="registerproduct.php"  class="bluelink">Register Product to sell</a> <br>			
		<a href="javascript: mainpagecontent('soldproducts.php')"  class="bluelink">Sold Products</a> <br>
		<a href="editaccount.php"  class="bluelink">Edit Account</a> <br>
		<a href="javascript: mainpagecontent('commission.php')"  class="bluelink">Pay Commission</a> <br>
		</td>
	</tr>
	<?php
		}
		else
		{
	?>
	<tr>
		<td  style="padding:10px; height:100px;" valign="top" class="bluelink">
		<a href="javascript: mainpagecontent('buyesaccount.php')" class="bluelink">My Seller Account</a> <br>
		<a href="#"  class="bluelink">Seller Articles</a> <br>
		<a href="#"  class="bluelink">Seller FAQ</a> <br>
		<a href="#"  class="bluelink">My Seller Help</a> <br>
		<a href="#"  class="bluelink">Search</a> <br>
		
			
		</td>
	</tr>
	<?php
		}
	?>
	
	
		
	<tr>
		<td bgcolor="#4F76FF" align="center"  class="whiteheading">Latest Work</td>
	</tr>
	<tr>
		<td  valign="top" style="height:50px;" bgcolor="#B7C6FF" class="SubHeading"> 
		
		</td>
	</tr>						
</table>