<?php

// Seller Email ID That will be used to receive Paypal transaction money after buy the product
$global_selleremailid_forpaypal = "seller_1261136919_biz@gmail.com" ;

// Site Owner Email ID That will be used to receive Paypal transaction money after Pay the Commission
$global_owneremailid_forpaypal = "admin_1261378738_biz@gmail.com" ;
$auth_token = "27au9wPHQaZ7YlZ5WHojxWIaz9bCnVaKBPCnU9XumpFQr4AnBnHodQ03Cmq" ;


function global_commissionpaid_message($commissionamount)
{
	$commissionpaidhtml = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
	$commissionpaidhtml .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
	$commissionpaidhtml .= "<b>Your Commission has been paid.</b><br><br>";
	$commissionpaidhtml .= "<b>Commission Paid: </b>".$commissionamount."<br>";
	$commissionpaidhtml .= "</td></tr></table>";
	
	return $commissionpaidhtml ;
}
?>