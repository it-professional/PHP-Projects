<?php
//session_start();
include("include/config.php");
function templateheader($strbarroot , $bleftpanel)
{

// Global Variables

//$loginmessage = "" ;
	

?>
<html>
<head>
	<title>PickmeFriend</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<!--<link rel="shortcut icon" href="http://voskysinteractive.servehttp.com/beta/images/favicon.ico" />-->
	<link href="include/css/css.css" type="text/css" rel="stylesheet" >
	<LINK HREF="include/Newsscroller/scroller.css" REL="stylesheet" TYPE="text/css">
	<SCRIPT SRC="include/Newsscroller/scroller.js"></SCRIPT>
	<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
	<script language="javascript">
		function mainpagecontent(callingpageurl)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= callingpageurl;
			var findindexof = url.indexOf("?") ;
			if(findindexof > 0)
			{
				url=url+"&sid="+Math.random() ;				
			}
			else
			{
				url=url+"?sid="+Math.random() ;
			}	
			xmlHttp.onreadystatechange=mainpagecontentstateChanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		function ExecuteJavaScript()
		{
			var arr = new Array();
			arr = document.getElementById("tdmain").getElementsByTagName("script");
			for(var i=0; i < arr.length; i++)
			{			
				eval(arr[i].innerHTML);
			}
		} 		
		function mainpagecontentstateChanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdmain").innerHTML=xmlHttp.responseText ;
				ExecuteJavaScript();						
			 } 
			 
		}
		
		
		function 	homepagecontent(page)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= page;
			if(url == 'index.php')
			{
				url = "index.php" ;
			}
			else
			{
				url = "main.php?pg="+page;				
			}
						
			xmlHttp.onreadystatechange=homepagestateChanged 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		
		function homepagestateChanged() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("tdindexmain").innerHTML=xmlHttp.responseText ;						
			 } 
		}
		
		function homepage(callingpageurl)
		{
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null)
			 {
				 alert ("Browser does not support HTTP Request")
				 return
			 }
			var url= callingpageurl;
			url=url+"?sid="+Math.random()				
			xmlHttp.onreadystatechange=mainpagecontentstateChanged2 
			xmlHttp.open("GET",url,true)
			xmlHttp.send(null)
		}
		
		function mainpagecontentstateChanged2() 
		{ 
			if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			 { 
				document.getElementById("homecontent").innerHTML=xmlHttp.responseText ;						
			 } 
		}			
	
		function GetXmlHttpObject()
		{
		var xmlHttp=null;
		try
		 {
		 // Firefox, Opera 8.0+, Safari
		 xmlHttp=new XMLHttpRequest();
		 }
		catch (e)
		 {
		 //Internet Explorer
		 try
		  {
		  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		  }
		 catch (e)
		  {
		  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		 }
		return xmlHttp;
		}
	</script>
	
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" >
<table width="100%"  border="0" cellpadding="0" cellspacing="0">
<tr>
<td id="homecontent">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<!--header-->
		  <tr>
			<td>
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr>			
						<td width="25%" align="left"><img src="images/Template-other-Page-1_02.jpg" width="454" height="85" alt=""></td>
						<td width="50%">&nbsp;</td>
						<td width="25%" align="right"><img src="images/Template-other-Page-1_03.jpg" width="494" height="85" alt=""></td>				
					</tr>
				</table>
			</td>
		  </tr>
		  
		 <tr>
			<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
			
			<td>
				<img src="images/Template-other-Page-1_04.jpg" width="100%" height="7" alt=""></td>
			<td>
				<img src="images/spacer.gif" width="1" height="7" alt=""></td>
			</tr>
			</table>
			</td>	
		</tr>
		
		<tr>
			<td width="100%">
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
			<td >
				<img src="images/Template-other-Page-1_05.jpg" width="100%" height="4" alt=""></td>
			<td>
				<img src="images/spacer.gif" width="1" height="4" alt=""></td>
			</tr>
			</table>
			</td>	
		</tr>
		
		<tr>
			<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
			
			<td>
				<img src="images/Template-other-Page-1_04.jpg" width="100%" height="7" alt=""></td>
			<td>
				<img src="images/spacer.gif" width="1" height="7" alt=""></td>
			</tr>
			</table>
			</td>	
		</tr>

		  <!--header-->
		  
		   <!--content-->
		   <?php //if($bleftpanel == 'true')  { 
		   if(isset($_SESSION['loginid']) || $_SESSION['loginid'] != '') {
		   ?>
		  <tr>
			<td colspan="3">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						
						<td width="20%" style="padding-left:5px;" valign="top" bgcolor="#B7C6FF">
						
							
							<?php include("include/leftpanel.php"); ?>
						
						</td>
						<td   valign="top" class="content">
							<input type='hidden' id='externalscrollpos'  />
							<?php 
									//  Show message if seller/user has wrong paypal id
								$loginuser = $_SESSION['loginid'] ;	
								$flagquery = mysql_query("SELECT iflag FROM tblmember WHERE iid = '$loginuser' ");
								$fragdata = mysql_fetch_array($flagquery);
								$iflag = $fragdata['iflag'] ;
								if($iflag == 1)
								{
								?>
									<table border="0" cellpadding="0" cellspacing="0" width="100%" align="center">
										<tr bgcolor="#CCFFFF">
											<td align="center" class="redlink">
												Your Paypal Email Address is not Valid. Some one want to purchase your product.
												<br>Please Correct your Paypal Email Address using <a href="editaccount.php" class="bluelink">Edit Account</a> Link													
											</td>
										</tr>
										<tr><td>&nbsp;</td></tr>
									</table>
								<?php }?>	
						<div id="tdmain" style=" width:100%; height:390px; overflow-x:hidden; overflow-y:scroll;" onscroll="showexternalscroll(this.scrollTop)">
						
				<?php } else { ?>
				<tr>
					<td>
						
					<?php } ?>
						
						
<?php } 
function templatefooter($strbarroot , $bleftpanel)
{
?>						
					 <?php //if($bleftpanel == 'true')  { 
					   if(isset($_SESSION['loginid']) || $_SESSION['loginid'] != '') {
					 
					 ?>	
						</div>
						</td>
					</tr>
				</table>
			</td>
		  </tr>
		   <!--content-->
		   <?php } else { ?>
		 </td>
		</tr> 
		<?php } ?>
		   
		  <!--footer-->
		  <tr>
			<td width="100%" valign="top" >
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td >
							<img src="images/Template-other-Page-1_68.jpg" width="100%" height="9" alt=""></td>
						<td>
							<img src="images/spacer.gif" width="1" height="9" alt="">
						</td>
					</tr>
					<tr>
						<td valign="top" >
							<img src="images/Template-other-Page-1_69.jpg" width="100%" height="3" alt=""></td>
						<td>
							<img src="images/spacer.gif" width="1" height="3" alt=""></td>
					</tr>
					
					<tr>
						<td align="center" class="bluelink">
					
							<?php if(isset($_SESSION['loginid']) || $_SESSION['loginid'] != '') {?>
							<a href="javascript: mainpagecontent('buyesaccount.php')"  class="bluelink">Register A Seller (free)</a>&nbsp;&nbsp;
							<a href="javascript: mainpagecontent('newestwork.php')"  class="bluelink">See newest work </a> &nbsp;&nbsp;
							<a href="javascript: mainpagecontent('availablework.php')"  class="bluelink">Browse availabale work</a>&nbsp;&nbsp;
							<a href="javascript: mainpagecontent('search.php')"  class="bluelink">Search for work</a>
							
							<!--<div align="right"><a style="padding-right:50px;" href="mailto:voskysinteractive.com"  class="bluelink">voskysinteractive.com</a></div>-->							<br><br>
							<?php } ?>
							<?php if(isset($_SESSION['loginid']) || $_SESSION['loginid'] != '') {?>
							<a href="index.php"  class="bluelink">Home</a> &nbsp; | 
							<a href="javascript: mainpagecontent('aboutus.php')"  class="bluelink">About Us</a> &nbsp;| 
							<a href="javascript: mainpagecontent('legal.php')"  class="bluelink">Legal </a> &nbsp; |
							<a href="contactus.php"  class="bluelink">Contact Us </a>&nbsp; | 
							<a href="javascript: mainpagecontent('termsofservices.php')"  class="bluelink">Terms of Services</a>
							<?php } else {?>
							
							<a href="index.php"  class="bluelink">Home</a> &nbsp; | 
					<a href="javascript: homepagecontent('aboutus.php')"  class="bluelink">About Us</a> &nbsp;| 
					<a href="javascript: homepagecontent('legal.php')"  class="bluelink">Legal</a> &nbsp; |
					<a href="contactus.php"  class="bluelink">Contact Us</a> &nbsp; | 
					<a href="javascript: homepagecontent('termsofservices.php')" class="bluelink">Terms of Services</a>
							<?php } ?>
						</td>
				</tr>
				</table>
			</td>
		  </tr>
		  <!--footer-->
		</table>
		
		</td>
		</tr>
		</table>

	</body>
</html>	
<?php }?>