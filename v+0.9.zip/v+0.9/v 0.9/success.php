<?php
session_start();
include("random.php");

if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
{
	include("login.php");
}
else
{		
	include("include/template.php");
	templateheader("" , "true");
	include("include/config.php");
}
// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-synch';

//$tx_token = $_GET['tx'];
$getproductid = $_GET['item_number'];
$getproductbuyerid = $_GET['x_x'] ;

$productid = decryptId($getproductid,'ABCDZYX0987654321JUI200789');
$productbuyer = decryptId($getproductbuyerid,'ABCDZYX0987654321JUI200789');

$query = mysql_query("select * from tblproducts where iid = '$productid'");
$queryrows = mysql_num_rows($query);
if($queryrows > 0)
{
	$data = mysql_fetch_array($query);
	$productname = $data['strproductname'] ;
	$amount = $data['iproductprice'] ;
	$productowner = $data['iuid'];
	//$productbuyer = $_SESSION['loginid'] ;
	
	
	
	// Check Transaction Id
	$chktransactionid = mysql_query("Select * From tblboughtproducts where ipid = '$productid' and isellerid = '$productowner' and ibuyerid = '$productbuyer'");
	$chktransactionidrows = mysql_num_rows($chktransactionid);
	if($chktransactionidrows > 0)
	{
		echo "<table align='center' width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td align='center'><b><font color='#FF0000'>This transaction has already done.</font></b></td></tr></table>" ;
	}
	
	else
	{
			//$amount = $_GET['amt'];
			//$productid = $_GET['item_number'];
			$date = date("y-m-d");
			$beforedays  = mktime(0, 0, 0, date("m")  , date("d")+5, date("Y"));
			$duedate = date("Y-m-d" , $beforedays);
		
			$query2 = mysql_query("SELECT * FROM tblproducts WHERE iid = '$productid'");
			$data = mysql_fetch_array($query2);
			$proddesc = $data['strotherdesc'] ;
			$productownerid = $data['iuid'] ;
			$itemname = $data['strproductname'];	
		
			$query1 = mysql_query("INSERT INTO tblboughtproducts (ipid,ibuyerid,isellerid,istatus,ddate) VALUES('$productid','$productbuyer','$productownerid',1,'$date')");
			if($query1)
			{
				// Update this bought product from Marked Products.	
				mysql_query("UPDATE tblmarkedproducts set bactive = 0 WHERE ipid = '$productid' AND iuid = '$productbuyer'");
				
				$mailquery2 = mysql_query("select stremail from tblmember where iid = '$productownerid'");
				$maildata2 = mysql_fetch_array($mailquery2);
				$productowneremail = $maildata2['stremail'] ;
				
				$mailquery3 = mysql_query("select stremail from tblmember where iid = '$productbuyer'");
				$maildata3 = mysql_fetch_array($mailquery3);
				$productbuyeremail = $maildata3['stremail'] ;
				
				$headers = "MIME-Version: 1.0\r\n";  
				$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
				$headers .= "From: PickmeFriend.com";
				
				$strHTML = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
				$strHTML .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
				$strHTML .= "<b>Your transaction has been completed</b><br><br>";
				$strHTML .= "<b>Payment Details</b><br>";
				$strHTML .= "<b>Product: </b>".$itemname."<br>";
				$strHTML .= "<b>Amount: $</b>".$amount."<br>";
				$strHTML .= "<b>Description: </b>".$proddesc."<br><br>";
				$strHTML .= "</td></tr></table>";
					
				$strHTML = stripslashes($strHTML);	
				
				mail($productbuyeremail,"New Transaction Completed Successfully",$strHTML,$headers);
				mail($productowneremail,"New Transaction Completed Successfully",$strHTML,$headers);
				mail("successtransaction@pickmefriend.com","New Transaction Completed Successfully",$strHTML,$headers);
				
				
				$percentofproduct = ($amount/100)*10 ;
				
				$commissionquery = mysql_query("INSERT INTO tblcommission(isellerid,ipid,iproductamount,icommission,ddate,dduedate,istatus) VALUES('$productownerid','$productid','$amount','$percentofproduct','$date','$duedate','0')");
				if($commissionquery)
				{
					$headers2 = "MIME-Version: 1.0\r\n";  
					$headers2 .= "Content-type: text/html; charset=iso-8859-1\r\n";
					$headers2 .= "From: PickmeFriend.com";
					
					$strHTML2 = "<table border=0 cellpadding=0 cellspacing=0 width= 100% valign = Top>";		
					$strHTML2 .= "<tr><td valign = top align=left colspan=3 width=100%><font size=2>";
					$strHTML2 .= "<b>Your transaction has been completed. As per your agreement with the PickmeFriend.com you have to pay the 10% to the site.</b><br><br>";
					$strHTML2 .= "<b>Payment Details</b><br>";
					$strHTML2 .= "<b>Product: </b>".$itemname."<br>";
					$strHTML2 .= "<b>Amount: $</b>".$amount."<br>";
					$strHTML2 .= "<b>10% of Amount: $</b>".$percentofproduct."<br><br>";
					$strHTML2 .= "<b>Commission you owe: $".$percentofproduct."</b><br><br>";
					$strHTML2 .= "<b>Due Date :".$duedate."</b><br><br>";
					$strHTML2 .= "<b>After Due Date you will be banned to the site and all of the serives will be terminated.</b><br><br>";
					$strHTML2 .= "</td></tr></table>";
										
					mail($productowneremail,"Remember Transaction Completed Agreement.",$strHTML2,$headers2);
				}	
		
				?>
				<script language="javascript">
					window.location.href = "main.php?pg=boughtproducts.php" ;
				</script>
				<?php
			}
			else
			{	
				echo ("<p align='center' style='width:100%'><h3><font color='#FF0000'>There is some error to complete your transaction.</font></h3></p>");
			}
		
		}
}		
else
{
echo "<table align='center' width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td align='center'><b><font color='#FF0000'>No Transaction done. First Buy the product.</font></b></td></tr></table>" ;
}		
	

?>


<?php
templatefooter("" , "true");
?>