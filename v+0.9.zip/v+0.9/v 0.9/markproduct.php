<?php
session_start() ;
include("checksession.php");
include("include/config.php");
$productid = $_GET['iid'] ;
$iuid = $_SESSION['loginid'] ;
$date = date("y-m-d");

$strQry = mysql_query("SELECT iuid FROM tblproducts WHERE iid = '$productid'") ;	
$getuserid = mysql_fetch_array($strQry);
$userid = $getuserid['iuid'] ;

if($userid == $iuid)
{
	echo("2");
}
else
{

	$query2 = mysql_query("select * from tblmarkedproducts where ipid = '$productid' and iuid = '$iuid' ");
	$rows = mysql_num_rows($query2);
	if($rows > 0)
	{	
		echo("0");
	}
	else
	{
		$query = mysql_query("insert into tblmarkedproducts (ipid,iuid , bactive , ddate , istatusid) values('$productid' , '$iuid' , 1 , '$date' , 1)");
		echo("1");		
	}
}	
?>