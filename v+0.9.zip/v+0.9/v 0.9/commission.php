<?php session_start(); 
include("checksession.php");
?>
<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<table width="100%" cellpadding="0" cellspacing="0" >
	<tr>
		<td colspan="2" class="Heading" align="left">
			<h4 class="Heading">Commission on Sold Products</h4>
		</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td height="10" bgcolor="#999999" align="right" colspan="11">&nbsp;
					
					</td>
				</tr>
				<tr bgcolor="#CCCCCC">
				<td class="SubHeading"  align="left" width="20%"><b>Action</b></td>
					<td class="SubHeading" width="19%"><b>Product Name</b></td>
					<td class="SubHeading" width="15%"><b>Product Amount</b></td>
					<td class="SubHeading" align="left" width="10%"><b>Commission</b></td>
					<td class="SubHeading" align="left" width="13%"><b>Sold Date</b></td>
					<td class="SubHeading" align="left" width="13%"><b>Due Date</b></td>
					<td class="SubHeading" align="left" width="15%"><b>Status</b></td>
					
				</tr>
	
		<?php
		include("include/config.php");
	
	//	$temp = 0;
		
		$query = mysql_query("SELECT * FROM tblcommission WHERE isellerid = ".$_SESSION['loginid']."");		
		$rows = mysql_num_rows($query);
		if($rows > 0)
		{
			while($bought = mysql_fetch_array($query))
			{
				$id = $bought['iid'];
				$prodid =  $bought['ipid'];
				$sellerid =  $bought['isellerid'];
				$getproductamount = $bought['iproductamount'];
				$getcommisison = $bought['icommission'];
				$date =  $bought['ddate'];
				$duedate = $bought['dduedate'];
				$status = $bought['istatus'];
				
				$productamount = number_format($getproductamount,'2') ;
				$commisison = number_format($getcommisison,2);
				
				if($status == 0)
				{
					$status2 = "Not Paid" ;
				}
				else
				{
					$status2 = "Paid" ;
				}
				
				$query2 = mysql_query("select * from tblproducts where iid = '$prodid'  order by iid asc ");
				$rows2 = mysql_num_rows($query2);
				$data2 = mysql_fetch_array($query2);
				$strproductname = $data2['strproductname'] ;	
					?>
		<tr>
		<td align="left" width="20%" valign="top">
				<table >
					<tr>
						<td>
	<?php if($status == 0) { ?>
	<a class="bluelink" onClick="paycommission(<?php echo $id ;?>,'commission')"><img src="images/commission.jpg" border="0" width="38" height="30" title="click to Pay Commision"></a>				
		<?php } else { ?>
		<a class="bluelink" onClick="javascript:alert('Commission Already Paid')"><img src="images/commission.jpg" border="0" width="38" height="30" title="click to Pay Commision"></a>
		<?php } ?>	
		</td></tr></table>	
			</td>
			
			
			<td class="SubHeading" width="19%" valign="top">
				<?php echo $strproductname ; ?>
			</td>
			<td class="SubHeading" align="center" width="15%" valign="top">
				<?php echo "$".$productamount ; ?>
			</td>
			<td class="SubHeading" align="center" width="10%" valign="top">
				<?php echo "$".$commisison ; ?>
			</td>
			<td class="SubHeading" align="left" width="13%" valign="top">
				<?php echo $date ; ?>
			</td>
			<td class="SubHeading" align="left" width="13%" valign="top">
				<?php echo $duedate ; ?>
			</td>
			<td class="SubHeading" align="left" width="15%" valign="top">
				<?php echo $status2 ; ?>
			</td>
			
		</tr>		
		<?php			
				//}
			//}
			}
			?>
			
			<?php
			}
			else
			{
		?>
			<tr>
				<td colspan="11" class="SubHeading">
					No Commission to Pay.
				</td>
			</tr>
		<?php } ?>
		<tr bgcolor="#CCCCCC" height="5pt;">
						<td colspan="11" align="right" class="SubHeading">&nbsp;
																								
						</td>
					</tr>
		</table>
		</td>
	</tr>		
			
	
</table>
