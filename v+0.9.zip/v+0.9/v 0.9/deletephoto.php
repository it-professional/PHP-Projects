<?php
session_start();
include("checksession.php");
include("include/config.php");
$iid = $_GET['id'] ;
$strqry = "select * from tblmember where iid = '$iid'";
	$row = mysql_query( $strqry );
	$res = mysql_fetch_array ( $row );
	if($res["strpicture"] != "" )
	{
		$path = "images/accountpictures/" . $res["strpicture"];
		$delete = unlink($path) ;
		if($delete)
		{
			$q = "UPDATE tblmember SET strpicture = '' WHERE iid = '$iid'";
			$recordSet = mysql_query ($q);
?>
<script language="JavaScript">
var msg = "Picture has been deleted" ;
window.location.href = "editaccount.php?message="+msg ;
</script>
<?php
			
		}	
	}
	else
	{		
?>
<script language="JavaScript">
var msg = "There is no Picture. Please First Upload the Picture" ;
window.location.href = "editaccount.php?message="+msg ;
</script>
<?php
}
?>