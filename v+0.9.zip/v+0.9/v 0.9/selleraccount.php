<?php session_start(); 
include("checksession.php");
$_SESSION["Backlink1"] = "selleraccount.php"  ;
?>
<link href="include/css/css.css" type="text/css" rel="stylesheet" >
<script language="javascript" type="text/javascript" src="include/js/functions.js"></script>
<table width="100%" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td colspan="2" class="Heading" align="left">
			<h4 class="Heading">My Products</h4>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td height="10" bgcolor="#999999" align="right" colspan="5">&nbsp;
					
					</td>
				</tr>
				<tr bgcolor="#CCCCCC">
				<td class="SubHeading"  align="left" width="15%"><b>Action</b></td>
					<td class="SubHeading" width="20%"><b> Name</b></td>
					<td class="SubHeading" width="40%"><b> Description</b></td>
					<td class="SubHeading" width="15%" ><b> Marks</b></td>
					<td class="SubHeading" align="center" width="10%"><b>Date</b></td>						
					
				</tr>
		<?php
		include("include/config.php");
		
		/* Pagination Functionality */
 /* Set current, prev and next page */
	$page = (!isset($_GET['page']))? 1 : $_GET['page']; 
	$prev = ($page - 1);
	$next = ($page + 1);
	
	/* Max results per page */
	$max_results = 20;
	
	/* Calculate the offset */
	$from = (($page * $max_results) - $max_results);
	
	
    $q = "SELECT * FROM tblproducts Where iuid = ".$_SESSION['loginid']." order by iid asc ";
	$result = mysql_query($q);
	
   /* Error occurred, return given name by default */
   $num_rows = mysql_num_rows($result);
   
  	/* Grabbing the total rows*/
   $total_results = mysql_num_rows($result);
   
   /* Counting total pages*/
   $total_pages = ceil($total_results / $max_results);
   //mysql_close($mysqlconn);
   /* Initializing the pagination*/
   $pagination = "";
   
   /* Create a PREV link if there is one */

	if($page > 1)
	{
		$pagination .= "<a href=main.php?pg=selleraccount.php&action=".$HTTP_GET_VARS["action"]."&page=".$prev.">&lt; &lt;&nbsp;Previous&nbsp;</a>";
	}
	else
	{
		$pagination .= "<label class=csstext>&lt; &lt;&nbsp;Previous&nbsp;</label>";
	}
	/* Loop through the total pages */
	for($i = 1; $i <= $total_pages; $i++)
	{
		if(($page) == $i)
		{
			$pagination .= "<label class=csstextbold>[".$i."]</label>";
		}
		else
		{
			$pagination .= "<a href=main.php?pg=selleraccount.php&action=".$HTTP_GET_VARS["action"]."&page=".$i.">&nbsp;".$i."&nbsp;</a>";
		}
	}
	
	/* Print NEXT link if there is one */
	
	if($page < $total_pages)
	{
		$pagination .= "<a href=main.php?pg=selleraccount.php&action=".$HTTP_GET_VARS["action"]."&page=".$next.">&nbsp;Next&nbsp;&gt;&gt</a>";
	}
	else
	{
		$pagination .= "<label class=csstext>&nbsp;Next&nbsp;&gt;&gt</label>";
	}
	
	

			
			$query = mysql_query("select * from tblproducts where iuid = ".$_SESSION['loginid']." order by iid asc LIMIT $from, $max_results");
			$rows = mysql_num_rows($query);
			if($rows >0)
			{
				while($data = mysql_fetch_array($query))
				{
					$iid = $data['iid'] ;
					$strproductname = $data['strproductname'] ;
					$productdescriptions = $data['strotherdesc'];
					$date = $data['dtdate'];
					
					if(strlen($productdescriptions)>=100)
					{
						if(!function_exists('str_split')) 
						{ 
							$productdescription = str_split1($productdescriptions,100);
						}
						else
						{
							$productdescription = str_split($productdescriptions,100);
						}	
					}	
					
		?>
		<tr>
		
		<td align="left" width="15%" valign="top">
				<table >
															<tr>
																<td><a class="bluelink" onClick="editproduct(<?php echo $iid ; ?>);"><img src="images/Edit.jpg" border="0" title="click to Edit"></a></td>
																<td><a class="bluelink" onClick="viewproduct(<?php echo $iid ; ?>);"><img src="images/view.jpg" border="0" title="click to View"></a></td>
																
																<td><a class="bluelink" onClick="Javascript:deleteproduct(<?php echo $iid ; ?>);"><img src="images/Delete.gif" border="0" title="click to Delete"></a></td>
																
															</tr>
														</table>
			
				
			</td>
			<td class="SubHeading" width="20%" valign="top">
				<?php echo $strproductname ; ?>
			</td>
			<td class="SubHeading" align="left" width="40%" valign="top">
				<?php 
				if(strlen($productdescriptions)>=100)
				{
					 echo $productdescription[0]."&nbsp;...... " ;
				}
				else
				{	
					 echo $productdescriptions ;
				}				
				?>
			</td>
			<td class="SubHeading" width="14%" valign="top">
				<?php
				$markquery = mysql_query("select count(*) as iid from tblmarkedproducts where ipid = '$iid' ");
				if($markquery)
				{
					$noofrows = mysql_fetch_array($markquery);
					$totalbids =  $noofrows['iid'] ;
					if($totalbids > 0)
					{
				
				?>
				<a  class="bluelink" onClick="markedusers(<?php echo $iid?>)" title="Click to View Buyers" ><?php echo $totalbids ;?></a>
				<?php } ?>
				
				<?php }?>	
			</td>
			
			<td class="SubHeading" align="center" width="10%" valign="top">
				<?php echo $date ; ?>
			</td>
			
		</tr>		
		<?php			
				}
			}
			else
			{
		?>
		<tr>
			<td colspan="11" class="SubHeading">
					There is no product. Please first register your product.
				</td>
			</tr>
		<?php } ?>
		<tr bgcolor="#CCCCCC" height="5pt;">
						<td colspan="5" align="right" class="SubHeading">
							<?php echo($pagination); ?>																	
						</td>
					</tr>
		</table>
		</td>
	</tr>		
			
	
</table>
