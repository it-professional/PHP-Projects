<?php
session_start();
include("checksession.php");
include("random.php");

?>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table cellpadding="0" cellspacing="0" border="0" width="99%" >
<?php if($_GET['blink'] != '')  { ?>
<tr>
<td height="10" bgcolor="#999999"  class="redlink2"  onclick="javascript: goback('<?php echo $_GET['blink'].".php" ; ?>');" colspan="5">Go Back
</td>
</tr>
<?php } ?>
<?php
include("include/config.php");
include("include/configvariables.php");
$productmarkeduserid = $_GET['pmarkeduserid'] ;
$query = mysql_query("select * from tblproducts where iid = ".$_GET['productid']."");
$data = mysql_fetch_array($query) ;

$productid = $data['iid'];
$productname = $data['strproductname'] ;
$productprice2 = $data['iproductprice'] ;
$productprice = number_format($productprice2,2);
$other = $data['strother'];
$otherdesc = $data['strotherdesc'];	
$picture = $data['strpicture'];	
$productownerid = $data['iuid'];

$mailquery = mysql_query("select stremail,strnickname,strpaypalemailid from tblmember where iid = '$productownerid'");
$maildata = mysql_fetch_array($mailquery);
$selleremailid = $maildata['stremail'] ;
$ownernick = $maildata['strnickname'] ;
$sellerpaypalid = $maildata['strpaypalemailid'] ;
	

?>
 <tr>
		<td colspan="2" width="100%"  align="left" bgcolor="#CCCCCC" class="Heading"><font face="verdana" size="2" color="#000000"><?php echo $productname; ?>&nbsp;Detail</font></td>
</tr>
<tr>
	<td class="SubHeading" colspan="2">
		<b>User: </b><?php echo $ownernick; ?>
	</td>
</tr>
<?php if($picture != '') { ?>
<tr>
	<td colspan="2"  align="left"  class="Heading">
		<b>Picture</b>
	</td>
</tr>
<tr>	
	<td colspan="2"  align="center"  >
	<img src="images/productpictures/<?php echo $picture ?>" border="0" width="120" height="80" />
	</td>
</tr>
<?php } ?>
 <tr>
		<td colspan="2"  align="left"  class="Heading"><b>Characteristics</b></td>
</tr>

</table>
<table cellpadding="0" width="60%" cellspacing="0" border="0" style="padding-top:12px;" >

<?php
$query2 = mysql_query("select * from tblproductfeatures where ipid = ".$_GET['productid']."");
while($data2 = mysql_fetch_array($query2))
{
	$characteristicid = $data2['icharid'] ;
	$attributeid = $data2['iatrid'] ;
	
	$query3 = mysql_query("select * from tblproductcharacteristics where ipchid = '$characteristicid'  order by ipchid asc");
	while($data = mysql_fetch_array($query3))
	{
		$characteristics = $data['strcharacteristicsname'] ;
	?>
	<tr>
		<td class="SubHeading">
		 <b><?php echo $characteristics ?>:</b>
		</td>
	
<?php	
	$query4 = mysql_query("select * from tblproductattributes where iid = '$attributeid' ");
	while($data2 = mysql_fetch_array($query4))
	{
		
		$attribute = $data2['strattribute'] ;	
	?>
		<td  class="SubHeading" align="left">
			<?php echo $attribute ;?>
		</td>
			
	<?php
	}
	?>
	</tr>
	<?php
	}

}

?>

<tr>
	<td class="Heading">
		Other:
	</td>
	<td class="SubHeading" align="left">
	<?php echo $other?>
	</td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr>
	<td class="Heading" >
		<b>Product Price:</b>
	</td>
	<td class="SubHeading">
		<?php echo "$ ".$productprice ;?>
	</td>

</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr>
	<td class="Heading" colspan="2">
		<b>Description:</b>
	</td>

</tr>
<tr>
	
		<td class="SubHeading" align="left" colspan="2">
			<?php echo $otherdesc ;?>
		</td>
	
</tr>
<tr>
<td colspan="2"><?php
/*$amount = 1000 ;
$amount2 = ($amount/100)*10 ;
 //$amount3 = $amount - $amount2 ;
echo $amount2 ;*/
?></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
	<td colspan="2" align="center">

<?php $showitemname = "PickmeFriend ".$ownernick."&nbsp;".$productname ?>
<?php
	
	 $encryptproductid = encryptId($productid,'ABCDZYX0987654321JUI200789') ;
	 $buyerid = $_SESSION['loginid'] ;
	 $sendbuyerid = encryptId($buyerid,'ABCDZYX0987654321JUI200789') ;
?>
<!--Paypal Transaction Form-->

<!--<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">-->
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="<?php echo $sellerpaypalid ;?>">
<input type="hidden" name="rm" value="2">
<input type="hidden" name="return" value= "http://pickmefriend.com/beta/success.php?item_number=<?php echo $encryptproductid ; ?>&x_x=<?php echo $sendbuyerid ;?>" >
<input type="hidden" name="cancel_return" value="http://pickmefriend.com/beta/main.php?pg=error.php&ipid=<?php echo $encryptproductid ;?>" >
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="item_name" value="<?php echo $showitemname ;?>"/>
<input type="hidden" name="item_number" value="<?php echo $productid ; ?>">
<input type="hidden" name="amount" value="<?php echo $productprice ;?>"/>
<input type="hidden" name="quantity" value="1"/>
<input type="image" src="images/buynow.gif" border="0" name="submit" alt="Buy Now Button">
</form>

</td>
</tr>
</table>