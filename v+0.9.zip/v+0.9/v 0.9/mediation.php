<?php
session_start();
include("checksession.php");
?>
<title>Mediation</title>
<link href="include/css/css.css" rel="stylesheet" type="text/css" />
<table border="0" cellpadding="0" cellspacing="0" width="100%">

<tr>
<td height="10" bgcolor="#999999"  class="redlink2" onClick="javascript: goback('<?php echo $_GET['blink'] ;?>');" colspan="5" >Go Back 
</td>
</tr>

<tr>
	<td class="Heading">
		<b>Rules of Mediation</b><br />
	</td>
</tr>
<tr>
	<td class="SubHeading">
		There are some rules of mediation.
		<ul class="SubHeading">
			<li> If this mediation goes in your favour. then the seller of this product will be banned.</li>
			<li>If this mediation goes against your then you will be banned by admin.</li>
			<li>If any one banned then he cannot buy or sell the product using this website</li>
		</ul>
	</td>
</tr>

<tr>
<td align="center">
<?php $iboughtproductid = $_GET['boughtproductid'] ; ?>
<?php
$baclklink = $_GET['blink'] ; 
$beforephpblink = explode(".php",$baclklink);
if($beforephpblink[0] == 'soldproducts') { ?>
<input type="button" class="SubHeading" value=" Click to Continue Mediation " onclick="javascript: mediation(<?php echo $iboughtproductid ;?>,'soldproducts.php')" />
<?php } else { ?>
<input type="button" class="SubHeading" value=" Click to Continue Mediation " onclick="javascript: mediation(<?php echo $iboughtproductid ;?>,'boughtproducts.php')" />
<?php } ?>
</td>
</tr>
</table>