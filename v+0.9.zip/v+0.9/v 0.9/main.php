<?php
session_start();

if(isset($_GET["pg"]) && ($_GET['pg'] == "aboutus.php" || $_GET['pg'] == "legal.php" || $_GET['pg'] == "contactus.php" || $_GET['pg'] == "termsofservices.php" || $_GET['pg'] == "thanku.php" ))
{
include("include/template.php");
templateheader("" , "true");

$strpage2 = $_GET["pg"];
$strphpposition = explode(".php",$strpage2);
$page = $strphpposition[0] ;
$strpage = $page.".php" ;
?>
<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td width="100%" valign="top" class="content">		
			<?php include($strpage); ?>
		</td>
					
	</tr>
</table>
<?php
templatefooter("" , "true");
}
else
{

if(!isset($_SESSION['loginid']) || $_SESSION['loginid'] == '') 
{
include("login.php");
}
else
{	
	
include("include/template.php");
templateheader("" , "true");

$strpage;

if(isset($_GET["pg"]))
{
$strpage = $_GET["pg"];
?>


<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td width="100%" valign="top" class="content">	
			<?php include($strpage); ?>		
		</td>
					
	</tr>
</table>
<?php
}
else
{
?>
<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td width="100%" valign="top" class="content">	
			<span  class="heading"> Main Page</span>
			<p class="content">This is home page</p>
		
		</td>
					
	</tr>
</table>

<?php
}
templatefooter("" , "true");
}

}
?>
<?php

?>