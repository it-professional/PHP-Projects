<?php session_start();
include("checksession.php");
 ?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td>
			<?php
			$productid = $_GET['id'] ;
			include("include/config.php");
			$query = mysql_query("delete from tblproducts where iid = '$productid'");
			if($query)
			{
			$query2 = mysql_query("delete from tblproductfeatures where ipid = '$productid' ");
			include('selleraccount.php');
			}
			?>
		</td>
	</tr>
</table>			



